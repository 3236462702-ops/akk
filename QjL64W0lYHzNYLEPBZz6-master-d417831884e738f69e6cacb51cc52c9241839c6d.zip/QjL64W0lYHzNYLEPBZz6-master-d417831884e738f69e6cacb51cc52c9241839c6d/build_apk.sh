#!/bin/bash

echo "=========================================="
echo "Auto Accessibility Assistant - APK Build"
echo "=========================================="
echo ""

# 检查 Gradle 版本
echo "Checking Gradle version..."
gradle --version
echo ""

# 清理之前的构建
echo "Cleaning previous build..."
gradle clean --no-daemon
echo ""

# 构建 Release APK
echo "Building Release APK..."
gradle assembleRelease --no-daemon
echo ""

# 检查 APK 是否生成
if [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
    echo "=========================================="
    echo "✅ Build Successful!"
    echo "=========================================="
    echo ""
    echo "APK Location: app/build/outputs/apk/release/app-release.apk"
    echo ""
    echo "File size:"
    ls -lh app/build/outputs/apk/release/app-release.apk
else
    echo "=========================================="
    echo "❌ Build Failed or APK not found"
    echo "=========================================="
    echo ""
    echo "Please check the error messages above."
    echo "Common issues:"
    echo "  1. Android SDK not properly configured"
    echo "  2. Missing ANDROID_HOME environment variable"
    echo "  3. Gradle version mismatch"
fi