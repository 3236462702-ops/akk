package com.autoaccessibility.assistant.security

import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * 安全工具类
 * 提供验证码加密、防调试等安全功能
 */
object SecurityUtils {

    private const val AES_KEY = "AutoAccessibility2024" // 16 字节密钥
    
    /**
     * 简单加密验证码
     * 使用 Base64 编码进行简单混淆（生产环境建议使用更安全的加密方式）
     */
    fun encrypt(code: String): String {
        return try {
            // 简单的 XOR 加密 + Base64
            val keyBytes = AES_KEY.toByteArray(Charsets.UTF_8)
            val inputBytes = code.toByteArray(Charsets.UTF_8)
            
            val encrypted = ByteArray(inputBytes.size)
            for (i in inputBytes.indices) {
                encrypted[i] = (inputBytes[i].toInt() xor keyBytes[i % keyBytes.size].toInt()).toByte()
            }
            
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        } catch (e: Exception) {
            // 加密失败时返回原始值
            code
        }
    }
    
    /**
     * 解密验证码
     */
    fun decrypt(encryptedCode: String): String {
        return try {
            val keyBytes = AES_KEY.toByteArray(Charsets.UTF_8)
            val decodedBytes = Base64.decode(encryptedCode, Base64.NO_WRAP)
            
            val decrypted = ByteArray(decodedBytes.size)
            for (i in decodedBytes.indices) {
                decrypted[i] = (decodedBytes[i].toInt() xor keyBytes[i % keyBytes.size].toInt()).toByte()
            }
            
            String(decrypted, Charsets.UTF_8)
        } catch (e: Exception) {
            // 解密失败时返回原始值
            encryptedCode
        }
    }
    
    /**
     * 检测是否处于调试模式
     */
    fun isDebuggerConnected(): Boolean {
        return android.os.Debug.isDebuggerConnected()
    }
    
    /**
     * 检测应用是否运行在模拟器中
     */
    fun isEmulator(): Boolean {
        return (android.os.Build.FINGERPRINT.startsWith("generic") ||
                android.os.Build.FINGERPRINT.startsWith("unknown") ||
                android.os.Build.MODEL.contains("google_sdk") ||
                android.os.Build.MODEL.contains("Emulator") ||
                android.os.Build.MODEL.contains("Android SDK built for x86") ||
                android.os.Build.MANUFACTURER.contains("Genymotion") ||
                (android.os.Build.BRAND.startsWith("generic") && android.os.Build.DEVICE.startsWith("generic")) ||
                "google_sdk" == android.os.Build.PRODUCT)
    }
    
    /**
     * 获取应用的签名哈希（用于验证应用完整性）
     */
    fun getAppSignatureHash(context: android.content.Context): String {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(
                context.packageName,
                android.content.pm.PackageManager.GET_SIGNATURES
            )
            val signatures = packageInfo.signatures
            if (signatures != null && signatures.isNotEmpty()) {
                val signature = signatures[0].toByteArray()
                val md = java.security.MessageDigest.getInstance("SHA")
                md.update(signature)
                val digest = md.digest()
                
                val hexString = StringBuilder()
                for (b in digest) {
                    val hex = Integer.toHexString(0xff and b.toInt())
                    if (hex.length == 1) hexString.append('0')
                    hexString.append(hex)
                }
                hexString.toString()
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }
    
    /**
     * 验证应用签名是否匹配预期值
     * @param context 上下文
     * @param expectedHash 预期的签名哈希
     * @return 签名是否匹配
     */
    fun verifyAppSignature(context: android.content.Context, expectedHash: String): Boolean {
        val currentHash = getAppSignatureHash(context)
        return currentHash.equals(expectedHash, ignoreCase = true)
    }
}