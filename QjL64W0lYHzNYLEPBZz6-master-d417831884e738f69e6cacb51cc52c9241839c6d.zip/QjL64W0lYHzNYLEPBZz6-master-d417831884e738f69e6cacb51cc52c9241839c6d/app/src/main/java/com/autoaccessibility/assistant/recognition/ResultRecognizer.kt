package com.autoaccessibility.assistant.recognition

import android.graphics.Bitmap
import android.util.Log
import com.autoaccessibility.assistant.capture.ScreenCaptureManager
import com.autoaccessibility.assistant.ocr.OcrService
import kotlinx.coroutines.*
import java.util.concurrent.CopyOnWriteArrayList

/**
 * 抢单结果识别引擎
 * 通过 OCR 文字识别 + 图像特征比对，判断抢单成功/失败
 * 
 * 适配 Android 15 和澎湃系统（HyperOS）
 */
class ResultRecognizer {

    companion object {
        private const val TAG = "ResultRecognizer"
        
        @Volatile
        private var instance: ResultRecognizer? = null
        
        /**
         * 获取单例实例
         */
        fun getInstance(): ResultRecognizer {
            return instance ?: synchronized(this) {
                instance ?: ResultRecognizer().also { instance = it }
            }
        }
        
        // 默认成功关键词库
        val DEFAULT_SUCCESS_KEYWORDS = listOf(
            "抢单成功",
            "已接单",
            "接单成功",
            "接受订单成功",
            "您已抢到订单",
            "订单已确认",
            "Success",
            "Accepted"
        )
        
        // 默认失败关键词库
        val DEFAULT_FAILED_KEYWORDS = listOf(
            "订单已被抢",
            "已被抢走",
            "手慢了",
            "抢单失败",
            "来晚了",
            "已经有人接单",
            "Failed",
            "Taken"
        )
    }

    private val ocrService = OcrService.getInstance()
    private var captureManager: ScreenCaptureManager? = null
    
    // 可配置的关键词库（支持用户自定义）
    private var successKeywords = DEFAULT_SUCCESS_KEYWORDS.toMutableList()
    private var failedKeywords = DEFAULT_FAILED_KEYWORDS.toMutableList()
    
    // 识别配置
    private var recognitionTimeout = 3000L  // 默认 3 秒超时
    private var captureInterval = 600L      // 截图间隔 600ms
    private var isEnabled = true            // 是否启用识别
    
    // 识别结果回调
    private val resultCallbacks = CopyOnWriteArrayList<ResultCallback>()
    
    // 置信度阈值
    private val CONFIDENCE_THRESHOLD = 0.6f
    
    // 多帧投票机制
    private val recentResults = mutableListOf<GrabResultType>()
    private val MAX_HISTORY_SIZE = 5

    /**
     * 初始化（依赖注入）
     */
    fun initialize(captureManager: ScreenCaptureManager) {
        this.captureManager = captureManager
        Log.d(TAG, "抢单结果识别引擎已初始化")
    }

    /**
     * 开始识别抢单结果
     * 在抢单操作后自动调用此方法
     * 
     * @param delayMs 延迟开始时间（毫秒），给 APP 响应时间，默认 500ms
     */
    fun startRecognition(delayMs: Long = 500) {
        if (!isEnabled) {
            Log.d(TAG, "结果识别功能已禁用")
            return
        }
        
        if (captureManager == null) {
            Log.e(TAG, "请先调用 initialize() 初始化")
            notifyResult(GrabResultType.UNKNOWN, "识别引擎未初始化")
            return
        }
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // 延迟开始，等待 APP 响应
                delay(delayMs)
                
                Log.d(TAG, "开始抢单结果识别，超时 ${recognitionTimeout}ms")
                recentResults.clear()
                
                // 使用连续截图模式
                captureManager?.startContinuousCapture(
                    durationMs = recognitionTimeout,
                    intervalMs = captureInterval,
                    callback = object : ScreenCaptureManager.ScreenshotCallback {
                        override fun onScreenshotCaptured(bitmap: Bitmap) {
                            analyzeScreenshot(bitmap)
                        }
                        
                        override fun onError(error: String) {
                            Log.e(TAG, "截图错误：$error")
                        }
                    }
                )
                
                // 等待识别完成
                delay(recognitionTimeout + 500)
                
                // 综合所有帧的结果，投票决定最终结果
                val finalResult = votingDecision()
                Log.d(TAG, "最终识别结果：$finalResult（基于 ${recentResults.size} 帧）")
                
                notifyResult(finalResult, getResultDescription(finalResult))
                
            } catch (e: Exception) {
                Log.e(TAG, "识别过程异常", e)
                notifyResult(GrabResultType.UNKNOWN, "识别异常：${e.message}")
            }
        }
    }

    /**
     * 分析单张截图
     */
    private fun analyzeScreenshot(bitmap: Bitmap) {
        CoroutineScope(Dispatchers.IO).launch {
            var tempFile: java.io.File? = null
            try {
                // 1. 将 Bitmap 转换为临时文件进行 OCR
                tempFile = bitmapToTempFile(bitmap)
                
                // 2. 执行 OCR 识别（suspend 函数）
                val ocrResult = ocrService.recognizeFromFile(tempFile)
                
                if (ocrResult == null || !ocrResult.success) {
                    Log.w(TAG, "OCR 识别失败")
                    return@launch
                }
                
                val text = ocrResult.text
                Log.d(TAG, "OCR 识别内容：${text.take(100)}...")
                
                // 3. 检测成功关键词
                var successScore = 0
                for (keyword in successKeywords) {
                    if (text.contains(keyword, ignoreCase = true)) {
                        successScore++
                        Log.d(TAG, "匹配到成功关键词：$keyword")
                    }
                }
                
                // 4. 检测失败关键词
                var failedScore = 0
                for (keyword in failedKeywords) {
                    if (text.contains(keyword, ignoreCase = true)) {
                        failedScore++
                        Log.d(TAG, "匹配到失败关键词：$keyword")
                    }
                }
                
                // 5. 计算置信度并记录结果
                val result = when {
                    successScore > failedScore && successScore >= 1 -> {
                        val confidence = (successScore.toFloat() / successKeywords.size).coerceAtLeast(CONFIDENCE_THRESHOLD)
                        if (confidence >= CONFIDENCE_THRESHOLD) GrabResultType.SUCCESS else GrabResultType.UNKNOWN
                    }
                    failedScore > successScore && failedScore >= 1 -> {
                        val confidence = (failedScore.toFloat() / failedKeywords.size).coerceAtLeast(CONFIDENCE_THRESHOLD)
                        if (confidence >= CONFIDENCE_THRESHOLD) GrabResultType.FAILED else GrabResultType.UNKNOWN
                    }
                    else -> GrabResultType.UNKNOWN
                }
                
                recentResults.add(result)
                if (recentResults.size > MAX_HISTORY_SIZE) {
                    recentResults.removeAt(0)
                }
                
                Log.d(TAG, "当前帧识别结果：$result (成功:$successScore, 失败:$failedScore)")
                
            } catch (e: Exception) {
                Log.e(TAG, "分析截图异常", e)
            } finally {
                tempFile?.delete()
            }
        }
    }

    /**
     * 多帧投票决策
     * 提高准确率，避免单帧误判
     */
    private fun votingDecision(): GrabResultType {
        if (recentResults.isEmpty()) {
            return GrabResultType.TIMEOUT
        }
        
        // 统计各结果出现次数
        val counts = mutableMapOf<GrabResultType, Int>()
        recentResults.forEach { result ->
            counts[result] = (counts[result] ?: 0) + 1
        }
        
        // 找出出现次数最多的结果
        val maxCount = counts.values.maxOrNull() ?: 0
        val candidates = counts.filter { it.value == maxCount }
        
        // 如果有多个并列第一，优先 SUCCESS > FAILED > UNKNOWN
        return when {
            candidates.containsKey(GrabResultType.SUCCESS) -> GrabResultType.SUCCESS
            candidates.containsKey(GrabResultType.FAILED) -> GrabResultType.FAILED
            else -> GrabResultType.UNKNOWN
        }
    }

    /**
     * 将 Bitmap 转换为临时文件
     */
    private fun bitmapToTempFile(bitmap: Bitmap): java.io.File {
        val tempFile = java.io.File.createTempFile("screenshot_", ".png")
        val outputStream = java.io.FileOutputStream(tempFile)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        outputStream.flush()
        outputStream.close()
        return tempFile
    }

    /**
     * 通知识别结果给所有注册的回调
     */
    private fun notifyResult(result: GrabResultType, reason: String) {
        CoroutineScope(Dispatchers.Main).launch {
            resultCallbacks.forEach { callback ->
                try {
                    callback.onResult(result, reason)
                } catch (e: Exception) {
                    Log.e(TAG, "回调通知失败", e)
                }
            }
        }
    }

    /**
     * 获取结果的描述文本
     */
    private fun getResultDescription(result: GrabResultType): String {
        return when (result) {
            GrabResultType.SUCCESS -> "✅ 抢单成功"
            GrabResultType.FAILED -> "❌ 订单已被抢"
            GrabResultType.TIMEOUT -> "⏱️ 识别超时"
            GrabResultType.UNKNOWN -> "❓ 结果未知"
        }
    }

    // ==================== 配置管理 ====================

    /**
     * 添加自定义成功关键词
     */
    fun addSuccessKeyword(keyword: String) {
        if (!successKeywords.contains(keyword)) {
            successKeywords.add(keyword)
            Log.d(TAG, "添加成功关键词：$keyword")
        }
    }

    /**
     * 添加自定义失败关键词
     */
    fun addFailedKeyword(keyword: String) {
        if (!failedKeywords.contains(keyword)) {
            failedKeywords.add(keyword)
            Log.d(TAG, "添加失败关键词：$keyword")
        }
    }

    /**
     * 移除成功关键词
     */
    fun removeSuccessKeyword(keyword: String) {
        successKeywords.remove(keyword)
        Log.d(TAG, "移除成功关键词：$keyword")
    }

    /**
     * 移除失败关键词
     */
    fun removeFailedKeyword(keyword: String) {
        failedKeywords.remove(keyword)
        Log.d(TAG, "移除失败关键词：$keyword")
    }

    /**
     * 获取所有成功关键词
     */
    fun getSuccessKeywords(): List<String> {
        return successKeywords.toList()
    }

    /**
     * 获取所有失败关键词
     */
    fun getFailedKeywords(): List<String> {
        return failedKeywords.toList()
    }

    /**
     * 设置识别超时时间
     */
    fun setRecognitionTimeout(timeoutMs: Long) {
        this.recognitionTimeout = timeoutMs.coerceIn(2000, 5000)
        Log.d(TAG, "识别超时时间设置为：${this.recognitionTimeout}ms")
    }

    /**
     * 设置截图间隔
     */
    fun setCaptureInterval(intervalMs: Long) {
        this.captureInterval = intervalMs.coerceAtLeast(300)
        Log.d(TAG, "截图间隔设置为：${this.captureInterval}ms")
    }

    /**
     * 启用/禁用识别功能
     */
    fun setEnabled(enabled: Boolean) {
        this.isEnabled = enabled
        Log.d(TAG, "结果识别功能已${if (enabled) "启用" else "禁用"}")
    }

    /**
     * 是否已启用
     */
    fun isEnabled(): Boolean {
        return isEnabled
    }

    /**
     * 注册结果回调
     */
    fun registerCallback(callback: ResultCallback) {
        if (!resultCallbacks.contains(callback)) {
            resultCallbacks.add(callback)
        }
    }

    /**
     * 注销结果回调
     */
    fun unregisterCallback(callback: ResultCallback) {
        resultCallbacks.remove(callback)
    }

    /**
     * 清空所有回调
     */
    fun clearCallbacks() {
        resultCallbacks.clear()
    }

    /**
     * 重置识别状态
     */
    fun reset() {
        recentResults.clear()
        Log.d(TAG, "识别状态已重置")
    }

    /**
     * 销毁服务
     */
    fun destroy() {
        captureManager?.stopContinuousCapture()
        clearCallbacks()
        reset()
        instance = null
        Log.d(TAG, "抢单结果识别引擎已销毁")
    }
}

/**
 * 抢单结果类型枚举
 */
enum class GrabResultType {
    SUCCESS,    // 抢单成功
    FAILED,     // 抢单失败（已被抢）
    TIMEOUT,    // 识别超时
    UNKNOWN     // 无法确定
}

/**
 * 结果回调接口
 */
interface ResultCallback {
    fun onResult(result: GrabResultType, reason: String)
}