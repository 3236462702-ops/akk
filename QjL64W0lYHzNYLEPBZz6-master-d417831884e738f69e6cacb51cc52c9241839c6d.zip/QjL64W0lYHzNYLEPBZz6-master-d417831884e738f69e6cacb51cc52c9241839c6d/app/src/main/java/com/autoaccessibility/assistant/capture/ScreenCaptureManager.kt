package com.autoaccessibility.assistant.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.util.concurrent.CopyOnWriteArrayList

/**
 * 屏幕捕获管理器
 * 使用 MediaProjection API 截取屏幕内容
 */
class ScreenCaptureManager {

    companion object {
        private const val TAG = "ScreenCaptureManager"
        private const val REQUEST_CODE_SCREEN_CAPTURE = 1001
        
        @Volatile
        private var instance: ScreenCaptureManager? = null
        
        fun getInstance(): ScreenCaptureManager {
            return instance ?: synchronized(this) {
                instance ?: ScreenCaptureManager().also { instance = it }
            }
        }
        
        /**
         * 启动屏幕捕获权限申请
         */
        fun requestScreenCapture(activity: Activity) {
            val mediaProjectionManager = activity.getSystemService(
                Context.MEDIA_PROJECTION_SERVICE
            ) as MediaProjectionManager
            
            val intent = mediaProjectionManager.createScreenCaptureIntent()
            
            // Android 15 适配已移除（compileSdk=33 不支持）
            
            activity.startActivityForResult(intent, REQUEST_CODE_SCREEN_CAPTURE)
        }
    }
    
    /**
     * 截图回调接口
     */
    interface ScreenshotCallback {
        fun onScreenshotCaptured(bitmap: Bitmap)
        fun onError(error: String)
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handler = Handler(Looper.getMainLooper())
    
    private var width = 0
    private var height = 0
    private var dpi = 0
    
    // Android 15 适配已移除（compileSdk=33 不支持）
    
    // 连续截图相关
    private var captureScope: CoroutineScope? = null
    private val screenshotCallbacks = CopyOnWriteArrayList<ScreenshotCallback>()
    
    // 内存优化：Bitmap 池
    private val bitmapPool = mutableListOf<Bitmap>()
    private val MAX_BITMAP_POOL_SIZE = 3

    /**
     * 处理权限申请结果
     */
    fun handleResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQUEST_CODE_SCREEN_CAPTURE) {
            return false
        }
        
        if (resultCode != Activity.RESULT_OK) {
            Log.e(TAG, "屏幕捕获权限被拒绝")
            // 降级方案：提示用户手动截图或使用无障碍服务替代
            notifyPermissionDenied()
            return false
        }
        
        val context = android.app.Application().applicationContext
        val mediaProjectionManager = context.getSystemService(
            Context.MEDIA_PROJECTION_SERVICE
        ) as MediaProjectionManager
        
        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data!!)
        
        if (mediaProjection == null) {
            Log.e(TAG, "无法获取 MediaProjection 实例")
            return false
        }
        
        // Android 15 适配已移除（compileSdk=33 不支持）
        
        // 获取屏幕尺寸
        val metrics = DisplayMetrics()
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.getDisplay(0).getMetrics(metrics)
        
        width = metrics.widthPixels
        height = metrics.heightPixels
        dpi = metrics.densityDpi
        
        Log.i(TAG, "屏幕捕获已初始化：${width}x${height}, DPI=$dpi")
        return true
    }
    
    // Android 15 适配方法已移除（compileSdk=33 不支持）
    
    /**
     * 权限被拒绝后的降级方案
     */
    private fun notifyPermissionDenied() {
        // 可通过广播或回调通知 UI 层显示引导
        Log.w(TAG, "建议使用无障碍服务替代屏幕捕获")
    }
    
    /**
     * MediaProjection 被停止的通知
     */
    private fun notifyProjectionStopped() {
        screenshotCallbacks.forEach { callback ->
            try {
                callback.onError("屏幕捕获服务已停止")
            } catch (e: Exception) {
                Log.e(TAG, "回调通知失败", e)
            }
        }
    }

    /**
     * 检查是否已初始化
     */
    fun isInitialized(): Boolean {
        return mediaProjection != null
    }

    /**
     * 截取屏幕并返回 Bitmap
     */
    fun captureScreen(): Bitmap? {
        if (mediaProjection == null) {
            Log.e(TAG, "MediaProjection 未初始化")
            return null
        }
        
        var virtualDisplay: VirtualDisplay? = null
        var imageReader: ImageReader? = null
        
        try {
            // 创建 ImageReader
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            
            // 创建虚拟显示
            virtualDisplay = mediaProjection!!.createVirtualDisplay(
                "ScreenCapture",
                width,
                height,
                dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                handler
            )
            
            // 等待图像可用
            Thread.sleep(100)  // 优化：减少等待时间
            
            // 获取最新图像
            val image = imageReader.acquireLatestImage() ?: return null
            
            try {
                val bitmap = imageToBitmap(image) ?: return null
                // 加入缓存池
                addToBitmapPool(bitmap)
                return bitmap
            } finally {
                image.close()
            }
        } catch (e: Exception) {
            Log.e(TAG, "屏幕捕获失败", e)
            return null
        } finally {
            // 及时释放资源
            virtualDisplay?.release()
            imageReader?.close()
        }
    }
    
    /**
     * Android 15 适配：连续截图模式（抢单结果识别专用）
     * @param durationMs 持续时间（毫秒），默认 3000ms
     * @param intervalMs 截图间隔（毫秒），默认 600ms（3 秒内约 5 张）
     * @param callback 截图回调
     */
    fun startContinuousCapture(
        durationMs: Long = 3000,
        intervalMs: Long = 600,
        callback: ScreenshotCallback
    ) {
        if (mediaProjection == null) {
            callback.onError("MediaProjection 未初始化")
            return
        }
        
        screenshotCallbacks.add(callback)
        
        captureScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        captureScope?.launch {
            val startTime = System.currentTimeMillis()
            var captureCount = 0
            
            Log.d(TAG, "开始连续截图：持续 ${durationMs}ms, 间隔 ${intervalMs}ms")
            
            try {
                while (System.currentTimeMillis() - startTime < durationMs) {
                    if (!isActive) break
                    
                    val bitmap = captureScreen()
                    if (bitmap != null) {
                        captureCount++
                        withContext(Dispatchers.Main) {
                            callback.onScreenshotCaptured(bitmap)
                        }
                        Log.d(TAG, "第 $captureCount 张截图完成")
                    } else {
                        withContext(Dispatchers.Main) {
                            callback.onError("截图失败")
                        }
                    }
                    
                    delay(intervalMs)
                }
                
                Log.d(TAG, "连续截图完成，共 $captureCount 张")
                
            } catch (e: Exception) {
                Log.e(TAG, "连续截图异常", e)
                withContext(Dispatchers.Main) {
                    callback.onError(e.message ?: "未知错误")
                }
            } finally {
                screenshotCallbacks.remove(callback)
            }
        }
    }
    
    /**
     * 停止连续截图
     */
    fun stopContinuousCapture() {
        captureScope?.cancel()
        captureScope = null
        screenshotCallbacks.clear()
        Log.d(TAG, "连续截图已停止")
    }
    
    /**
     * 将 Image 转换为 Bitmap
     */
    private fun imageToBitmap(image: Image): Bitmap? {
        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            
            // 计算行填充
            val rowPadding = rowStride - pixelStride * width
            
            // 计算实际宽度（考虑填充）
            val actualWidth = if (rowPadding >= 0) {
                width + rowPadding / pixelStride
            } else {
                width
            }
            
            val bitmap = Bitmap.createBitmap(
                actualWidth,
                height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            
            // 裁剪到实际尺寸
            val croppedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height)
            bitmap.recycle()
            
            return croppedBitmap
        } catch (e: Exception) {
            Log.e(TAG, "Image 转 Bitmap 失败", e)
            return null
        }
    }
    
    /**
     * 内存优化：将 Bitmap 加入缓存池
     */
    private fun addToBitmapPool(bitmap: Bitmap) {
        if (bitmapPool.size >= MAX_BITMAP_POOL_SIZE) {
            val oldBitmap = bitmapPool.removeAt(0)
            if (!oldBitmap.isRecycled) {
                oldBitmap.recycle()
            }
        }
        bitmapPool.add(bitmap)
    }
    
    /**
     * 从缓存池获取可复用的 Bitmap
     */
    private fun getFromBitmapPool(): Bitmap? {
        return if (bitmapPool.isNotEmpty()) {
            bitmapPool.removeAt(0)
        } else {
            null
        }
    }
    
    /**
     * 清理 Bitmap 缓存池
     */
    fun clearBitmapPool() {
        bitmapPool.forEach { bitmap ->
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
        bitmapPool.clear()
        Log.d(TAG, "Bitmap 缓存池已清理")
    }

    /**
     * 截取屏幕并转换为 Base64
     */
    fun captureScreenToBase64(): String? {
        val bitmap = captureScreen() ?: return null
        
        try {
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            val byteArray = outputStream.toByteArray()
            
            return android.util.Base64.encodeToString(byteArray, android.util.Base64.NO_WRAP)
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * 截取屏幕并保存为临时文件
     */
    fun captureScreenToFile(context: Context): java.io.File? {
        val bitmap = captureScreen() ?: return null
        
        try {
            val file = java.io.File(context.cacheDir, "screenshot_${System.currentTimeMillis()}.png")
            val outputStream = java.io.FileOutputStream(file)
            
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            outputStream.flush()
            outputStream.close()
            
            return file
        } catch (e: Exception) {
            Log.e(TAG, "保存截图失败", e)
            return null
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * 释放资源
     */
    fun release() {
        stopContinuousCapture()
        virtualDisplay?.release()
        imageReader?.close()
        clearBitmapPool()
        // 注意：不释放 mediaProjection，因为可能需要多次使用
        Log.d(TAG, "屏幕捕获资源已释放")
    }

    /**
     * 完全销毁（包括 MediaProjection）
     */
    fun destroy() {
        stopContinuousCapture()
        release()
        
        mediaProjection?.stop()
        mediaProjection = null
        instance = null
        Log.i(TAG, "屏幕捕获服务已销毁")
    }
}