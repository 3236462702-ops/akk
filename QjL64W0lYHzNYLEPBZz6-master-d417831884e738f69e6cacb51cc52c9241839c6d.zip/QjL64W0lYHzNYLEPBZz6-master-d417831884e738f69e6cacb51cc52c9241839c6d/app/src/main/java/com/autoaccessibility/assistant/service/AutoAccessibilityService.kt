package com.autoaccessibility.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.autoaccessibility.assistant.model.UiElement
import java.util.*

/**
 * 核心无障碍服务
 * 负责：监听界面变化、获取屏幕元素信息、执行手势操作
 */
class AutoAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoAccessibilityService"
        
        @Volatile
        private var instance: AutoAccessibilityService? = null
        
        /**
         * 获取服务单例（外部调用前需检查 isRunning）
         */
        fun getInstance(): AutoAccessibilityService? = instance
        
        /**
         * 服务是否正在运行
         */
        fun isRunning(): Boolean = instance != null && instance!!.isConnected()
        
        var isConnected: Boolean = false
            private set
        
        // 状态监听回调
        var onStateChanged: ((Boolean) -> Unit)? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    
    // 当前屏幕元素缓存
    private var currentElements: List<UiElement> = emptyList()
    
    // 元素变化监听器
    var onElementsChanged: ((List<UiElement>) -> Unit)? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "无障碍服务已连接")
        instance = this
        isConnected = true
        onStateChanged?.invoke(true)
        
        // 延迟初始化，等待系统准备
        handler.postDelayed({
            refreshScreenElements()
        }, 500)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                Log.d(TAG, "窗口状态变化：${event.packageName}")
                // 窗口切换时刷新元素
                handler.postDelayed({ refreshScreenElements() }, 300)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // 内容变化，可选择性刷新
                Log.d(TAG, "窗口内容变化")
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                Log.d(TAG, "视图被点击：${event.className}")
            }
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                Log.d(TAG, "视图获得焦点")
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "服务被中断")
        isConnected = false
        onStateChanged?.invoke(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "服务销毁")
        instance = null
        isConnected = false
        onStateChanged?.invoke(false)
    }

    /**
     * 刷新当前屏幕元素列表
     */
    fun refreshScreenElements() {
        try {
            val root = getRootInActiveWindow() ?: return
            currentElements = traverseNodeInfo(root, 0)
            Log.d(TAG, "扫描到 ${currentElements.size} 个元素")
            onElementsChanged?.invoke(currentElements)
        } catch (e: Exception) {
            Log.e(TAG, "刷新元素失败", e)
        }
    }

    /**
     * 递归遍历 AccessibilityNodeInfo 树
     */
    private fun traverseNodeInfo(
        node: AccessibilityNodeInfo,
        depth: Int,
        parentText: String = ""
    ): List<UiElement> {
        val elements = mutableListOf<UiElement>()
        
        if (depth > 15) { // 防止过深
            return elements
        }

        try {
            // 提取元素信息
            val text = node.text?.toString() ?: ""
            val contentDesc = node.contentDescription?.toString() ?: ""
            val displayText = if (text.isNotEmpty()) text else contentDesc
            
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            
            // 过滤无效元素（不可见或尺寸为 0）
            if (bounds.width() > 0 && bounds.height() > 0) {
                val element = UiElement(
                    id = generateElementId(),
                    text = displayText,
                    className = node.className?.toString() ?: "",
                    packageName = node.packageName?.toString() ?: "",
                    bounds = bounds,
                    isClickable = node.isClickable,
                    isCheckable = node.isCheckable,
                    isChecked = node.isChecked,
                    isEnabled = node.isEnabled,
                    isVisibleToUser = node.isVisibleToUser,
                    depth = depth,
                    parentText = parentText
                )
                elements.add(element)
            }

            // 递归子节点
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                val childElements = traverseNodeInfo(
                    child,
                    depth + 1,
                    if (displayText.isNotEmpty()) displayText else parentText
                )
                elements.addAll(childElements)
            }
        } catch (e: Exception) {
            Log.e(TAG, "遍历节点失败", e)
        } finally {
            // 注意：根节点由调用者回收，子节点在这里回收
            if (node !== getRootInActiveWindow()) {
                try {
                    node.recycle()
                } catch (e: Exception) {
                    Log.e(TAG, "回收节点失败", e)
                }
            }
        }

        return elements
    }

    private var elementCounter = 0L
    private fun generateElementId(): Long = ++elementCounter

    /**
     * 按文字查找元素（模糊匹配）
     */
    fun findElementByText(text: String, exact: Boolean = false): UiElement? {
        return if (exact) {
            currentElements.find { it.text == text }
        } else {
            currentElements.find { it.text.contains(text, ignoreCase = true) }
        }
    }

    /**
     * 按坐标范围查找元素
     */
    fun findElementByBounds(x: Int, y: Int): UiElement? {
        return currentElements.find { it.bounds.contains(x, y) }
    }

    /**
     * 获取所有可点击元素
     */
    fun getClickableElements(): List<UiElement> {
        return currentElements.filter { it.isClickable && it.isVisibleToUser }
    }

    /**
     * 获取当前屏幕元素列表（公共访问方法）
     */
    fun getCurrentElements(): List<UiElement> {
        return currentElements
    }

    // ==================== 手势操作 ====================

    /**
     * 执行点击操作
     */
    fun performClick(x: Int, y: Int, delay: Long = 0): Boolean {
        if (delay > 0) {
            handler.postDelayed({
                dispatchGesture(createClickGesture(x, y), null, null)
            }, delay)
            return true
        }
        return dispatchGesture(createClickGesture(x, y), null, null)
    }

    /**
     * 执行点击操作（基于元素）
     */
    fun performClick(element: UiElement): Boolean {
        val centerX = element.bounds.centerX()
        val centerY = element.bounds.centerY()
        return performClick(centerX, centerY)
    }

    /**
     * 执行长按操作
     */
    fun performLongPress(x: Int, y: Int, duration: Long = 2000): Boolean {
        return dispatchGesture(createLongPressGesture(x, y, duration), null, null)
    }

    /**
     * 执行滑动操作
     */
    fun performSwipe(startX: Int, startY: Int, endX: Int, endY: Int, duration: Long = 500): Boolean {
        return dispatchGesture(createSwipeGesture(startX, startY, endX, endY, duration), null, null)
    }

    /**
     * 执行全局返回操作
     */
    fun performGlobalBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    /**
     * 执行全局主页操作
     */
    fun performGlobalHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    /**
     * 执行全局最近任务操作
     */
    fun performGlobalRecentApps(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    /**
     * 创建点击手势
     */
    private fun createClickGesture(x: Int, y: Int): GestureDescription {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        
        val builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, 1))
        
        return builder.build()
    }

    /**
     * 创建长按手势
     */
    private fun createLongPressGesture(x: Int, y: Int, duration: Long): GestureDescription {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        
        val builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, duration))
        
        return builder.build()
    }

    /**
     * 创建滑动手势
     */
    private fun createSwipeGesture(
        startX: Int, startY: Int,
        endX: Int, endY: Int,
        duration: Long
    ): GestureDescription {
        val path = Path()
        path.moveTo(startX.toFloat(), startY.toFloat())
        path.lineTo(endX.toFloat(), endY.toFloat())
        
        val builder = GestureDescription.Builder()
        builder.addStroke(GestureDescription.StrokeDescription(path, 0, duration))
        
        return builder.build()
    }

    /**
     * 延迟执行任务
     */
    fun postDelayed(runnable: Runnable, delayMillis: Long) {
        handler.postDelayed(runnable, delayMillis)
    }
    
    /**
     * 获取当前连接状态
     */
    fun isConnected(): Boolean {
        return isConnected
    }

    /**
     * 获取当前屏幕分辨率
     */
    fun getScreenSize(): Pair<Int, Int> {
        val root = getRootInActiveWindow()
        val bounds = Rect()
        root?.getBoundsInScreen(bounds)
        root?.recycle()
        
        return if (bounds.width() > 0 && bounds.height() > 0) {
            Pair(bounds.width(), bounds.height())
        } else {
            // 默认值
            Pair(1080, 2400)
        }
    }
}