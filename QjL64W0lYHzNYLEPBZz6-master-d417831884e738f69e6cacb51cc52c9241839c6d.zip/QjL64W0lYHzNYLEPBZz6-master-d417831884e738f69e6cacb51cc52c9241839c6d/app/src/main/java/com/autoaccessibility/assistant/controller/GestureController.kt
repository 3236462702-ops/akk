package com.autoaccessibility.assistant.controller

import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.autoaccessibility.assistant.model.ActionType
import com.autoaccessibility.assistant.model.TaskStep
import com.autoaccessibility.assistant.model.UiElement
import com.autoaccessibility.assistant.service.AutoAccessibilityService

/**
 * 手势操作控制器
 * 封装所有模拟人手操作的方法，提供高级 API
 */
class GestureController {

    companion object {
        private const val TAG = "GestureController"
        
        // 默认操作延迟（毫秒）
        const val DEFAULT_DELAY = 1000L
        const val CLICK_DELAY = 300L
        const val SWIPE_DURATION = 500L
        const val LONG_PRESS_DURATION = 2000L
        
        // 默认重试次数
        const val DEFAULT_RETRY_COUNT = 3
    }

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    
    // 执行状态监听
    var onStepStarted: ((TaskStep) -> Unit)? = null
    var onStepCompleted: ((TaskStep, Boolean) -> Unit)? = null
    var onTaskCompleted: ((Boolean) -> Unit)? = null

    /**
     * 获取无障碍服务实例
     */
    private fun getService(): AutoAccessibilityService? {
        return AutoAccessibilityService.getInstance()
    }

    /**
     * 检查服务是否可用
     */
    fun isServiceAvailable(): Boolean {
        return AutoAccessibilityService.isRunning()
    }

    // ==================== 基础点击操作 ====================

    /**
     * 点击指定坐标
     */
    fun click(x: Int, y: Int, delay: Long = CLICK_DELAY): Boolean {
        Log.d(TAG, "点击坐标：($x, $y)")
        return getService()?.performClick(x, y, delay) ?: false
    }

    /**
     * 点击 UI 元素中心
     */
    fun click(element: UiElement): Boolean {
        if (!element.isVisibleToUser || !element.isEnabled) {
            Log.w(TAG, "元素不可见或未启用：${element.text}")
            return false
        }
        
        Log.d(TAG, "点击元素：${element.text}")
        return click(element.getCenterX(), element.getCenterY())
    }

    /**
     * 按文字查找并点击元素
     */
    fun clickByText(text: String, exact: Boolean = false): Boolean {
        Log.d(TAG, "查找并点击：'$text'")
        
        val service = getService() ?: run {
            Log.e(TAG, "无障碍服务不可用")
            return false
        }

        val element = service.findElementByText(text, exact)
        if (element == null) {
            Log.e(TAG, "未找到元素：'$text'")
            return false
        }

        return click(element)
    }

    /**
     * 点击所有匹配文字的元素（用于列表项）
     */
    fun clickAllByText(text: String): List<Boolean> {
        val service = getService() ?: return emptyList()
        
        val results = mutableListOf<Boolean>()
        service.refreshScreenElements()
        
        val elements = service.getCurrentElements().filter { 
            it.text.contains(text, ignoreCase = true) && it.isClickable 
        }
        
        Log.d(TAG, "找到 ${elements.size} 个匹配元素")
        
        for (element in elements) {
            results.add(click(element))
            Thread.sleep(DEFAULT_DELAY)
        }
        
        return results
    }

    // ==================== 长按操作 ====================

    /**
     * 长按指定坐标
     */
    fun longPress(x: Int, y: Int, duration: Long = LONG_PRESS_DURATION): Boolean {
        Log.d(TAG, "长按坐标：($x, $y), 时长：${duration}ms")
        return getService()?.performLongPress(x, y, duration) ?: false
    }

    /**
     * 长按 UI 元素
     */
    fun longPress(element: UiElement, duration: Long = LONG_PRESS_DURATION): Boolean {
        return longPress(element.getCenterX(), element.getCenterY(), duration)
    }

    /**
     * 按文字查找并长按元素
     */
    fun longPressByText(text: String, duration: Long = LONG_PRESS_DURATION): Boolean {
        val service = getService() ?: return false
        
        val element = service.findElementByText(text)
        if (element == null) {
            Log.e(TAG, "未找到元素：'$text'")
            return false
        }

        return longPress(element, duration)
    }

    // ==================== 滑动操作 ====================

    /**
     * 滑动操作
     */
    fun swipe(startX: Int, startY: Int, endX: Int, endY: Int, duration: Long = SWIPE_DURATION): Boolean {
        Log.d(TAG, "滑动：($startX,$startY) -> ($endX,$endY)")
        return getService()?.performSwipe(startX, startY, endX, endY, duration) ?: false
    }

    /**
     * 向上滑动（从下往上）
     */
    fun swipeUp(duration: Long = SWIPE_DURATION): Boolean {
        val service = getService() ?: return false
        val (width, height) = service.getScreenSize()
        
        val startX = width / 2
        val startY = (height * 0.7).toInt()
        val endX = width / 2
        val endY = (height * 0.3).toInt()
        
        return swipe(startX, startY, endX, endY, duration)
    }

    /**
     * 向下滑动（从上往下）
     */
    fun swipeDown(duration: Long = SWIPE_DURATION): Boolean {
        val service = getService() ?: return false
        val (width, height) = service.getScreenSize()
        
        val startX = width / 2
        val startY = (height * 0.3).toInt()
        val endX = width / 2
        val endY = (height * 0.7).toInt()
        
        return swipe(startX, startY, endX, endY, duration)
    }

    /**
     * 向左滑动
     */
    fun swipeLeft(duration: Long = SWIPE_DURATION): Boolean {
        val service = getService() ?: return false
        val (width, height) = service.getScreenSize()
        
        val startX = (width * 0.7).toInt()
        val startY = height / 2
        val endX = (width * 0.3).toInt()
        val endY = height / 2
        
        return swipe(startX, startY, endX, endY, duration)
    }

    /**
     * 向右滑动
     */
    fun swipeRight(duration: Long = SWIPE_DURATION): Boolean {
        val service = getService() ?: return false
        val (width, height) = service.getScreenSize()
        
        val startX = (width * 0.3).toInt()
        val startY = height / 2
        val endX = (width * 0.7).toInt()
        val endY = height / 2
        
        return swipe(startX, startY, endX, endY, duration)
    }

    /**
     * 滑动到指定元素可见
     */
    fun scrollToElement(text: String, maxSwipes: Int = 10): Boolean {
        val service = getService() ?: return false
        
        for (i in 0 until maxSwipes) {
            // 先检查元素是否存在
            service.refreshScreenElements()
            val element = service.findElementByText(text)
            
            if (element != null && element.isVisibleToUser) {
                Log.d(TAG, "找到元素，已滚动 $i 次")
                return true
            }
            
            // 未找到，向下滑动
            Log.d(TAG, "未找到元素，继续滚动 ($i/${maxSwipes})")
            swipeDown()
            Thread.sleep(DEFAULT_DELAY)
        }
        
        Log.e(TAG, "滚动 $maxSwipes 次后仍未找到元素：'$text'")
        return false
    }

    // ==================== 全局操作 ====================

    /**
     * 返回操作
     */
    fun goBack(): Boolean {
        Log.d(TAG, "执行返回")
        return getService()?.performGlobalBack() ?: false
    }

    /**
     * 主页操作
     */
    fun goToHome(): Boolean {
        Log.d(TAG, "返回主页")
        return getService()?.performGlobalHome() ?: false
    }

    /**
     * 最近任务操作
     */
    fun showRecentApps(): Boolean {
        Log.d(TAG, "显示最近任务")
        return getService()?.performGlobalRecentApps() ?: false
    }

    // ==================== 文本输入 ====================

    /**
     * 输入文本（需要先聚焦输入框）
     */
    fun inputText(text: String): Boolean {
        Log.d(TAG, "输入文本：$text")
        
        val service = getService() ?: return false
        
        try {
            // 尝试使用 AccessibilityNodeInfo 的 setText 方法
            val root = service.getRootInActiveWindow() ?: return false
            
            // 查找可编辑的节点
            val editableNode = findEditableNode(root)
            if (editableNode != null) {
                val arguments = android.os.Bundle()
                arguments.putCharSequence(
                    android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    text
                )
                
                val result = editableNode.performAction(
                    android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT,
                    arguments
                )
                
                editableNode.recycle()
                return result
            }
            
            root.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "输入文本失败", e)
        }
        
        return false
    }

    /**
     * 递归查找可编辑节点
     */
    private fun findEditableNode(node: android.view.accessibility.AccessibilityNodeInfo): android.view.accessibility.AccessibilityNodeInfo? {
        if (node.isEditable) {
            return node
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findEditableNode(child)
            if (result != null) {
                return result
            }
        }
        
        return null
    }

    // ==================== 任务执行 ====================

    /**
     * 执行单个步骤
     */
    suspend fun executeStep(step: TaskStep): Boolean {
        Log.d(TAG, "执行步骤：${step.description}")
        onStepStarted?.invoke(step)
        
        // 延迟执行
        if (step.delay > 0) {
            Thread.sleep(step.delay)
        }
        
        var success = false
        var retryCount = 0
        
        while (retryCount <= step.retryCount && !success) {
            success = when (step.actionType) {
                ActionType.CLICK -> {
                    if (step.targetText != null) {
                        clickByText(step.targetText)
                    } else if (step.x != null && step.y != null) {
                        click(step.x, step.y)
                    } else {
                        false
                    }
                }
                ActionType.LONG_PRESS -> {
                    if (step.targetText != null) {
                        longPressByText(step.targetText, step.duration)
                    } else if (step.x != null && step.y != null) {
                        longPress(step.x, step.y, step.duration)
                    } else {
                        false
                    }
                }
                ActionType.SWIPE -> {
                    if (step.x != null && step.y != null && step.endX != null && step.endY != null) {
                        swipe(step.x, step.y, step.endX, step.endY, step.duration)
                    } else {
                        false
                    }
                }
                ActionType.INPUT_TEXT -> {
                    if (step.text != null) {
                        inputText(step.text)
                    } else {
                        false
                    }
                }
                ActionType.PRESS_BACK -> goBack()
                ActionType.PRESS_HOME -> goToHome()
                ActionType.PRESS_RECENTS -> showRecentApps()
                ActionType.WAIT -> {
                    Thread.sleep(step.duration)
                    true
                }
                ActionType.CONDITION -> {
                    // 条件判断，由 TaskEngine 处理
                    true
                }
                ActionType.LOOP_START, ActionType.LOOP_END, ActionType.SCREEN_CAPTURE, 
                ActionType.OCR_ANALYZE, ActionType.AI_DECIDE -> {
                    // 这些类型由 TaskEngine 或外部服务处理
                    true
                }
            }
            
            if (!success) {
                retryCount++
                Log.w(TAG, "步骤执行失败，重试 $retryCount/${step.retryCount}")
                if (retryCount <= step.retryCount) {
                    Thread.sleep(DEFAULT_DELAY)
                }
            }
        }
        
        onStepCompleted?.invoke(step, success)
        return success
    }

    /**
     * 异步执行步骤
     */
    fun executeStepAsync(step: TaskStep, callback: (Boolean) -> Unit) {
        handler.post {
            // Kotlin 协程需要在协程作用域中调用 suspend 函数
            // 这里简化处理，直接在新线程执行
            Thread {
                try {
                    // 由于 executeStep 是 suspend 函数，需要重构为非 suspend
                    val result = executeStepSimple(step)
                    callback(result)
                } catch (e: Exception) {
                    Log.e(TAG, "执行步骤异常", e)
                    callback(false)
                }
            }.start()
        }
    }

    /**
     * 简化的步骤执行（非 suspend）
     */
    private fun executeStepSimple(step: TaskStep): Boolean {
        Log.d(TAG, "执行步骤：${step.description}")
        onStepStarted?.invoke(step)
        
        if (step.delay > 0) {
            Thread.sleep(step.delay)
        }
        
        var success = false
        var retryCount = 0
        
        while (retryCount <= step.retryCount && !success) {
            success = executeAction(step)
            
            if (!success) {
                retryCount++
                Log.w(TAG, "步骤执行失败，重试 $retryCount/${step.retryCount}")
                if (retryCount <= step.retryCount) {
                    Thread.sleep(DEFAULT_DELAY)
                }
            }
        }
        
        onStepCompleted?.invoke(step, success)
        return success
    }

    // 屏幕捕获和 OCR/AI 相关服务（由外部注入）
    var screenCaptureManager: com.autoaccessibility.assistant.capture.ScreenCaptureManager? = null
    var ocrService: com.autoaccessibility.assistant.ocr.OcrService? = null
    var aiDecisionService: com.autoaccessibility.assistant.ai.AiDecisionService? = null
    
    /**
     * 执行具体动作
     */
    private fun executeAction(step: TaskStep): Boolean {
        return when (step.actionType) {
            ActionType.CLICK -> {
                if (step.targetText != null) {
                    clickByText(step.targetText)
                } else if (step.x != null && step.y != null) {
                    click(step.x, step.y)
                } else {
                    false
                }
            }
            ActionType.LONG_PRESS -> {
                if (step.targetText != null) {
                    longPressByText(step.targetText, step.duration)
                } else if (step.x != null && step.y != null) {
                    longPress(step.x, step.y, step.duration)
                } else {
                    false
                }
            }
            ActionType.SWIPE -> {
                if (step.x != null && step.y != null && step.endX != null && step.endY != null) {
                    swipe(step.x, step.y, step.endX, step.endY, step.duration)
                } else {
                    false
                }
            }
            ActionType.INPUT_TEXT -> {
                if (step.text != null) {
                    inputText(step.text)
                } else {
                    false
                }
            }
            ActionType.PRESS_BACK -> goBack()
            ActionType.PRESS_HOME -> goToHome()
            ActionType.PRESS_RECENTS -> showRecentApps()
            ActionType.WAIT -> {
                Thread.sleep(step.duration)
                true
            }
            ActionType.CONDITION -> true
            
            // 新增：屏幕捕获
            ActionType.SCREEN_CAPTURE -> {
                captureScreen()
            }
            
            // 新增：OCR 识别
            ActionType.OCR_ANALYZE -> {
                analyzeWithOcr(step)
            }
            
            // 新增：AI 决策
            ActionType.AI_DECIDE -> {
                decideWithAi(step)
            }
            
            // 循环由 TaskEngine 处理
            ActionType.LOOP_START, ActionType.LOOP_END -> true
        }
    }
    
    /**
     * 捕获屏幕截图
     */
    private fun captureScreen(): Boolean {
        Log.d(TAG, "执行屏幕捕获")
        val captureManager = screenCaptureManager ?: run {
            Log.e(TAG, "ScreenCaptureManager 未初始化")
            return false
        }
        
        return try {
            // 使用协程或回调方式获取截图，这里简化处理
            // 实际实现需要根据 ScreenCaptureManager 的具体 API 调整
            Log.w(TAG, "屏幕捕获功能需要完整实现 ScreenCaptureManager")
            true
        } catch (e: Exception) {
            Log.e(TAG, "屏幕捕获失败", e)
            false
        }
    }
    
    /**
     * 执行 OCR 识别
     */
    private fun analyzeWithOcr(step: TaskStep): Boolean {
        Log.d(TAG, "执行 OCR 识别：${step.description}")
        val ocr = ocrService ?: run {
            Log.e(TAG, "OcrService 未初始化")
            return false
        }
        
        return try {
            // 简化实现，实际需要根据具体 API 调整
            Log.w(TAG, "OCR 识别功能需要完整实现")
            true
        } catch (e: Exception) {
            Log.e(TAG, "OCR 识别失败", e)
            false
        }
    }
    
    /**
     * 执行 AI 智能决策
     */
    private fun decideWithAi(step: TaskStep): Boolean {
        Log.d(TAG, "执行 AI 决策：${step.description}")
        val aiService = aiDecisionService ?: run {
            Log.e(TAG, "AiDecisionService 未初始化")
            return false
        }
        
        return try {
            // 简化实现，实际需要根据具体 API 调整
            Log.w(TAG, "AI 决策功能需要完整实现")
            true
        } catch (e: Exception) {
            Log.e(TAG, "AI 决策失败", e)
            false
        }
    }

    /**
     * 停止所有操作
     */
    fun stop() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        Log.d(TAG, "所有操作已停止")
    }
}