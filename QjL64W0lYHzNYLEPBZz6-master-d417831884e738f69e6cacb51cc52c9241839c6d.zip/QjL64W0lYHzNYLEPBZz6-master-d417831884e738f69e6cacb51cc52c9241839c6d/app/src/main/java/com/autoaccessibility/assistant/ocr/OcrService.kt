package com.autoaccessibility.assistant.ocr

import android.util.Log
import com.autoaccessibility.assistant.api.CsdnApiService
import com.autoaccessibility.assistant.api.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

/**
 * OCR 文字识别服务
 * 集成 CSDN OCR API 识别屏幕文字内容
 */
class OcrService {

    companion object {
        private const val TAG = "OcrService"
        private const val OCR_MODEL = "default_ocr"
        
        @Volatile
        private var instance: OcrService? = null
        
        fun getInstance(): OcrService {
            return instance ?: synchronized(this) {
                instance ?: OcrService().also { instance = it }
            }
        }
    }

    private val apiService: CsdnApiService = ApiClient.csdnApiService

    /**
     * 从图片文件识别文字
     */
    suspend fun recognizeFromFile(imageFile: File): OcrResult? {
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "开始识别图片文件：${imageFile.absolutePath}")
                
                val fileBody = imageFile.asRequestBody("image/png".toMediaTypeOrNull())
                val filePart = MultipartBody.Part.createFormData(
                    "image",
                    imageFile.name,
                    fileBody
                )
                
                val modelBody = OCR_MODEL.toRequestBody("text/plain".toMediaTypeOrNull())
                
                val response = apiService.recognizeText("", filePart, null, modelBody)
                
                if (response.isSuccessful && response.body() != null) {
                    val ocrResponse = response.body()!!
                    Log.i(TAG, "OCR 识别成功，内容长度：${ocrResponse.data.length}")
                    
                    OcrResult(
                        success = true,
                        text = ocrResponse.data,
                        requestId = ocrResponse.request_id,
                        errorMessage = null
                    )
                } else {
                    val errorMsg = response.errorBody()?.string() ?: "未知错误"
                    Log.e(TAG, "OCR 识别失败：$errorMsg")
                    
                    OcrResult(
                        success = false,
                        text = "",
                        requestId = null,
                        errorMessage = "API 请求失败：$errorMsg"
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "OCR 识别异常", e)
                OcrResult(
                    success = false,
                    text = "",
                    requestId = null,
                    errorMessage = "识别异常：${e.message}"
                )
            }
        }
    }

    /**
     * 从 Base64 字符串识别文字
     */
    suspend fun recognizeFromBase64(base64Image: String): OcrResult? {
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "开始识别 Base64 图片")
                
                // 将 Base64 转换为临时文件
                val decodedBytes = android.util.Base64.decode(base64Image, android.util.Base64.DEFAULT)
                val tempFile = File.createTempFile("ocr_", ".png")
                
                try {
                    tempFile.writeBytes(decodedBytes)
                    recognizeFromFile(tempFile)
                } finally {
                    tempFile.delete()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Base64 识别异常", e)
                OcrResult(
                    success = false,
                    text = "",
                    requestId = null,
                    errorMessage = "Base64 解码失败：${e.message}"
                )
            }
        }
    }

    /**
     * 从图片 URL 识别文字
     */
    suspend fun recognizeFromUrl(imageUrl: String): OcrResult? {
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "开始识别图片 URL：$imageUrl")
                
                val urlBody = imageUrl.toRequestBody("text/plain".toMediaTypeOrNull())
                val modelBody = OCR_MODEL.toRequestBody("text/plain".toMediaTypeOrNull())
                
                // 使用 recognizeText 方法，通过 url 参数传递图片地址
                val response = apiService.recognizeText("", null, urlBody, modelBody)
                
                if (response.isSuccessful && response.body() != null) {
                    val ocrResponse = response.body()!!
                    Log.i(TAG, "URL 图片识别成功")
                    
                    OcrResult(
                        success = true,
                        text = ocrResponse.data,
                        requestId = ocrResponse.request_id,
                        errorMessage = null
                    )
                } else {
                    val errorMsg = response.errorBody()?.string() ?: "未知错误"
                    Log.e(TAG, "URL 图片识别失败：$errorMsg")
                    
                    OcrResult(
                        success = false,
                        text = "",
                        requestId = null,
                        errorMessage = "API 请求失败：$errorMsg"
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "URL 识别异常", e)
                OcrResult(
                    success = false,
                    text = "",
                    requestId = null,
                    errorMessage = "识别异常：${e.message}"
                )
            }
        }
    }

    /**
     * 解析 OCR 结果，提取结构化信息（如价格、商品名等）
     */
    fun parseStructuredData(ocrText: String): Map<String, Any?> {
        val result = mutableMapOf<String, Any?>()
        
        // 按行分割
        val lines = ocrText.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        
        // 尝试提取价格信息
        val prices = mutableListOf<Double>()
        val pricePattern = Regex("(\\d+\\.?\\d*)\\s*元|￥\\s*(\\d+\\.?\\d*)|(\\d+\\.?\\d*)\\s*RMB")
        
        lines.forEach { line ->
            pricePattern.findAll(line).forEach { match ->
                val priceStr = match.groupValues.drop(1).find { it.isNotEmpty() } ?: ""
                try {
                    val price = priceStr.toDouble()
                    prices.add(price)
                } catch (e: NumberFormatException) {
                    // 忽略无效价格
                }
            }
        }
        
        result["prices"] = prices
        result["maxPrice"] = prices.maxOrNull()
        result["lines"] = lines
        result["lineCount"] = lines.size
        
        return result
    }

    /**
     * 销毁服务
     */
    fun destroy() {
        instance = null
        Log.d(TAG, "OCR 服务已销毁")
    }
}

/**
 * OCR 识别结果
 */
data class OcrResult(
    val success: Boolean,
    val text: String,
    val requestId: String?,
    val errorMessage: String?
) {
    /**
     * 获取识别结果的简要描述
     */
    fun getSummary(): String {
        return if (success) {
            "识别成功，共 ${text.length} 个字符"
        } else {
            "识别失败：$errorMessage"
        }
    }
    
    /**
     * 获取前 N 行内容
     */
    fun getFirstLines(n: Int = 5): String {
        return text.split("\n").take(n).joinToString("\n")
    }
}