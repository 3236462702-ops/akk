package com.autoaccessibility.assistant.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.data.SettingsRepository
import com.autoaccessibility.assistant.model.OrderType
import com.autoaccessibility.assistant.model.RegionFilterMode
import com.autoaccessibility.assistant.model.UserSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * 用户设置界面
 * 提供可视化配置界面，支持实时预览和测试
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    
    // UI 控件引用
    private lateinit var switchAutoGrab: SwitchCompat
    private lateinit var seekBarRefreshInterval: SeekBar
    private lateinit var textRefreshIntervalValue: android.widget.TextView
    
    // 价格过滤相关
    private lateinit var checkPriceRange: CheckBox
    private lateinit var switchPriceFilter: SwitchCompat
    private lateinit var editMinPrice: EditText
    private lateinit var editMaxPrice: EditText
    
    // 接驾距离相关
    private lateinit var checkDistance: CheckBox
    private lateinit var switchDistanceFilter: SwitchCompat
    private lateinit var editMaxPickupDistance: EditText
    
    // 行程距离相关
    private lateinit var checkTripDistance: CheckBox
    private lateinit var switchTripDistanceFilter: SwitchCompat
    private lateinit var editMinTripDistance: EditText
    private lateinit var editMaxTripDistance: EditText
    
    // 订单类型相关
    private lateinit var checkOrderTypes: CheckBox
    private lateinit var gridOrderTypes: GridLayout
    private lateinit var btnSelectAll: Button
    private lateinit var btnClearAll: Button
    private val orderTypeCheckboxes = mutableMapOf<OrderType, CheckBox>()
    
    // 点击延迟相关
    private lateinit var checkClickDelay: CheckBox
    private lateinit var editFixedDelay: EditText
    private lateinit var switchRandomDelay: SwitchCompat
    private lateinit var textDelayPreview: android.widget.TextView
    
    // 刷新延迟相关
    private lateinit var checkRefreshDelay: CheckBox
    private lateinit var editRefreshFixedDelay: EditText
    private lateinit var switchRefreshRandomDelay: SwitchCompat
    private lateinit var textRefreshDelayPreview: android.widget.TextView
    
    // 保存/重置按钮
    private lateinit var btnSave: Button
    private lateinit var btnReset: Button
    
    // 区域过滤相关
    private lateinit var checkExcludeRegion: CheckBox
    private lateinit var checkIncludeRegion: CheckBox
    private lateinit var layoutExcludeOptions: android.widget.LinearLayout
    private lateinit var layoutIncludeOptions: android.widget.LinearLayout
    private lateinit var btnExcludeDistricts: Button
    private lateinit var btnIncludeDistricts: Button
    private lateinit var textExcludePreview: android.widget.TextView
    private lateinit var textIncludePreview: android.widget.TextView
    private val districtCheckboxes = mutableMapOf<String, CheckBox>()
    private val allChongqingDistricts = listOf(
        "渝中区", "江北区", "南岸区", "九龙坡区", "沙坪坝区", "大渡口区", "北碚区", "渝北区", "巴南区",
        "万州区", "涪陵区", "永川区", "合川区", "江津区", "长寿区", "南川区", "綦江区", "大足区",
        "璧山区", "铜梁区", "潼南区", "荣昌区", "开州区", "梁平区", "武隆区", "城口县", "丰都县",
        "垫江县", "忠县", "云阳县", "奉节县", "巫山县", "巫溪县", "石柱县", "秀山县", "酉阳县", "彭水县",
        "两江新区"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        // 初始化 Repository
        settingsRepository = SettingsRepository.getInstance(this)
        
        // 初始化 settingsFlow
        settingsFlow = MutableStateFlow(UserSettings.getDefault())
        
        // 绑定 UI 控件
        bindViews()
        
        // 加载当前设置
        loadCurrentSettings()
        
        // 设置监听器
        setupListeners()
    }

    /**
     * 绑定 UI 控件
     */
    private fun bindViews() {
        switchAutoGrab = findViewById(R.id.switchAutoGrab)
        seekBarRefreshInterval = findViewById(R.id.seekBarRefreshInterval)
        textRefreshIntervalValue = findViewById(R.id.textRefreshIntervalValue)
        
        // 价格过滤相关
        checkPriceRange = findViewById(R.id.checkPriceRange)
        switchPriceFilter = findViewById(R.id.switchPriceFilter)
        editMinPrice = findViewById(R.id.editMinPrice)
        editMaxPrice = findViewById(R.id.editMaxPrice)
        
        // 接驾距离相关
        checkDistance = findViewById(R.id.checkDistance)
        switchDistanceFilter = findViewById(R.id.switchDistanceFilter)
        editMaxPickupDistance = findViewById(R.id.editMaxPickupDistance)
        
        // 行程距离相关
        checkTripDistance = findViewById(R.id.checkTripDistance)
        switchTripDistanceFilter = findViewById(R.id.switchTripDistanceFilter)
        editMinTripDistance = findViewById(R.id.editMinTripDistance)
        editMaxTripDistance = findViewById(R.id.editMaxTripDistance)
        
        // 订单类型相关
        checkOrderTypes = findViewById(R.id.checkOrderTypes)
        gridOrderTypes = findViewById(R.id.gridOrderTypes)
        btnSelectAll = findViewById(R.id.btnSelectAll)
        btnClearAll = findViewById(R.id.btnClearAll)
        
        // 点击延迟相关
        checkClickDelay = findViewById(R.id.checkClickDelay)
        editFixedDelay = findViewById(R.id.editFixedDelay)
        switchRandomDelay = findViewById(R.id.switchRandomDelay)
        textDelayPreview = findViewById(R.id.textDelayPreview)
        
        // 刷新延迟相关
        checkRefreshDelay = findViewById(R.id.checkRefreshDelay)
        editRefreshFixedDelay = findViewById(R.id.editRefreshFixedDelay)
        switchRefreshRandomDelay = findViewById(R.id.switchRefreshRandomDelay)
        textRefreshDelayPreview = findViewById(R.id.textRefreshDelayPreview)
        
        // 初始化订单类型复选框
        initOrderTypeCheckboxes()
        
        // 保存/重置按钮
        btnSave = findViewById(R.id.btnSave)
        btnReset = findViewById(R.id.btnReset)
        
        // 初始化区域过滤相关
        checkExcludeRegion = findViewById(R.id.checkExcludeRegion)
        checkIncludeRegion = findViewById(R.id.checkIncludeRegion)
        layoutExcludeOptions = findViewById(R.id.layoutExcludeOptions)
        layoutIncludeOptions = findViewById(R.id.layoutIncludeOptions)
        btnExcludeDistricts = findViewById(R.id.btnExcludeDistricts)
        btnIncludeDistricts = findViewById(R.id.btnIncludeDistricts)
        textExcludePreview = findViewById(R.id.textExcludePreview)
        textIncludePreview = findViewById(R.id.textIncludePreview)
        
        initDistrictDialog()
    }

    /**
     * 初始化区域选择对话框
     */
    private fun initDistrictDialog() {
        // 动态创建复选框列表（用于对话框）
        allChongqingDistricts.forEach { district ->
            val checkBox = CheckBox(this)
            checkBox.text = district
            districtCheckboxes[district] = checkBox
        }
    }
    
    /**
     * 显示区域选择对话框
     */
    private fun showDistrictDialog(mode: String) {
        val isExclude = mode == "exclude"
        val currentSelection = if (isExclude) {
            getCurrentSettings().parseExcludedDistricts()
        } else {
            getCurrentSettings().parseIncludedDistricts()
        }
        
        // 创建 AlertDialog
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle(if (isExclude) "选择不接区域" else "选择只接区域")
        
        // 创建滚动容器
        val scrollView = android.widget.ScrollView(this)
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(50, 20, 50, 20)
        }
        
        // 添加所有区县复选框
        allChongqingDistricts.forEach { district ->
            val checkBox = CheckBox(this).apply {
                text = district
                isChecked = currentSelection.contains(district)
                setPadding(0, 15, 0, 15)
            }
            layout.addView(checkBox)
        }
        
        scrollView.addView(layout)
        builder.setView(scrollView)
        
        // 全选按钮
        val selectAllBtn = Button(this).apply {
            text = "全选"
            setOnClickListener {
                layout.childCount.apply {
                    for (i in 0 until this) {
                        val view = layout.getChildAt(i)
                        if (view is CheckBox) view.isChecked = true
                    }
                }
            }
        }
        
        // 清空按钮
        val clearAllBtn = Button(this).apply {
            text = "清空"
            setOnClickListener {
                layout.childCount.apply {
                    for (i in 0 until this) {
                        val view = layout.getChildAt(i)
                        if (view is CheckBox) view.isChecked = false
                    }
                }
            }
        }
        
        // 按钮布局
        val buttonLayout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            setPadding(20, 20, 20, 20)
            gravity = android.view.Gravity.CENTER
            addView(selectAllBtn, android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 20
                marginEnd = 10
            })
            addView(clearAllBtn, android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 10
                marginEnd = 20
            })
        }
        
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(scrollView)
            addView(buttonLayout)
        }
        
        builder.setView(container)
        
        // 确定按钮
        builder.setPositiveButton("确定") { dialog, _ ->
            val selectedDistricts = mutableListOf<String>()
            layout.childCount.apply {
                for (i in 0 until this) {
                    val view = layout.getChildAt(i)
                    if (view is CheckBox && view.isChecked) {
                        selectedDistricts.add(view.text.toString())
                    }
                }
            }
            
            // 更新预览文本
            if (isExclude) {
                updateExcludePreview(selectedDistricts)
            } else {
                updateIncludePreview(selectedDistricts)
            }
            
            dialog.dismiss()
        }
        
        // 取消按钮
        builder.setNegativeButton("取消") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
    
    /**
     * 更新不接区域预览文本
     */
    private fun updateExcludePreview(districts: List<String>) {
        if (districts.isEmpty()) {
            textExcludePreview.text = "未选择不接区域"
            textExcludePreview.setTextColor(Color.parseColor("#999999"))
        } else {
            textExcludePreview.text = "已选：${districts.take(3).joinToString("、")}${if (districts.size > 3) "等${districts.size}个" else ""}"
            textExcludePreview.setTextColor(Color.parseColor("#FF5722"))
        }
    }
    
    /**
     * 更新只接区域预览文本
     */
    private fun updateIncludePreview(districts: List<String>) {
        if (districts.isEmpty()) {
            textIncludePreview.text = "未选择只接区域"
            textIncludePreview.setTextColor(Color.parseColor("#999999"))
        } else {
            textIncludePreview.text = "已选：${districts.take(3).joinToString("、")}${if (districts.size > 3) "等${districts.size}个" else ""}"
            textIncludePreview.setTextColor(Color.parseColor("#4CAF50"))
        }
    }
    
    /**
     * 获取当前设置（用于对话框）
     */
    private fun getCurrentSettings(): UserSettings {
        return settingsFlow.value ?: UserSettings.getDefault()
    }
    
    private lateinit var settingsFlow: MutableStateFlow<UserSettings>
    
    /**
     * 初始化订单类型复选框
     */
    private fun initOrderTypeCheckboxes() {
        gridOrderTypes.removeAllViews()
        orderTypeCheckboxes.clear()
        
        OrderType.entries.forEach { orderType ->
            val cardView = LayoutInflater.from(this)
                .inflate(R.layout.item_order_type_checkbox, gridOrderTypes, false) as CardView
            
            val checkBox = cardView.findViewById<CheckBox>(R.id.chkOrderType)
            checkBox.text = orderType.displayName
            
            // 设置颜色
            val bgColor = when (orderType) {
                OrderType.CARPOOL -> Color.parseColor("#E8F5E9")
                OrderType.EXPRESS -> Color.parseColor("#E3F2FD")
                OrderType.PREMIUM -> Color.parseColor("#FFF3E0")
                OrderType.SMALL_CARGO -> Color.parseColor("#F3E5F5")
                OrderType.RIDE_HAILING -> Color.parseColor("#FFEBEE")
                OrderType.USER_BID -> Color.parseColor("#E0F7FA")
                OrderType.DISCOUNT -> Color.parseColor("#FFFDE7")
                OrderType.LONG_DISTANCE -> Color.parseColor("#ECEFF1")
            }
            cardView.setCardBackgroundColor(bgColor)
            
            orderTypeCheckboxes[orderType] = checkBox
            gridOrderTypes.addView(cardView)
        }
    }

    /**
     * 加载当前设置
     */
    private fun loadCurrentSettings() {
        lifecycleScope.launch {
            try {
                val settings = settingsRepository.getSettings()
                
                // 总开关
                switchAutoGrab.isChecked = settings.autoGrabEnabled
                
                // 刷新速度（SeekBar: 0-7 对应 3-10 秒）
                val progress = settings.refreshIntervalSeconds - 3
                seekBarRefreshInterval.progress = progress.coerceIn(0, 7)
                updateRefreshIntervalText(settings.refreshIntervalSeconds)
                
                // 价格过滤（勾选框控制启用）
                checkPriceRange.isChecked = settings.enablePriceFilter
                editMinPrice.setText(settings.minPrice.toString())
                editMaxPrice.setText(settings.maxPrice.toString())
                updatePriceOptionsEnabled()
                
                // 接驾距离（勾选框控制启用）
                checkDistance.isChecked = settings.enableDistanceFilter
                editMaxPickupDistance.setText(settings.maxPickupDistance.toString())
                updateDistanceOptionsEnabled()
                
                // 行程距离（勾选框控制启用）
                checkTripDistance.isChecked = settings.enableTripDistanceFilter
                editMinTripDistance.setText(settings.minTripDistance.toString())
                editMaxTripDistance.setText(settings.maxTripDistance.toString())
                updateTripDistanceOptionsEnabled()
                
                // 订单类型（勾选框控制启用）
                checkOrderTypes.isChecked = settings.enableOrderTypeFilter
                loadOrderTypes(settings.parseSelectedOrderTypes())
                updateOrderTypeOptionsEnabled()
                
                // 点击延迟设置（勾选框控制启用）
                checkClickDelay.isChecked = settings.clickDelayRandom || settings.clickDelayFixed != UserSettings.DELAY_DEFAULT_MS
                editFixedDelay.setText(settings.clickDelayFixed.toString())
                switchRandomDelay.isChecked = settings.clickDelayRandom
                updateDelayPreview(settings)
                updateDelayInputEnabled(!settings.clickDelayRandom && checkClickDelay.isChecked)
                
                // 刷新延迟设置（勾选框控制启用）
                checkRefreshDelay.isChecked = settings.refreshDelayRandom || settings.refreshDelayFixed != UserSettings.REFRESH_DELAY_DEFAULT_MS
                editRefreshFixedDelay.setText(settings.refreshDelayFixed.toString())
                switchRefreshRandomDelay.isChecked = settings.refreshDelayRandom
                updateRefreshDelayPreview(settings)
                updateRefreshDelayInputEnabled(!settings.refreshDelayRandom && checkRefreshDelay.isChecked)
                
                // 区域过滤设置（使用新的布尔值字段）
                checkExcludeRegion.isChecked = settings.excludeRegionEnabled
                checkIncludeRegion.isChecked = settings.includeRegionEnabled
                updateExcludeOptionsVisibility()
                updateIncludeOptionsVisibility()
                updateExcludePreview(settings.parseExcludedDistricts())
                updateIncludePreview(settings.parseIncludedDistricts())
                
                // 更新 settingsFlow
                settingsFlow.value = settings
                
            } catch (e: Exception) {
                Toast.makeText(this@SettingsActivity, "加载设置失败：${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * 加载订单类型选择状态
     */
    private fun loadOrderTypes(selectedTypes: List<String>) {
        orderTypeCheckboxes.forEach { (orderType, checkBox) ->
            checkBox.isChecked = selectedTypes.contains(orderType.name)
        }
    }

    /**
     * 获取选中的订单类型
     */
    private fun getSelectedOrderTypes(): List<String> {
        return orderTypeCheckboxes
            .filter { it.value.isChecked }
            .map { it.key.name }
    }

    /**
     * 更新点击延迟预览文本
     */
    private fun updateDelayPreview(settings: UserSettings) {
        if (switchRandomDelay.isChecked) {
            textDelayPreview.text = "当前延迟：200ms-2s 随机"
            textDelayPreview.setTextColor(Color.parseColor("#FF9800"))
        } else {
            val delay = editFixedDelay.text.toString().toIntOrNull() ?: UserSettings.DELAY_DEFAULT_MS
            textDelayPreview.text = "当前延迟：${delay}ms"
            textDelayPreview.setTextColor(Color.parseColor("#4CAF50"))
        }
    }
    
    /**
     * 更新点击延迟输入框启用状态
     */
    private fun updateDelayInputEnabled(enabled: Boolean) {
        val actuallyEnabled = enabled && checkClickDelay.isChecked
        editFixedDelay.isEnabled = actuallyEnabled
        switchRandomDelay.isEnabled = actuallyEnabled
        editFixedDelay.alpha = if (actuallyEnabled) 1.0f else 0.5f
        switchRandomDelay.alpha = if (actuallyEnabled) 1.0f else 0.5f
    }
    
    /**
     * 更新刷新延迟预览文本
     */
    private fun updateRefreshDelayPreview(settings: UserSettings) {
        if (switchRefreshRandomDelay.isChecked) {
            textRefreshDelayPreview.text = "当前延迟：2s-5s 随机"
            textRefreshDelayPreview.setTextColor(Color.parseColor("#FF9800"))
        } else {
            val delay = editRefreshFixedDelay.text.toString().toIntOrNull() ?: UserSettings.REFRESH_DELAY_DEFAULT_MS
            val delaySec = if (delay >= 1000) "${delay / 1000}s" else "${delay}ms"
            textRefreshDelayPreview.text = "当前延迟：$delaySec"
            textRefreshDelayPreview.setTextColor(Color.parseColor("#4CAF50"))
        }
    }
    
    /**
     * 更新刷新延迟输入框启用状态
     */
    private fun updateRefreshDelayInputEnabled(enabled: Boolean) {
        val actuallyEnabled = enabled && checkRefreshDelay.isChecked
        editRefreshFixedDelay.isEnabled = actuallyEnabled
        switchRefreshRandomDelay.isEnabled = actuallyEnabled
        editRefreshFixedDelay.alpha = if (actuallyEnabled) 1.0f else 0.5f
        switchRefreshRandomDelay.alpha = if (actuallyEnabled) 1.0f else 0.5f
    }
    
    /**
     * 设置监听器
     */
    private fun setupListeners() {
        // 刷新速度 SeekBar 变化监听
        seekBarRefreshInterval.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val seconds = progress + 3
                updateRefreshIntervalText(seconds)
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // 价格过滤勾选框监听
        checkPriceRange.setOnCheckedChangeListener { _, _ ->
            updatePriceOptionsEnabled()
        }
        
        // 接驾距离勾选框监听
        checkDistance.setOnCheckedChangeListener { _, _ ->
            updateDistanceOptionsEnabled()
        }
        
        // 行程距离勾选框监听
        checkTripDistance.setOnCheckedChangeListener { _, _ ->
            updateTripDistanceOptionsEnabled()
        }
        
        // 订单类型勾选框监听
        checkOrderTypes.setOnCheckedChangeListener { _, _ ->
            updateOrderTypeOptionsEnabled()
        }
        
        // 点击延迟勾选框监听
        checkClickDelay.setOnCheckedChangeListener { _, _ ->
            updateDelayInputEnabled(!switchRandomDelay.isChecked && checkClickDelay.isChecked)
        }
        
        // 刷新延迟勾选框监听
        checkRefreshDelay.setOnCheckedChangeListener { _, _ ->
            updateRefreshDelayInputEnabled(!switchRefreshRandomDelay.isChecked && checkRefreshDelay.isChecked)
        }
        
        // 全选按钮
        btnSelectAll.setOnClickListener {
            orderTypeCheckboxes.values.forEach { it.isChecked = true }
        }
        
        // 清空按钮
        btnClearAll.setOnClickListener {
            orderTypeCheckboxes.values.forEach { it.isChecked = false }
        }
        
        // 保存按钮
        btnSave.setOnClickListener {
            saveSettings()
        }
        
        // 重置按钮
        btnReset.setOnClickListener {
            resetToDefault()
        }
        
        // 点击延迟随机开关监听
        switchRandomDelay.setOnCheckedChangeListener { _, isChecked ->
            updateDelayInputEnabled(!isChecked && checkClickDelay.isChecked)
            updateDelayPreview(UserSettings.getDefault()) // 临时预览
        }
        
        // 点击延迟固定输入框变化监听
        editFixedDelay.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (!switchRandomDelay.isChecked) {
                    updateDelayPreview(UserSettings.getDefault()) // 临时预览
                }
            }
        })
        
        // 刷新延迟随机开关监听
        switchRefreshRandomDelay.setOnCheckedChangeListener { _, isChecked ->
            updateRefreshDelayInputEnabled(!isChecked && checkRefreshDelay.isChecked)
            updateRefreshDelayPreview(UserSettings.getDefault()) // 临时预览
        }
        
        // 不接区域勾选框监听（互斥逻辑）
        checkExcludeRegion.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // 勾选不接区域时，取消只接区域的勾选
                if (checkIncludeRegion.isChecked) {
                    checkIncludeRegion.isChecked = false
                    updateIncludeOptionsVisibility()
                }
                updateExcludeOptionsVisibility()
            } else {
                // 取消勾选时隐藏选项
                updateExcludeOptionsVisibility()
            }
        }
        
        // 只接区域勾选框监听（互斥逻辑）
        checkIncludeRegion.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // 勾选只接区域时，取消不接区域的勾选
                if (checkExcludeRegion.isChecked) {
                    checkExcludeRegion.isChecked = false
                    updateExcludeOptionsVisibility()
                }
                updateIncludeOptionsVisibility()
            } else {
                // 取消勾选时隐藏选项
                updateIncludeOptionsVisibility()
            }
        }
        
        // 不接区域按钮
        btnExcludeDistricts.setOnClickListener {
            showDistrictDialog("exclude")
        }
        
        // 只接区域按钮
        btnIncludeDistricts.setOnClickListener {
            showDistrictDialog("include")
        }
        
        // 刷新延迟固定输入框变化监听
        editRefreshFixedDelay.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (!switchRefreshRandomDelay.isChecked) {
                    updateRefreshDelayPreview(UserSettings.getDefault()) // 临时预览
                }
            }
        })
    }

    /**
     * 更新刷新速度显示文本
     */
    private fun updateRefreshIntervalText(seconds: Int) {
        textRefreshIntervalValue.text = "当前：$seconds 秒"
    }

    /**
     * 更新不接区域选项可见性
     */
    private fun updateExcludeOptionsVisibility() {
        layoutExcludeOptions.visibility = if (checkExcludeRegion.isChecked) android.view.View.VISIBLE else android.view.View.GONE
    }
    
    /**
     * 更新只接区域选项可见性
     */
    private fun updateIncludeOptionsVisibility() {
        layoutIncludeOptions.visibility = if (checkIncludeRegion.isChecked) android.view.View.VISIBLE else android.view.View.GONE
    }
    
    /**
     * 保存设置
     */
    private fun saveSettings() {
        lifecycleScope.launch {
            try {
                // 获取输入值
                val refreshInterval = seekBarRefreshInterval.progress + 3
                
                // 价格过滤（根据勾选框状态）
                val enablePrice = checkPriceRange.isChecked
                val minPrice = if (enablePrice) editMinPrice.text.toString().toDoubleOrNull() ?: 0.0 else 0.0
                val maxPrice = if (enablePrice) editMaxPrice.text.toString().toDoubleOrNull() ?: 9999.0 else 9999.0
                
                // 接驾距离（根据勾选框状态）
                val enableDistance = checkDistance.isChecked
                val maxPickupDistance = if (enableDistance) editMaxPickupDistance.text.toString().toDoubleOrNull() ?: 10.0 else 10.0
                
                // 行程距离（根据勾选框状态）
                val enableTripDistance = checkTripDistance.isChecked
                val minTripDistance = if (enableTripDistance) editMinTripDistance.text.toString().toDoubleOrNull() ?: 0.0 else 0.0
                val maxTripDistance = if (enableTripDistance) editMaxTripDistance.text.toString().toDoubleOrNull() ?: 999.0 else 999.0
                
                // 订单类型（根据勾选框状态）
                val enableOrderType = checkOrderTypes.isChecked
                val selectedOrderTypes = if (enableOrderType) getSelectedOrderTypes() else OrderType.entries.map { it.name }
                
                // 验证至少选择一个订单类型
                if (selectedOrderTypes.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请至少选择一种订单类型", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                // 验证输入
                if (!UserSettings.isValidRefreshInterval(refreshInterval)) {
                    Toast.makeText(this@SettingsActivity, "刷新间隔必须在 3-10 秒之间", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                if (!UserSettings.isValidPriceRange(minPrice, maxPrice)) {
                    Toast.makeText(this@SettingsActivity, "价格区间不合法", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                if (!UserSettings.isValidDistance(maxPickupDistance) || 
                    !UserSettings.isValidDistance(minTripDistance) ||
                    !UserSettings.isValidDistance(maxTripDistance)) {
                    Toast.makeText(this@SettingsActivity, "距离值不合法", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                // 点击延迟设置（根据勾选框状态）
                val enableClickDelay = checkClickDelay.isChecked
                val isRandomDelay = switchRandomDelay.isChecked
                val fixedDelay = if (enableClickDelay) editFixedDelay.text.toString().toIntOrNull() ?: UserSettings.DELAY_DEFAULT_MS else UserSettings.DELAY_DEFAULT_MS
                
                // 验证点击固定延迟范围
                if (enableClickDelay && !isRandomDelay && !UserSettings.isValidClickDelay(fixedDelay)) {
                    Toast.makeText(this@SettingsActivity, "点击固定延迟必须在 200-10000ms 之间", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                // 刷新延迟设置（根据勾选框状态）
                val enableRefreshDelay = checkRefreshDelay.isChecked
                val isRefreshRandomDelay = switchRefreshRandomDelay.isChecked
                val refreshFixedDelay = if (enableRefreshDelay) editRefreshFixedDelay.text.toString().toIntOrNull() ?: UserSettings.REFRESH_DELAY_DEFAULT_MS else UserSettings.REFRESH_DELAY_DEFAULT_MS
                
                // 验证刷新固定延迟范围（1-10 秒）
                if (enableRefreshDelay && !isRefreshRandomDelay && !UserSettings.isValidRefreshDelay(refreshFixedDelay)) {
                    Toast.makeText(this@SettingsActivity, "刷新固定延迟必须在 1000-10000ms 之间", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                // 获取区域过滤设置（根据勾选框状态判断）
                val excludeRegionEnabled = checkExcludeRegion.isChecked
                val includeRegionEnabled = checkIncludeRegion.isChecked
                
                // 解析当前选择的区域列表（从预览文本提取）
                val excludedDistricts = if (excludeRegionEnabled) {
                    parseDistrictsFromPreview(textExcludePreview.text.toString())
                } else {
                    emptyList()
                }
                val includedDistricts = if (includeRegionEnabled) {
                    parseDistrictsFromPreview(textIncludePreview.text.toString())
                } else {
                    emptyList()
                }
                
                // 构建新设置（使用新的布尔值字段）
                val newSettings = UserSettings(
                    id = 0,
                    refreshIntervalSeconds = refreshInterval,
                    enablePriceFilter = enablePrice,
                    minPrice = minPrice,
                    maxPrice = maxPrice,
                    enableDistanceFilter = enableDistance,
                    maxPickupDistance = maxPickupDistance,
                    enableTripDistanceFilter = enableTripDistance,
                    minTripDistance = minTripDistance,
                    maxTripDistance = maxTripDistance,
                    autoGrabEnabled = switchAutoGrab.isChecked,
                    enableOrderTypeFilter = enableOrderType,
                    selectedOrderTypes = selectedOrderTypes.joinToString(","),
                    clickDelayFixed = fixedDelay,
                    clickDelayRandom = isRandomDelay && enableClickDelay,
                    refreshDelayFixed = refreshFixedDelay,
                    refreshDelayRandom = isRefreshRandomDelay && enableRefreshDelay,
                    excludeRegionEnabled = excludeRegionEnabled,
                    includeRegionEnabled = includeRegionEnabled,
                    excludedDistricts = excludedDistricts.joinToString(","),
                    includedDistricts = includedDistricts.joinToString(",")
                )
                
                // 保存到数据库
                settingsRepository.saveSettings(newSettings)
                
                Toast.makeText(this@SettingsActivity, "设置已保存", Toast.LENGTH_SHORT).show()
                
            } catch (e: Exception) {
                Toast.makeText(this@SettingsActivity, "保存失败：${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * 从预览文本解析区域列表
     */
    private fun parseDistrictsFromPreview(previewText: String): List<String> {
        // 预览文本格式："已选：渝中区、江北区等 5 个" 或 "未选择不接区域"
        if (previewText.startsWith("未选择")) {
            return emptyList()
        }
        
        // 提取"已选："和"等"之间的内容
        val startIdx = previewText.indexOf("已选：")
        if (startIdx == -1) return emptyList()
        
        val content = previewText.substring(startIdx + 3)
        val endIdx = content.indexOf("等")
        val districtsStr = if (endIdx != -1) {
            content.substring(0, endIdx)
        } else {
            content
        }
        
        return districtsStr.split("、").map { it.trim() }.filter { it.isNotEmpty() }
    }
    
    /**
     * 重置为默认值
     */
    private fun resetToDefault() {
        val default = UserSettings.getDefault()
        
        switchAutoGrab.isChecked = default.autoGrabEnabled
        seekBarRefreshInterval.progress = default.refreshIntervalSeconds - 3
        updateRefreshIntervalText(default.refreshIntervalSeconds)
        
        // 重置所有勾选框为未勾选状态
        checkPriceRange.isChecked = false
        checkDistance.isChecked = false
        checkTripDistance.isChecked = false
        checkOrderTypes.isChecked = false
        checkClickDelay.isChecked = false
        checkRefreshDelay.isChecked = false
        
        // 重置输入框为默认值
        editMinPrice.setText(default.minPrice.toString())
        editMaxPrice.setText(default.maxPrice.toString())
        editMaxPickupDistance.setText(default.maxPickupDistance.toString())
        editMinTripDistance.setText(default.minTripDistance.toString())
        editMaxTripDistance.setText(default.maxTripDistance.toString())
        editFixedDelay.setText(default.clickDelayFixed.toString())
        editRefreshFixedDelay.setText(default.refreshDelayFixed.toString())
        
        // 重置随机延迟开关
        switchRandomDelay.isChecked = default.clickDelayRandom
        switchRefreshRandomDelay.isChecked = default.refreshDelayRandom
        
        // 更新所有选项的启用状态
        updateAllOptionsVisibility()
        updateDelayPreview(default)
        updateDelayInputEnabled(false)
        updateRefreshDelayPreview(default)
        updateRefreshDelayInputEnabled(false)
        
        // 重置订单类型为全选
        orderTypeCheckboxes.values.forEach { it.isChecked = true }
        
        // 重置区域过滤（都不勾选）
        checkExcludeRegion.isChecked = false
        checkIncludeRegion.isChecked = false
        updateExcludeOptionsVisibility()
        updateIncludeOptionsVisibility()
        updateExcludePreview(default.parseExcludedDistricts())
        updateIncludePreview(default.parseIncludedDistricts())
        
        Toast.makeText(this, "已重置为默认设置", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * 更新所有选项的可见性和启用状态
     */
    private fun updateAllOptionsVisibility() {
        updatePriceOptionsEnabled()
        updateDistanceOptionsEnabled()
        updateTripDistanceOptionsEnabled()
        updateOrderTypeOptionsEnabled()
        updateDelayInputEnabled(!switchRandomDelay.isChecked && checkClickDelay.isChecked)
        updateRefreshDelayInputEnabled(!switchRefreshRandomDelay.isChecked && checkRefreshDelay.isChecked)
    }
    
    /**
     * 更新价格过滤选项启用状态
     */
    private fun updatePriceOptionsEnabled() {
        val enabled = checkPriceRange.isChecked
        editMinPrice.isEnabled = enabled
        editMaxPrice.isEnabled = enabled
        editMinPrice.alpha = if (enabled) 1.0f else 0.5f
        editMaxPrice.alpha = if (enabled) 1.0f else 0.5f
    }
    
    /**
     * 更新接驾距离选项启用状态
     */
    private fun updateDistanceOptionsEnabled() {
        val enabled = checkDistance.isChecked
        editMaxPickupDistance.isEnabled = enabled
        editMaxPickupDistance.alpha = if (enabled) 1.0f else 0.5f
    }
    
    /**
     * 更新行程距离选项启用状态
     */
    private fun updateTripDistanceOptionsEnabled() {
        val enabled = checkTripDistance.isChecked
        editMinTripDistance.isEnabled = enabled
        editMaxTripDistance.isEnabled = enabled
        editMinTripDistance.alpha = if (enabled) 1.0f else 0.5f
        editMaxTripDistance.alpha = if (enabled) 1.0f else 0.5f
    }
    
    /**
     * 更新订单类型选项启用状态
     */
    private fun updateOrderTypeOptionsEnabled() {
        val enabled = checkOrderTypes.isChecked
        gridOrderTypes.isEnabled = enabled
        gridOrderTypes.alpha = if (enabled) 1.0f else 0.5f
        btnSelectAll.isEnabled = enabled
        btnClearAll.isEnabled = enabled
    }
}