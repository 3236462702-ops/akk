package com.autoaccessibility.assistant.config

import android.content.Context
import android.content.SharedPreferences

/**
 * 验证管理器
 * 负责管理验证状态，避免重复验证
 */
class VerificationManager private constructor(context: Context) {

    companion object {
        private const val PREFS_NAME = "verification_prefs"
        private const val KEY_IS_VERIFIED = "is_verified"
        private const val KEY_VERIFY_TIME = "verify_time"
        
        @Volatile
        private var instance: VerificationManager? = null

        fun getInstance(context: Context): VerificationManager {
            return instance ?: synchronized(this) {
                instance ?: VerificationManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * 检查是否已验证
     * @return true 表示已验证，false 表示需要验证
     */
    fun isVerified(): Boolean {
        return prefs.getBoolean(KEY_IS_VERIFIED, false)
    }

    /**
     * 设置验证状态
     * @param verified 验证状态
     */
    fun setVerified(verified: Boolean) {
        prefs.edit().apply {
            putBoolean(KEY_IS_VERIFIED, verified)
            if (verified) {
                putLong(KEY_VERIFY_TIME, System.currentTimeMillis())
            } else {
                remove(KEY_VERIFY_TIME)
            }
            apply()
        }
    }

    /**
     * 获取验证时间戳
     * @return 验证成功的时间戳，未验证返回 0
     */
    fun getVerifyTimestamp(): Long {
        return prefs.getLong(KEY_VERIFY_TIME, 0)
    }

    /**
     * 检查验证是否过期（可选：24 小时后需重新验证）
     * @param expireHours 过期时间（小时），默认 24 小时
     * @return true 表示已过期，需要重新验证
     */
    fun isExpired(expireHours: Long = 24): Boolean {
        if (!isVerified()) return true
        
        val verifyTime = getVerifyTimestamp()
        if (verifyTime == 0L) return true
        
        val currentTime = System.currentTimeMillis()
        val expireMillis = expireHours * 60 * 60 * 1000
        
        return (currentTime - verifyTime) > expireMillis
    }

    /**
     * 清除验证状态（用于调试或退出登录）
     */
    fun clearVerification() {
        prefs.edit().apply {
            remove(KEY_IS_VERIFIED)
            remove(KEY_VERIFY_TIME)
            apply()
        }
    }

    /**
     * 获取验证信息（用于调试）
     */
    fun getVerificationInfo(): String {
        val isVerified = isVerified()
        val verifyTime = getVerifyTimestamp()
        val isExpired = isExpired()
        
        return buildString {
            appendLine("Verification Status:")
            appendLine("  Is Verified: $isVerified")
            appendLine("  Verify Time: ${if (verifyTime > 0) java.util.Date(verifyTime) else "N/A"}")
            appendLine("  Is Expired: $isExpired")
        }
    }
}