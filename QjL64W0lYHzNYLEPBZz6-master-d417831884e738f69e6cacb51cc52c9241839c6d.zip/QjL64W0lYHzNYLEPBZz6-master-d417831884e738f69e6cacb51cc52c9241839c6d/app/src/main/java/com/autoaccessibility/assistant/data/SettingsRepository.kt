package com.autoaccessibility.assistant.data

import android.content.Context
import com.autoaccessibility.assistant.model.UserSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * 用户设置仓库
 * 封装数据访问逻辑，提供统一的配置管理接口
 */
class SettingsRepository private constructor(
    private val settingsDao: SettingsDao
) {
    
    companion object {
        @Volatile
        private var instance: SettingsRepository? = null
        
        fun getInstance(context: Context): SettingsRepository {
            return instance ?: synchronized(this) {
                val dao = AppDatabase.getDatabase(context).taskDao() as SettingsDao
                val repo = SettingsRepository(dao)
                instance = repo
                repo
            }
        }
    }
    
    /**
     * 获取当前设置（协程版本）
     */
    suspend fun getSettings(): UserSettings {
        return withContext(Dispatchers.IO) {
            settingsDao.getSettings() ?: UserSettings.getDefault()
        }
    }
    
    /**
     * 获取当前设置（阻塞版本，用于非协程环境）
     */
    fun getSettingsBlocking(): UserSettings {
        return runCatching {
            settingsDao.getSettingsBlocking() ?: UserSettings.getDefault()
        }.getOrElse {
            UserSettings.getDefault()
        }
    }
    
    /**
     * 获取设置的 Flow（用于观察变化）
     */
    fun getSettingsFlow(): Flow<UserSettings?> {
        return settingsDao.getSettingsFlow()
    }
    
    /**
     * 保存设置
     */
    suspend fun saveSettings(settings: UserSettings) {
        withContext(Dispatchers.IO) {
            settingsDao.insertOrUpdate(settings.copy(updatedAt = System.currentTimeMillis()))
        }
    }
    
    /**
     * 更新刷新间隔
     */
    suspend fun updateRefreshInterval(seconds: Int): Boolean {
        if (!UserSettings.isValidRefreshInterval(seconds)) {
            return false
        }
        withContext(Dispatchers.IO) {
            settingsDao.updateRefreshInterval(seconds)
        }
        return true
    }
    
    /**
     * 更新价格过滤
     */
    suspend fun updatePriceFilter(enabled: Boolean, minPrice: Double, maxPrice: Double): Boolean {
        if (!UserSettings.isValidPriceRange(minPrice, maxPrice)) {
            return false
        }
        withContext(Dispatchers.IO) {
            settingsDao.updatePriceFilter(enabled, minPrice, maxPrice)
        }
        return true
    }
    
    /**
     * 更新接驾距离过滤
     */
    suspend fun updateDistanceFilter(enabled: Boolean, maxDistance: Double): Boolean {
        if (!UserSettings.isValidDistance(maxDistance)) {
            return false
        }
        withContext(Dispatchers.IO) {
            settingsDao.updateDistanceFilter(enabled, maxDistance)
        }
        return true
    }
    
    /**
     * 更新行程距离过滤
     */
    suspend fun updateTripDistanceFilter(
        enabled: Boolean,
        minDistance: Double,
        maxDistance: Double
    ): Boolean {
        if (!UserSettings.isValidDistance(minDistance) || 
            !UserSettings.isValidDistance(maxDistance) ||
            minDistance > maxDistance) {
            return false
        }
        withContext(Dispatchers.IO) {
            settingsDao.updateTripDistanceFilter(enabled, minDistance, maxDistance)
        }
        return true
    }
    
    /**
     * 更新自动抢单开关
     */
    suspend fun updateAutoGrabEnabled(enabled: Boolean) {
        withContext(Dispatchers.IO) {
            settingsDao.updateAutoGrabEnabled(enabled)
        }
    }
    
    /**
     * 增加刷新次数统计
     */
    suspend fun incrementRefreshCount() {
        withContext(Dispatchers.IO) {
            settingsDao.incrementRefreshCount()
        }
    }
    
    /**
     * 增加过滤订单数统计
     */
    suspend fun incrementFilteredCount() {
        withContext(Dispatchers.IO) {
            settingsDao.incrementFilteredCount()
        }
    }
    
    /**
     * 增加成功抢单数统计
     */
    suspend fun incrementGrabbedCount() {
        withContext(Dispatchers.IO) {
            settingsDao.incrementGrabbedCount()
        }
    }
    
    /**
     * 重置统计数据
     */
    suspend fun resetStatistics() {
        withContext(Dispatchers.IO) {
            settingsDao.resetStatistics()
        }
    }
    
    /**
     * 导出配置为 JSON 文件
     */
    suspend fun exportToJson(context: Context): File {
        return withContext(Dispatchers.IO) {
            val settings = getSettings()
            val json = JSONObject().apply {
                put("refreshIntervalSeconds", settings.refreshIntervalSeconds)
                put("enablePriceFilter", settings.enablePriceFilter)
                put("minPrice", settings.minPrice)
                put("maxPrice", settings.maxPrice)
                put("enableDistanceFilter", settings.enableDistanceFilter)
                put("maxPickupDistance", settings.maxPickupDistance)
                put("enableTripDistanceFilter", settings.enableTripDistanceFilter)
                put("minTripDistance", settings.minTripDistance)
                put("maxTripDistance", settings.maxTripDistance)
                put("autoGrabEnabled", settings.autoGrabEnabled)
            }
            
            val fileName = "settings_backup_${System.currentTimeMillis()}.json"
            val file = File(context.filesDir, fileName)
            file.writeText(json.toString(2))
            file
        }
    }
    
    /**
     * 从 JSON 文件导入配置
     */
    suspend fun importFromJson(context: Context, file: File): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val json = JSONObject(file.readText())
                val currentSettings = getSettings()
                
                val newSettings = currentSettings.copy(
                    refreshIntervalSeconds = json.optInt("refreshIntervalSeconds", 5),
                    enablePriceFilter = json.optBoolean("enablePriceFilter", false),
                    minPrice = json.optDouble("minPrice", 0.0),
                    maxPrice = json.optDouble("maxPrice", 9999.0),
                    enableDistanceFilter = json.optBoolean("enableDistanceFilter", false),
                    maxPickupDistance = json.optDouble("maxPickupDistance", 10.0),
                    enableTripDistanceFilter = json.optBoolean("enableTripDistanceFilter", false),
                    minTripDistance = json.optDouble("minTripDistance", 0.0),
                    maxTripDistance = json.optDouble("maxTripDistance", 999.0),
                    autoGrabEnabled = json.optBoolean("autoGrabEnabled", false),
                    updatedAt = System.currentTimeMillis()
                )
                
                saveSettings(newSettings)
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
    
    /**
     * 检查订单是否符合所有条件
     */
    suspend fun isOrderValid(
        price: Double,
        pickupDistance: Double,
        tripDistance: Double
    ): Boolean {
        val settings = getSettings()
        return settings.isOrderValid(price, pickupDistance, tripDistance)
    }
}