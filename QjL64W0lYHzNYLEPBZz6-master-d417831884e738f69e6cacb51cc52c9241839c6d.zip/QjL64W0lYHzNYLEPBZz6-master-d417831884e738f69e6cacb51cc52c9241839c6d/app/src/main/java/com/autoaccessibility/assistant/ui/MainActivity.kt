package com.autoaccessibility.assistant.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.data.SettingsRepository
import com.autoaccessibility.assistant.engine.TaskEngine
import com.autoaccessibility.assistant.model.TaskScript
import com.autoaccessibility.assistant.service.AutoAccessibilityService
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.autoaccessibility.assistant.config.VerificationManager

/**
 * 主界面 Activity
 * 展示任务列表，引导开启无障碍服务权限
 */
class MainActivity : AppCompatActivity() {

    private val verificationManager by lazy { VerificationManager.getInstance(this) }

    private lateinit var recyclerView: RecyclerView
    private lateinit var taskAdapter: TaskAdapter
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var fabSettings: FloatingActionButton
    private lateinit var emptyView: View
    private lateinit var statusPanel: View
    
    // 状态显示组件
    private lateinit var tvRefreshInterval: TextView
    private lateinit var tvPriceFilter: TextView
    private lateinit var tvDistanceFilter: TextView
    private lateinit var tvStats: TextView
    
    private val taskEngine = TaskEngine.getInstance()
    private val settingsRepository by lazy { SettingsRepository.getInstance(applicationContext) }
    private val taskList = mutableListOf<TaskScript>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 检查验证状态，未验证则跳转到验证页面
        if (!verificationManager.isVerified()) {
            val intent = android.content.Intent(this, VerificationActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        
        // 先检查悬浮窗权限
        if (!PermissionGuideActivity.hasOverlayPermission(this)) {
            // 跳转到权限引导页面
            val intent = android.content.Intent(this, PermissionGuideActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        
        setContentView(R.layout.activity_main)
        
        initViews()
        setupRecyclerView()
        setupFab()
        setupStatusPanel()
        checkAccessibilityPermission()
        loadTasks()
        updateStatusPanel()
        
        // 启动悬浮窗服务
        startFloatingWindowService()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        fabAdd = findViewById(R.id.fabAdd)
        fabSettings = findViewById(R.id.fabSettings)
        emptyView = findViewById(R.id.emptyView)
        statusPanel = findViewById(R.id.statusPanel)
        
        tvRefreshInterval = findViewById(R.id.tvRefreshInterval)
        tvPriceFilter = findViewById(R.id.tvPriceFilter)
        tvDistanceFilter = findViewById(R.id.tvDistanceFilter)
        tvStats = findViewById(R.id.tvStats)
    }

    private fun setupRecyclerView() {
        taskAdapter = TaskAdapter(taskList, object : TaskAdapter.TaskClickListener {
            override fun onTaskClick(task: TaskScript) {
                // 点击任务项，可以选择执行或编辑
                showTaskOptions(task)
            }
            
            override fun onTaskToggle(task: TaskScript, isEnabled: Boolean) {
                // 切换任务启用状态 - 创建新实例
                val updatedTask = task.copy(isEnabled = isEnabled)
                val index = taskList.indexOf(task)
                if (index >= 0) {
                    taskList[index] = updatedTask
                    taskAdapter.notifyItemChanged(index)
                }
                // TODO: 保存到数据库
                Toast.makeText(this@MainActivity, 
                    "任务${if (isEnabled) "已启用" else "已禁用"}", 
                    Toast.LENGTH_SHORT).show()
            }
            
            override fun onTaskDelete(task: TaskScript) {
                // 删除任务
                confirmDelete(task)
            }
        })
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = taskAdapter
    }

    private fun setupFab() {
        fabAdd.setOnClickListener {
            // 跳转到脚本编辑器
            val intent = Intent(this, ScriptEditorActivity::class.java)
            startActivity(intent)
        }
        
        fabSettings.setOnClickListener {
            // 跳转到设置页面
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }
    
    /**
     * 设置状态面板
     */
    private fun setupStatusPanel() {
        statusPanel.setOnClickListener {
            // 点击跳转到设置页面
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }
    
    /**
     * 更新状态面板显示
     */
    private fun updateStatusPanel() {
        val settings = settingsRepository.getSettingsBlocking()
        
        // 刷新间隔
        tvRefreshInterval.text = "⏱ 刷新：${settings.refreshIntervalSeconds}秒/次"
        
        // 价格过滤
        if (settings.enablePriceFilter) {
            tvPriceFilter.text = "💰 价格：¥${settings.minPrice}-${settings.maxPrice}"
            tvPriceFilter.visibility = View.VISIBLE
        } else {
            tvPriceFilter.visibility = View.GONE
        }
        
        // 距离过滤
        if (settings.enableDistanceFilter || settings.enableTripDistanceFilter) {
            val distanceText = buildString {
                if (settings.enableDistanceFilter) {
                    append("接驾≤${settings.maxPickupDistance}km")
                }
                if (settings.enableTripDistanceFilter) {
                    if (isNotEmpty()) append(" | ")
                    append("行程${settings.minTripDistance}-${settings.maxTripDistance}km")
                }
            }
            tvDistanceFilter.text = "📍 $distanceText"
            tvDistanceFilter.visibility = View.VISIBLE
        } else {
            tvDistanceFilter.visibility = View.GONE
        }
        
        // 统计数据
        tvStats.text = "📊 刷新:${settings.totalRefreshCount} | 过滤:${settings.totalFilteredOrders} | 抢单:${settings.totalGrabbedOrders}"
    }

    /**
     * 检查无障碍服务权限
     */
    private fun checkAccessibilityPermission() {
        if (!isAccessibilityServiceEnabled()) {
            showEnableAccessibilityDialog()
        }
    }

    /**
     * 启动悬浮窗服务
     */
    private fun startFloatingWindowService() {
        val intent = android.content.Intent(this, com.autoaccessibility.assistant.service.FloatingWindowService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    /**
     * 检查无障碍服务是否已启用
     */
    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        
        for (service in enabledServices) {
            if (service.resolveInfo.serviceInfo.packageName == packageName &&
                service.resolveInfo.serviceInfo.name == AutoAccessibilityService::class.java.name) {
                return true
            }
        }
        
        return false
    }

    /**
     * 显示启用无障碍服务的对话框
     */
    private fun showEnableAccessibilityDialog() {
        AlertDialog.Builder(this)
            .setTitle("需要无障碍权限")
            .setMessage("本应用需要使用无障碍服务来实现屏幕识别和自动操作功能。请在设置中启用「AutoAccessibility」无障碍服务。")
            .setPositiveButton("去设置") { _, _ ->
                openAccessibilitySettings()
            }
            .setNegativeButton("稍后") { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    /**
     * 打开无障碍服务设置页面
     */
    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "无法打开设置页面", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * 加载任务列表
     */
    private fun loadTasks() {
        // TODO: 从数据库加载任务
        // 这里先使用模拟数据
        
        taskList.clear()
        taskList.addAll(getMockTasks())
        
        updateEmptyView()
        taskAdapter.notifyDataSetChanged()
    }

    /**
     * 获取模拟任务数据
     */
    private fun getMockTasks(): List<TaskScript> {
        return listOf(
            TaskScript(
                id = "1",
                name = "微信自动点赞",
                description = "自动浏览朋友圈并点赞",
                isEnabled = true,
                steps = emptyList()
            ),
            TaskScript(
                id = "2",
                name = "抖音自动滑动",
                description = "自动滑动观看抖音视频",
                isEnabled = false,
                steps = emptyList()
            ),
            TaskScript(
                id = "3",
                name = "自动签到助手",
                description = "每日自动打开应用签到",
                isEnabled = true,
                steps = emptyList()
            )
        )
    }

    /**
     * 更新空视图显示
     */
    private fun updateEmptyView() {
        emptyView.visibility = if (taskList.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (taskList.isEmpty()) View.GONE else View.VISIBLE
    }

    /**
     * 显示任务操作选项
     */
    private fun showTaskOptions(task: TaskScript) {
        val options = arrayOf("执行任务", "编辑任务", "查看日志", "删除任务")
        
        AlertDialog.Builder(this)
            .setTitle(task.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> executeTask(task)
                    1 -> editTask(task)
                    2 -> viewLogs(task)
                    3 -> confirmDelete(task)
                }
            }
            .show()
    }

    /**
     * 执行任务
     */
    private fun executeTask(task: TaskScript) {
        if (!taskEngine.isServiceAvailable()) {
            Snackbar.make(fabAdd, "无障碍服务未启用，请先在设置中开启", Snackbar.LENGTH_LONG)
                .setAction("去设置") {
                    openAccessibilitySettings()
                }
                .show()
            return
        }
        
        if (task.steps.isEmpty()) {
            Toast.makeText(this, "任务没有配置操作步骤", Toast.LENGTH_SHORT).show()
            return
        }
        
        Toast.makeText(this, "开始执行：${task.name}", Toast.LENGTH_SHORT).show()
        taskEngine.executeTask(task)
    }

    /**
     * 编辑任务
     */
    private fun editTask(task: TaskScript) {
        val intent = Intent(this, ScriptEditorActivity::class.java)
        intent.putExtra("task_id", task.id)
        startActivity(intent)
    }

    /**
     * 查看日志
     */
    private fun viewLogs(task: TaskScript) {
        // TODO: 实现日志查看功能
        Toast.makeText(this, "日志功能开发中...", Toast.LENGTH_SHORT).show()
    }

    /**
     * 确认删除任务
     */
    private fun confirmDelete(task: TaskScript) {
        AlertDialog.Builder(this)
            .setTitle("删除任务")
            .setMessage("确定要删除任务「${task.name}」吗？此操作不可恢复。")
            .setPositiveButton("删除") { _, _ ->
                deleteTask(task)
            }
            .setNegativeButton("取消") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    /**
     * 删除任务
     */
    private fun deleteTask(task: TaskScript) {
        taskList.remove(task)
        taskAdapter.notifyDataSetChanged()
        updateEmptyView()
        
        // TODO: 从数据库删除
        Toast.makeText(this, "任务已删除", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        
        // 检查验证状态，防止绕过验证
        if (!verificationManager.isVerified()) {
            val intent = android.content.Intent(this, VerificationActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        
        // 重新检查权限状态
        if (isAccessibilityServiceEnabled()) {
            Toast.makeText(this, "无障碍服务已启用", Toast.LENGTH_SHORT).show()
        }
        // 更新状态面板
        updateStatusPanel()
    }

    override fun onDestroy() {
        super.onDestroy()
        taskEngine.destroy()
        // 停止悬浮窗服务
        stopFloatingWindowService()
    }

    /**
     * 停止悬浮窗服务
     */
    private fun stopFloatingWindowService() {
        try {
            val intent = android.content.Intent(this, com.autoaccessibility.assistant.service.FloatingWindowService::class.java)
            stopService(intent)
        } catch (e: Exception) {
            // 忽略异常
        }
    }
}