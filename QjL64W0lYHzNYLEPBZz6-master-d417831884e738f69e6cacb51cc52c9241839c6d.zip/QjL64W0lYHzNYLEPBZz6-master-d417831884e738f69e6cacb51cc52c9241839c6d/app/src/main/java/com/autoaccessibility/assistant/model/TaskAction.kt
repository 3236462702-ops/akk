package com.autoaccessibility.assistant.model

import java.io.Serializable

/**
 * 任务操作步骤
 * 定义单个自动化操作的详细信息
 */
data class TaskAction(
    val type: ActionType,
    val param1: String = "",
    val param2: String = "",
    val delay: Long = 0L
) : Serializable {

    companion object {
        private const val serialVersionUID = 1L
    }
}