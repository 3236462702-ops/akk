package com.autoaccessibility.assistant.model

import android.graphics.Rect

/**
 * UI 元素数据类
 * 存储从 AccessibilityNodeInfo 提取的界面元素信息
 */
data class UiElement(
    val id: Long,                          // 唯一标识
    val text: String,                      // 显示文本或 contentDescription
    val className: String,                 // 视图类名
    val packageName: String,               // 所属应用包名
    val bounds: Rect,                      // 屏幕坐标范围
    val isClickable: Boolean,              // 是否可点击
    val isCheckable: Boolean,              // 是否可选中
    val isChecked: Boolean,                // 是否已选中
    val isEnabled: Boolean,                // 是否启用
    val isVisibleToUser: Boolean,          // 对用户是否可见
    val depth: Int,                        // 在视图树中的深度
    val parentText: String = ""            // 父容器文本（用于上下文）
) {
    /**
     * 获取中心点 X 坐标
     */
    fun getCenterX(): Int = bounds.centerX()

    /**
     * 获取中心点 Y 坐标
     */
    fun getCenterY(): Int = bounds.centerY()

    /**
     * 获取宽度
     */
    fun getWidth(): Int = bounds.width()

    /**
     * 获取高度
     */
    fun getHeight(): Int = bounds.height()

    /**
     * 检查是否包含指定坐标
     */
    fun contains(x: Int, y: Int): Boolean = bounds.contains(x, y)

    /**
     * 转换为可读字符串
     */
    override fun toString(): String {
        return "UiElement(text='$text', class=$className, bounds=$bounds, clickable=$isClickable)"
    }

    /**
     * 生成操作描述
     */
    fun toActionDescription(): String {
        val action = when {
            isCheckable && isChecked -> "[已选中] $text"
            isCheckable && !isChecked -> "[未选中] $text"
            isClickable -> "[可点击] $text"
            else -> "[只读] $text"
        }
        return if (parentText.isNotEmpty()) {
            "$action (位于：$parentText)"
        } else {
            action
        }
    }
}

