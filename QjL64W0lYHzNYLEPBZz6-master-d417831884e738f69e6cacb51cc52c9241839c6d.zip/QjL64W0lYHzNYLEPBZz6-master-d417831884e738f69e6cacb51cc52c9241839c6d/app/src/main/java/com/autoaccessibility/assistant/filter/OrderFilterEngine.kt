package com.autoaccessibility.assistant.filter

import android.util.Log
import com.autoaccessibility.assistant.data.SettingsRepository
import com.autoaccessibility.assistant.model.OrderInfo
import com.autoaccessibility.assistant.model.OrderType
import com.autoaccessibility.assistant.model.UserSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 订单过滤引擎
 * 根据用户设置对订单进行多维度过滤，只有符合条件的订单才会触发抢单操作
 */
class OrderFilterEngine {

    companion object {
        private const val TAG = "OrderFilterEngine"
        
        @Volatile
        private var instance: OrderFilterEngine? = null
        
        /**
         * 获取单例实例
         */
        fun getInstance(): OrderFilterEngine {
            return instance ?: synchronized(this) {
                instance ?: OrderFilterEngine().also { instance = it }
            }
        }
    }

    private lateinit var settingsRepository: SettingsRepository
    
    // 过滤统计
    private var totalCheckedCount = 0L
    private var passedCount = 0L
    private var filteredCount = 0L
    
    // 过滤原因记录
    private var lastFilterReason: String? = null
    
    // 日志回调（用于悬浮窗显示）
    var onOrderChecked: ((OrderInfo, FilterResult) -> Unit)? = null

    /**
     * 初始化（需要 Context）
     */
    fun initialize(context: android.content.Context) {
        settingsRepository = SettingsRepository.getInstance(context)
        Log.d(TAG, "订单过滤引擎已初始化")
    }

    /**
     * 检查订单是否符合用户设置
     * @param orderInfo 订单信息
     * @return 是否符合条件
     */
    suspend fun checkOrder(orderInfo: OrderInfo): Boolean {
        return withContext(Dispatchers.IO) {
            totalCheckedCount++
            
            try {
                val settings = settingsRepository.getSettings()
                
                // 如果总开关未启用，直接通过（不过滤）
                if (!settings.autoGrabEnabled) {
                    Log.d(TAG, "自动抢单未启用，跳过过滤")
                    val result = FilterResult(isPassed = true, reason = "自动抢单未启用")
                    notifyOrderChecked(orderInfo, result)
                    return@withContext true
                }
                
                // 执行多维度过滤
                val filterResult = performFilter(settings, orderInfo)
                
                if (filterResult.isPassed) {
                    passedCount++
                    lastFilterReason = null
                    Log.d(TAG, "订单通过过滤：${orderInfo.toDescription()}")
                } else {
                    filteredCount++
                    lastFilterReason = filterResult.reason
                    Log.d(TAG, "订单被过滤：${filterResult.reason}")
                }
                
                // 通知悬浮窗更新日志
                notifyOrderChecked(orderInfo, filterResult)
                
                filterResult.isPassed
                
            } catch (e: Exception) {
                Log.e(TAG, "过滤检查异常", e)
                val errorResult = FilterResult(isPassed = true, reason = "过滤异常：" + e.message)
                notifyOrderChecked(orderInfo, errorResult)
                // 异常时默认通过，避免误杀
                true
            }
        }
    }
    
    /**
     * 通知订单检查结果（用于悬浮窗日志）
     */
    private fun notifyOrderChecked(orderInfo: OrderInfo, result: FilterResult) {
        onOrderChecked?.invoke(orderInfo, result)
    }

    /**
     * 执行多维度过滤
     */
    private fun performFilter(settings: UserSettings, orderInfo: OrderInfo): FilterResult {
        // 1. 订单类型过滤
        if (settings.enableOrderTypeFilter) {
            if (!settings.isOrderTypeValid(orderInfo.orderType)) {
                val selectedTypes = settings.parseSelectedOrderTypes().joinToString("、")
                return FilterResult(
                    isPassed = false,
                    reason = "订单类型不匹配：${if (orderInfo.orderType.isNotBlank()) orderInfo.orderType else "未知"}（已选：$selectedTypes）"
                )
            }
        }
        
        // 2. 价格过滤
        if (settings.enablePriceFilter) {
            if (!settings.isPriceValid(orderInfo.price)) {
                return FilterResult(
                    isPassed = false,
                    reason = "价格不符合：¥${orderInfo.price} 不在 [¥${settings.minPrice}, ¥${settings.maxPrice}] 范围内"
                )
            }
        }
        
        // 3. 接驾距离过滤
        if (settings.enableDistanceFilter) {
            if (!settings.isPickupDistanceValid(orderInfo.pickupDistance)) {
                return FilterResult(
                    isPassed = false,
                    reason = "接驾距离过远：${orderInfo.pickupDistance}km > ${settings.maxPickupDistance}km"
                )
            }
        }
        
        // 4. 行程距离过滤
        if (settings.enableTripDistanceFilter) {
            if (!settings.isTripDistanceValid(orderInfo.tripDistance)) {
                return FilterResult(
                    isPassed = false,
                    reason = "行程距离不符合：${orderInfo.tripDistance}km 不在 [${settings.minTripDistance}, ${settings.maxTripDistance}]km 范围内"
                )
            }
        }
        
        // 5. 区域过滤（新逻辑：两个互斥的勾选框）
        val regionResult = checkRegionFilter(settings, orderInfo.district)
        if (!regionResult.isPassed) {
            return regionResult
        }
        
        // 所有条件都通过
        return FilterResult(isPassed = true)
    }
    
    /**
     * 检查区域是否符合设置（新逻辑：两个互斥的勾选框）
     */
    private fun checkRegionFilter(settings: UserSettings, district: String?): FilterResult {
        // 如果区域为空，直接通过
        if (district.isNullOrBlank()) {
            return FilterResult(isPassed = true)
        }
        
        // 检查黑名单模式（不接区域）
        if (settings.excludeRegionEnabled) {
            val excluded = settings.parseExcludedDistricts()
            if (excluded.isNotEmpty()) {
                val isExcluded = excluded.any { ex -> district.contains(ex, ignoreCase = true) }
                if (isExcluded) {
                    val excludedStr = excluded.joinToString("、")
                    return FilterResult(
                        isPassed = false,
                        reason = "区域在黑名单中：$district（不接区域：$excludedStr）"
                    )
                }
            }
        }
        
        // 检查白名单模式（只接区域）
        if (settings.includeRegionEnabled) {
            val included = settings.parseIncludedDistricts()
            if (included.isNotEmpty()) {
                val isIncluded = included.any { inc -> district.contains(inc, ignoreCase = true) }
                if (!isIncluded) {
                    val includedStr = included.joinToString("、")
                    return FilterResult(
                        isPassed = false,
                        reason = "区域不在白名单中：$district（只接区域：$includedStr）"
                    )
                }
            }
        }
        
        // 通过过滤
        return FilterResult(isPassed = true)
    }

    /**
     * 从 OCR 文本解析订单信息
     * @param ocrText OCR 识别结果
     * @return 解析后的订单信息
     */
    fun parseOrderFromOcr(ocrText: String): OrderInfo {
        val orderInfo = OrderInfo(rawText = ocrText)
        
        try {
            // 解析价格（匹配 ¥ 或 元 前面的数字）
            val priceRegex = Regex("(?:¥|￥|元)[:：]?\\s*([0-9]+\\.?[0-9]*)")
            val priceMatch = priceRegex.find(ocrText)
            val price = priceMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            
            // 解析接驾距离（匹配 公里 或 km 前面的数字）
            val pickupRegex = Regex("接驾 [:：]?\\s*([0-9]+\\.?[0-9]*)\\s*(?:公里|km)")
            val pickupMatch = pickupRegex.find(ocrText)
            val pickupDistance = pickupMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            
            // 解析行程距离（匹配 行程 或 距离 后面的数字）
            val tripRegex = Regex("(?:行程 | 距离)[:：]?\\s*([0-9]+\\.?[0-9]*)\\s*(?:公里|km)")
            val tripMatch = tripRegex.find(ocrText)
            val tripDistance = tripMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
            
            // 解析订单类型（新增）
            val orderType = detectOrderType(ocrText)
            
            val result = orderInfo.copy(
                price = price,
                pickupDistance = pickupDistance,
                tripDistance = tripDistance,
                orderType = orderType
            )
            
            Log.d(TAG, "解析订单信息：${result.toDescription()}")
            
        } catch (e: Exception) {
            Log.e(TAG, "解析 OCR 文本失败", e)
        }
        
        return orderInfo
    }
    
    /**
     * 从 OCR 文本中检测订单类型
     */
    fun detectOrderType(ocrText: String): String {
        // 遍历所有订单类型关键词进行匹配
        for (type in OrderType.values()) {
            for (keyword in type.keywords) {
                if (ocrText.contains(keyword, ignoreCase = true)) {
                    return type.displayName
                }
            }
        }
        return ""
    }

    /**
     * 获取最后一次过滤原因
     */
    fun getLastFilterReason(): String? {
        return lastFilterReason
    }

    /**
     * 获取过滤统计信息
     */
    fun getStatistics(): FilterStatistics {
        return FilterStatistics(
            totalChecked = totalCheckedCount,
            passed = passedCount,
            filtered = filteredCount,
            passRate = if (totalCheckedCount > 0) passedCount.toFloat() / totalCheckedCount else 0f,
            lastFilterReason = lastFilterReason
        )
    }

    /**
     * 重置统计
     */
    fun resetStatistics() {
        totalCheckedCount = 0L
        passedCount = 0L
        filteredCount = 0L
        lastFilterReason = null
    }
}

/**
 * 过滤结果
 */
data class FilterResult(
    val isPassed: Boolean,
    val reason: String? = null
)

/**
 * 过滤统计信息
 */
data class FilterStatistics(
    val totalChecked: Long,
    val passed: Long,
    val filtered: Long,
    val passRate: Float,
    val lastFilterReason: String?
) {
    fun getPassRatePercent(): Int {
        return (passRate * 100).toInt()
    }
}