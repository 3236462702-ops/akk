package com.autoaccessibility.assistant.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 自动化任务脚本模型
 * 存储用户创建的自动化任务配置
 */
@Entity(tableName = "task_script")
data class TaskScript(
    @PrimaryKey
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val isEnabled: Boolean = true,
    val steps: List<TaskStep> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 任务步骤模型
 */
data class TaskStep(
    val actionType: ActionType,
    val targetText: String? = null,
    val x: Int? = null,
    val y: Int? = null,
    val endX: Int? = null,
    val endY: Int? = null,
    val startY: Int? = null,
    val text: String? = null,
    val duration: Long = 0,
    val delay: Long = 0,
    val retryCount: Int = 3,
    val loopCount: Int = 0,
    val description: String = ""
)