package com.autoaccessibility.assistant.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.engine.TaskEngine
import com.autoaccessibility.assistant.model.ActionType
import com.autoaccessibility.assistant.model.TaskAction
import com.autoaccessibility.assistant.model.TaskScript
import com.autoaccessibility.assistant.model.TaskStep
import com.autoaccessibility.assistant.service.AutoAccessibilityService
import java.util.Collections

/**
 * 脚本编辑器界面
 * 可视化编辑自动化任务的执行步骤
 */
class ScriptEditorActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAddStep: Button
    private lateinit var btnSave: Button
    private lateinit var btnRun: Button
    private lateinit var etTaskName: EditText
    private lateinit var etTaskDesc: EditText
    private lateinit var tvEmptyState: TextView

    private val steps = mutableListOf<TaskAction>()
    private lateinit var adapter: StepAdapter
    private var taskId: Long = -1

    companion object {
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TASK_NAME = "extra_task_name"
        const val EXTRA_TASK_DESC = "extra_task_desc"
        const val EXTRA_STEPS = "extra_steps"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_script_editor)

        // 接收传入的参数
        taskId = intent.getLongExtra(EXTRA_TASK_ID, -1)
        val taskName = intent.getStringExtra(EXTRA_TASK_NAME) ?: ""
        val taskDesc = intent.getStringExtra(EXTRA_TASK_DESC) ?: ""
        val taskSteps = intent.getSerializableExtra(EXTRA_STEPS) as? ArrayList<TaskAction>

        // 初始化视图
        initViews()

        // 填充已有数据
        etTaskName.setText(taskName)
        etTaskDesc.setText(taskDesc)
        
        if (taskSteps != null) {
            steps.addAll(taskSteps)
            updateEmptyState()
        }

        // 设置适配器
        adapter = StepAdapter(steps)
        recyclerView.adapter = adapter

        // 添加拖拽排序支持
        setupItemTouchHelper()

        // 绑定事件
        bindEvents()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewSteps)
        btnAddStep = findViewById(R.id.btnAddStep)
        btnSave = findViewById(R.id.btnSave)
        btnRun = findViewById(R.id.btnRun)
        etTaskName = findViewById(R.id.etTaskName)
        etTaskDesc = findViewById(R.id.etTaskDesc)
        tvEmptyState = findViewById(R.id.tvEmptyState)

        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun bindEvents() {
        // 添加步骤按钮
        btnAddStep.setOnClickListener {
            showAddStepDialog()
        }

        // 保存按钮
        btnSave.setOnClickListener {
            saveTask()
        }

        // 运行按钮
        btnRun.setOnClickListener {
            runTask()
        }
    }

    private fun setupItemTouchHelper() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val fromPos = viewHolder.adapterPosition
                val toPos = target.adapterPosition
                
                Collections.swap(steps, fromPos, toPos)
                adapter.notifyItemMoved(fromPos, toPos)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                steps.removeAt(position)
                adapter.notifyItemRemoved(position)
                updateEmptyState()
            }
        }

        ItemTouchHelper(callback).attachToRecyclerView(recyclerView)
    }

    private fun showAddStepDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_step, null)
        val spinnerType = dialogView.findViewById<Spinner>(R.id.spinnerActionType)
        val etParam1 = dialogView.findViewById<EditText>(R.id.etParam1)
        val etParam2 = dialogView.findViewById<EditText>(R.id.etParam2)
        val etDelay = dialogView.findViewById<EditText>(R.id.etDelay)

        // 设置操作类型选项
        val types = arrayOf("点击坐标", "长按坐标", "滑动", "输入文字", "等待", "返回", "主页")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, types)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerType.adapter = adapter

        // 根据类型显示不同参数输入框
        spinnerType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when (position) {
                    0, 1 -> { // 点击/长按坐标
                        etParam1.hint = "X 坐标"
                        etParam2.hint = "Y 坐标"
                    }
                    2 -> { // 滑动
                        etParam1.hint = "起点 X,Y"
                        etParam2.hint = "终点 X,Y"
                    }
                    3 -> { // 输入文字
                        etParam1.hint = "要输入的文字"
                        etParam2.visibility = View.GONE
                    }
                    4 -> { // 等待
                        etParam1.hint = "等待毫秒数"
                        etParam2.visibility = View.GONE
                    }
                    else -> { // 返回/主页
                        etParam1.visibility = View.GONE
                        etParam2.visibility = View.GONE
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        AlertDialog.Builder(this)
            .setTitle("添加操作步骤")
            .setView(dialogView)
            .setPositiveButton("确定") { _, _ ->
                val typeIndex = spinnerType.selectedItemPosition
                val delayStr = etDelay.text.toString().ifEmpty { "0" }
                val delay = delayStr.toLongOrNull() ?: 0L

                val action = when (typeIndex) {
                    0 -> TaskAction(ActionType.CLICK, etParam1.text.toString(), etParam2.text.toString(), delay)
                    1 -> TaskAction(ActionType.LONG_PRESS, etParam1.text.toString(), etParam2.text.toString(), delay)
                    2 -> TaskAction(ActionType.SWIPE, etParam1.text.toString(), etParam2.text.toString(), delay)
                    3 -> TaskAction(ActionType.INPUT_TEXT, etParam1.text.toString(), "", delay)
                    4 -> TaskAction(ActionType.WAIT, delayStr, "", delay)
                    5 -> TaskAction(ActionType.PRESS_BACK, "", "", delay)
                    6 -> TaskAction(ActionType.PRESS_HOME, "", "", delay)
                    else -> null
                }

                action?.let {
                    steps.add(it)
                    adapter.notifyDataSetChanged()
                    updateEmptyState()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun saveTask() {
        val name = etTaskName.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, "请输入任务名称", Toast.LENGTH_SHORT).show()
            return
        }

        if (steps.isEmpty()) {
            Toast.makeText(this, "请至少添加一个步骤", Toast.LENGTH_SHORT).show()
            return
        }

        val task = TaskScript(
            id = if (taskId > 0) taskId.toString() else System.currentTimeMillis().toString(),
            name = name,
            description = etTaskDesc.text.toString().trim(),
            steps = steps.map { action ->
                TaskStep(
                    actionType = action.type,
                    x = action.param1.toIntOrNull(),
                    y = action.param2.toIntOrNull(),
                    duration = action.delay,
                    delay = action.delay
                )
            },
            isEnabled = true,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        // 这里应该保存到数据库，简化处理直接返回结果
        val resultIntent = Intent()
        resultIntent.putExtra(EXTRA_TASK_ID, task.id.toLongOrNull() ?: 0L)
        resultIntent.putExtra(EXTRA_TASK_NAME, task.name)
        resultIntent.putExtra(EXTRA_TASK_DESC, task.description)
        resultIntent.putExtra(EXTRA_STEPS, ArrayList(task.steps.map { step ->
            TaskAction(step.actionType, step.x?.toString() ?: "", step.y?.toString() ?: "", step.delay)
        }))
        setResult(Activity.RESULT_OK, resultIntent)
        
        Toast.makeText(this, "任务已保存", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun runTask() {
        if (steps.isEmpty()) {
            Toast.makeText(this, "请先添加步骤", Toast.LENGTH_SHORT).show()
            return
        }

        // 检查无障碍服务是否启用
        val service = AutoAccessibilityService.getInstance()
        if (service == null) {
            Toast.makeText(this, "请先启用无障碍服务", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val task = TaskScript(
            id = System.currentTimeMillis().toString(),
            name = etTaskName.text.toString(),
            description = "",
            steps = steps.map { action ->
                TaskStep(
                    actionType = action.type,
                    x = action.param1.toIntOrNull(),
                    y = action.param2.toIntOrNull(),
                    duration = action.delay,
                    delay = action.delay
                )
            },
            isEnabled = true,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        TaskEngine.getInstance().executeTask(task)
        Toast.makeText(this, "任务开始执行", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun updateEmptyState() {
        tvEmptyState.visibility = if (steps.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (steps.isEmpty()) View.GONE else View.VISIBLE
    }

    /**
     * 步骤列表适配器
     */
    inner class StepAdapter(private val steps: List<TaskAction>) : 
        RecyclerView.Adapter<StepAdapter.StepViewHolder>() {

        inner class StepViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvStepNumber: TextView = itemView.findViewById(R.id.tvStepNumber)
            val tvStepType: TextView = itemView.findViewById(R.id.tvStepType)
            val tvStepParam: TextView = itemView.findViewById(R.id.tvStepParam)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StepViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_step, parent, false)
            return StepViewHolder(view)
        }

        override fun onBindViewHolder(holder: StepViewHolder, position: Int) {
            val step = steps[position]
            
            holder.tvStepNumber.text = "步骤 ${position + 1}"
            holder.tvStepType.text = getStepTypeName(step.type)
            holder.tvStepParam.text = formatStepParams(step)
        }

        override fun getItemCount(): Int = steps.size

        private fun getStepTypeName(type: ActionType): String {
            return when (type) {
                ActionType.CLICK -> "点击"
                ActionType.LONG_PRESS -> "长按"
                ActionType.SWIPE -> "滑动"
                ActionType.INPUT_TEXT -> "输入"
                ActionType.WAIT -> "等待"
                ActionType.PRESS_BACK -> "返回"
                ActionType.PRESS_HOME -> "主页"
                else -> "其他"
            }
        }

        private fun formatStepParams(step: TaskAction): String {
            return when (step.type) {
                ActionType.CLICK, ActionType.LONG_PRESS -> 
                    "坐标：(${step.param1}, ${step.param2})"
                ActionType.SWIPE -> 
                    "从 (${step.param1}) 到 (${step.param2})"
                ActionType.INPUT_TEXT -> 
                    "文字：${step.param1}"
                ActionType.WAIT -> 
                    "${step.param1}毫秒"
                else -> ""
            }
        }
    }
}