package com.autoaccessibility.assistant.data

import androidx.room.*
import com.autoaccessibility.assistant.model.UserSettings
import kotlinx.coroutines.flow.Flow

/**
 * 用户设置数据访问对象
 * 提供配置的增删改查操作
 */
@Dao
interface SettingsDao {
    
    /**
     * 插入或更新用户设置
     * 使用 OnConflictStrategy.REPLACE 实现更新
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: UserSettings)
    
    /**
     * 获取所有设置（单例，只返回 id=0 的记录）
     */
    @Query("SELECT * FROM user_settings WHERE id = 0")
    suspend fun getSettings(): UserSettings?
    
    /**
     * 阻塞式获取设置（用于非协程环境）
     */
    @Query("SELECT * FROM user_settings WHERE id = 0")
    fun getSettingsBlocking(): UserSettings?
    
    /**
     * 获取设置的 Flow（用于观察变化）
     */
    @Query("SELECT * FROM user_settings WHERE id = 0")
    fun getSettingsFlow(): Flow<UserSettings?>
    
    /**
     * 更新刷新间隔
     */
    @Query("UPDATE user_settings SET refreshIntervalSeconds = :interval, updatedAt = :timestamp WHERE id = 0")
    suspend fun updateRefreshInterval(interval: Int, timestamp: Long = System.currentTimeMillis())
    
    /**
     * 更新价格过滤设置
     */
    @Query("UPDATE user_settings SET enablePriceFilter = :enabled, minPrice = :minPrice, maxPrice = :maxPrice, updatedAt = :timestamp WHERE id = 0")
    suspend fun updatePriceFilter(
        enabled: Boolean,
        minPrice: Double,
        maxPrice: Double,
        timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 更新距离过滤设置
     */
    @Query("UPDATE user_settings SET enableDistanceFilter = :enabled, maxPickupDistance = :maxDistance, updatedAt = :timestamp WHERE id = 0")
    suspend fun updateDistanceFilter(
        enabled: Boolean,
        maxDistance: Double,
        timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 更新行程距离过滤设置
     */
    @Query("UPDATE user_settings SET enableTripDistanceFilter = :enabled, minTripDistance = :minDistance, maxTripDistance = :maxDistance, updatedAt = :timestamp WHERE id = 0")
    suspend fun updateTripDistanceFilter(
        enabled: Boolean,
        minDistance: Double,
        maxDistance: Double,
        timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 更新自动抢单总开关
     */
    @Query("UPDATE user_settings SET autoGrabEnabled = :enabled, updatedAt = :timestamp WHERE id = 0")
    suspend fun updateAutoGrabEnabled(enabled: Boolean, timestamp: Long = System.currentTimeMillis())
    
    /**
     * 更新点击延迟设置
     */
    @Query("UPDATE user_settings SET clickDelayFixed = :delayMs, clickDelayRandom = :isRandom, updatedAt = :timestamp WHERE id = 0")
    suspend fun updateClickDelay(
        delayMs: Int,
        isRandom: Boolean,
        timestamp: Long = System.currentTimeMillis()
    )
    
    /**
     * 更新统计信息 - 刷新次数
     */
    @Query("UPDATE user_settings SET totalRefreshCount = totalRefreshCount + 1, updatedAt = :timestamp WHERE id = 0")
    suspend fun incrementRefreshCount(timestamp: Long = System.currentTimeMillis())
    
    /**
     * 更新统计信息 - 过滤订单数
     */
    @Query("UPDATE user_settings SET totalFilteredOrders = totalFilteredOrders + 1, updatedAt = :timestamp WHERE id = 0")
    suspend fun incrementFilteredCount(timestamp: Long = System.currentTimeMillis())
    
    /**
     * 更新统计信息 - 成功抢单数
     */
    @Query("UPDATE user_settings SET totalGrabbedOrders = totalGrabbedOrders + 1, updatedAt = :timestamp WHERE id = 0")
    suspend fun incrementGrabbedCount(timestamp: Long = System.currentTimeMillis())
    
    /**
     * 重置所有统计信息
     */
    @Query("UPDATE user_settings SET totalRefreshCount = 0, totalFilteredOrders = 0, totalGrabbedOrders = 0, updatedAt = :timestamp WHERE id = 0")
    suspend fun resetStatistics(timestamp: Long = System.currentTimeMillis())
    
    /**
     * 删除所有设置
     */
    @Query("DELETE FROM user_settings")
    suspend fun deleteAll()
}