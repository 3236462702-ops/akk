package com.autoaccessibility.assistant.data

import androidx.room.TypeConverter
import com.autoaccessibility.assistant.model.TaskStep
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Room 类型转换器
 * 用于将复杂类型转换为数据库可存储的格式
 */
class Converters {
    private val gson = Gson()

    /**
     * 将 TaskStep 列表转换为 JSON 字符串
     */
    @TypeConverter
    fun fromTaskStepList(value: List<TaskStep>): String {
        return gson.toJson(value)
    }

    /**
     * 将 JSON 字符串转换为 TaskStep 列表
     */
    @TypeConverter
    fun toTaskStepList(value: String): List<TaskStep> {
        val type = object : TypeToken<List<TaskStep>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }

    /**
     * 将 String 映射转换为 JSON 字符串
     */
    @TypeConverter
    fun fromStringMap(value: Map<String, String>): String {
        return gson.toJson(value)
    }

    /**
     * 将 JSON 字符串转换为 String 映射
     */
    @TypeConverter
    fun toStringMap(value: String): Map<String, String> {
        val type = object : TypeToken<Map<String, String>>() {}.type
        return gson.fromJson(value, type) ?: emptyMap()
    }
}