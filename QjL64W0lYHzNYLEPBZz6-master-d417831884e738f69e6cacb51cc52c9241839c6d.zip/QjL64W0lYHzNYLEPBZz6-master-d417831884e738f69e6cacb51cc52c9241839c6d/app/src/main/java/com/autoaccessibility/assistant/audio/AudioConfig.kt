package com.autoaccessibility.assistant.audio

/**
 * 音效配置常量
 */
object AudioConfig {
    
    /**
     * 音效类型枚举
     */
    enum class SoundType {
        CLICK_SHORT,      // 短点击音（<1 秒）
        SUCCESS_DJ,       // 抢单成功 DJ 音效
        ERROR             // 错误提示音
    }
    
    /**
     * 音效资源 ID 映射
     */
    object SoundResource {
        const val CLICK_SHORT = -1  // 待分配
        const val SUCCESS_DJ = -2   // 待分配
        const val ERROR = -3        // 待分配
    }
    
    /**
     * 默认配置
     */
    const val DEFAULT_VOLUME = 80  // 默认音量 80%
    const val DEBOUNCE_TIME_MS = 300L  // 点击防抖时间
    const val MAX_SIMULTANEOUS_SOUNDS = 10  // 最大同时播放音效数
}