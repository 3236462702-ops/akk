package com.autoaccessibility.assistant.ai

import android.util.Log
import com.autoaccessibility.assistant.api.ApiClient
import com.autoaccessibility.assistant.api.ChatCompletionRequest
import com.autoaccessibility.assistant.api.Message
import com.autoaccessibility.assistant.api.ContentPart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * AI 智能决策服务
 * 集成 CSDN AI 对话 API（qwen-vl-plus）进行图文理解和逻辑判断
 */
class AiDecisionService {

    companion object {
        private const val TAG = "AiDecisionService"
        private const val MODEL_NAME = "qwen-vl-plus"
        
        @Volatile
        private var instance: AiDecisionService? = null
        
        fun getInstance(): AiDecisionService {
            return instance ?: synchronized(this) {
                instance ?: AiDecisionService().also { instance = it }
            }
        }
    }

    private val apiClient = ApiClient.csdnApiService

    /**
     * 基于屏幕截图和文字指令进行决策
     * @param base64Image 屏幕截图的 Base64 编码
     * @param instruction 决策指令（如："找出价格最高的商品"）
     * @return 决策结果
     */
    suspend fun makeDecision(base64Image: String, instruction: String): AiDecisionResult {
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "开始 AI 决策分析")
                
                // 构建图文混合请求
                val messages = listOf(
                    Message(
                        role = "user",
                        content = listOf(
                            ContentPart(type = "text", text = buildPrompt(instruction)),
                            ContentPart(
                                type = "image_url",
                                image_url = com.autoaccessibility.assistant.api.ImageUrl(url = "data:image/png;base64,$base64Image")
                            )
                        )
                    )
                )
                
                val request = ChatCompletionRequest(
                    model = MODEL_NAME,
                    messages = messages,
                    stream = false,
                    temperature = 0.3f,
                    max_tokens = 500
                )
                
                val response = apiClient.chatCompletion(ApiClient.getAuthHeader(), request)
                
                if (response.isSuccessful && response.body() != null) {
                    val chatResponse = response.body()!!
                    val aiContent = chatResponse.choices.firstOrNull()?.message?.content ?: ""
                    
                    Log.i(TAG, "AI 决策完成：$aiContent")
                    
                    // 解析 AI 返回的决策结果
                    parseDecisionResult(aiContent, instruction)
                } else {
                    val errorMsg = response.errorBody()?.string() ?: "未知错误"
                    Log.e(TAG, "AI 决策失败：$errorMsg")
                    
                    AiDecisionResult(
                        success = false,
                        actionType = DecisionAction.NONE,
                        description = "AI 决策失败：$errorMsg",
                        targetX = null,
                        targetY = null,
                        reason = errorMsg
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "AI 决策异常", e)
                AiDecisionResult(
                    success = false,
                    actionType = DecisionAction.NONE,
                    description = "决策异常：${e.message}",
                    targetX = null,
                    targetY = null,
                    reason = e.message ?: "未知异常"
                )
            }
        }
    }

    /**
     * 纯文本决策（不需要图片）
     * @param context 上下文信息（如 OCR 识别的文字）
     * @param instruction 决策指令
     * @return 决策结果
     */
    suspend fun makeTextDecision(context: String, instruction: String): AiDecisionResult {
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "开始文本决策分析")
                
                val fullPrompt = """
                    当前屏幕内容：
                    $context
                    
                    任务指令：$instruction
                    
                    请分析并给出决策。
                """.trimIndent()
                
                val messages = listOf(
                    Message(
                        role = "user",
                        content = fullPrompt
                    )
                )
                
                val request = ChatCompletionRequest(
                    model = "Deepseek-V3",
                    messages = messages,
                    stream = false,
                    temperature = 0.3f,
                    max_tokens = 500
                )
                
                val response = apiClient.chatCompletion(ApiClient.getAuthHeader(), request)
                
                if (response.isSuccessful && response.body() != null) {
                    val aiContent = response.body()!!.choices.firstOrNull()?.message?.content ?: ""
                    Log.i(TAG, "文本决策完成：$aiContent")
                    
                    parseDecisionResult(aiContent, instruction)
                } else {
                    val errorMsg = response.errorBody()?.string() ?: "未知错误"
                    AiDecisionResult(
                        success = false,
                        actionType = DecisionAction.NONE,
                        description = "决策失败：$errorMsg",
                        targetX = null,
                        targetY = null,
                        reason = errorMsg
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "文本决策异常", e)
                AiDecisionResult(
                    success = false,
                    actionType = DecisionAction.NONE,
                    description = "决策异常：${e.message}",
                    targetX = null,
                    targetY = null,
                    reason = e.message ?: "未知异常"
                )
            }
        }
    }

    /**
     * 构建决策 Prompt
     */
    private fun buildPrompt(instruction: String): String {
        return """
            你是一个智能自动化助手，需要分析手机屏幕截图并做出决策。
            
            任务指令：$instruction
            
            请仔细分析图片内容，然后：
            1. 识别出所有符合条件的目标元素
            2. 根据指令选择最优目标（如价格最高、评分最高等）
            3. 返回决策结果，包括：
               - 选择的理由
               - 目标元素的位置描述（如"左上角第二个商品"）
               - 建议的操作（点击、滑动等）
            
            请用简洁的中文回答。
        """.trimIndent()
    }

    /**
     * 解析 AI 决策结果
     */
    private fun parseDecisionResult(aiContent: String, originalInstruction: String): AiDecisionResult {
        // 简单的关键词匹配来提取决策信息
        val content = aiContent.lowercase()
        
        val actionType = when {
            content.contains("点击") || content.contains("选择") -> DecisionAction.CLICK
            content.contains("滑动") || content.contains("滚动") -> DecisionAction.SWIPE
            content.contains("长按") -> DecisionAction.LONG_PRESS
            content.contains("无") || content.contains("没有") || content.contains("未找到") -> DecisionAction.NONE
            else -> DecisionAction.CLICK  // 默认点击
        }
        
        // 尝试提取坐标（如果 AI 返回了具体坐标）
        val coordPattern = Regex("\\((\\d+)[,，]\\s*(\\d+)\\)")
        val match = coordPattern.find(aiContent)
        val targetX = match?.groupValues?.getOrNull(1)?.toIntOrNull()
        val targetY = match?.groupValues?.getOrNull(2)?.toIntOrNull()
        
        return AiDecisionResult(
            success = true,
            actionType = actionType,
            description = aiContent,
            targetX = targetX,
            targetY = targetY,
            reason = extractReason(aiContent)
        )
    }

    /**
     * 从 AI 回复中提取决策理由
     */
    private fun extractReason(content: String): String {
        // 简单实现：返回前 100 个字符作为理由
        return content.take(100)
    }

    /**
     * 销毁服务
     */
    fun destroy() {
        instance = null
        Log.d(TAG, "AI 决策服务已销毁")
    }
}

/**
 * 决策动作类型
 */
enum class DecisionAction {
    CLICK,      // 点击
    LONG_PRESS, // 长按
    SWIPE,      // 滑动
    NONE        // 无操作
}

/**
 * AI 决策结果
 */
data class AiDecisionResult(
    val success: Boolean,
    val actionType: DecisionAction,
    val description: String,           // AI 的完整决策描述
    val targetX: Int?,                 // 目标 X 坐标（如果有）
    val targetY: Int?,                 // 目标 Y 坐标（如果有）
    val reason: String                 // 决策理由
) {
    /**
     * 获取简要描述
     */
    fun getSummary(): String {
        return when (actionType) {
            DecisionAction.CLICK -> "点击操作：$reason"
            DecisionAction.LONG_PRESS -> "长按操作：$reason"
            DecisionAction.SWIPE -> "滑动操作：$reason"
            DecisionAction.NONE -> "无操作：$reason"
        }
    }
}