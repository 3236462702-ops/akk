package com.autoaccessibility.assistant.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.api.VerificationService
import com.autoaccessibility.assistant.config.VerificationManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 验证 Activity
 * 用户必须输入正确验证码才能进入主界面
 */
class VerificationActivity : AppCompatActivity() {

    private lateinit var etVerificationCode: TextInputEditText
    private lateinit var tilVerificationCode: TextInputLayout
    private lateinit var btnVerify: MaterialButton
    private lateinit var progressBar: View
    private lateinit var tvErrorHint: View
    private lateinit var tvFooter: View

    private val verificationService by lazy { VerificationService() }
    private val verificationManager by lazy { VerificationManager.getInstance(this) }

    private var isLoading = false
    private var attemptCount = 0
    private val maxAttempts = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verification)

        // 如果已经验证通过，直接跳转到主界面
        if (verificationManager.isVerified()) {
            navigateToMain()
            return
        }

        initViews()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        // 检查是否已验证（防止绕过）
        if (verificationManager.isVerified()) {
            navigateToMain()
        }
    }

    private fun initViews() {
        etVerificationCode = findViewById(R.id.etVerificationCode)
        tilVerificationCode = findViewById(R.id.tilVerificationCode)
        btnVerify = findViewById(R.id.btnVerify)
        progressBar = findViewById(R.id.progressBar)
        tvErrorHint = findViewById(R.id.tvErrorHint)
        tvFooter = findViewById(R.id.tvFooter)
    }

    private fun setupListeners() {
        // 输入框文本变化监听
        etVerificationCode.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                // 清除错误状态
                if (isLoading.not()) {
                    tilVerificationCode.error = null
                    tvErrorHint.visibility = View.GONE
                }
            }
        })

        // 验证按钮点击事件
        btnVerify.setOnClickListener {
            val code = etVerificationCode.text?.toString()?.trim()
            if (code.isNullOrEmpty()) {
                tilVerificationCode.error = getString(R.string.verification_code_empty)
                return@setOnClickListener
            }
            verifyCode(code)
        }
    }

    /**
     * 验证验证码
     */
    private fun verifyCode(inputCode: String) {
        if (isLoading) return
        if (attemptCount >= maxAttempts) {
            showError(getString(R.string.verification_max_attempts))
            return
        }

        isLoading = true
        updateUIForLoading(true)

        lifecycleScope.launch {
            try {
                // 从网络获取正确验证码
                val correctCode = withContext(Dispatchers.IO) {
                    verificationService.getVerificationCode()
                }

                // 验证输入
                val isValid = correctCode.equals(inputCode, ignoreCase = true)

                if (isValid) {
                    // 验证成功
                    verificationManager.setVerified(true)
                    showSuccess()
                } else {
                    // 验证失败
                    attemptCount++
                    val remainingAttempts = maxAttempts - attemptCount
                    if (remainingAttempts > 0) {
                        showError(getString(R.string.verification_failed_with_remaining, remainingAttempts))
                    } else {
                        showError(getString(R.string.verification_max_attempts))
                    }
                }
            } catch (e: Exception) {
                // 网络异常或其他错误
                showError(getString(R.string.verification_network_error, e.message ?: "Unknown error"))
            } finally {
                isLoading = false
                updateUIForLoading(false)
            }
        }
    }

    private fun updateUIForLoading(loading: Boolean) {
        btnVerify.isEnabled = !loading
        etVerificationCode.isEnabled = !loading
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        if (loading) {
            btnVerify.text = getString(R.string.verifying)
        } else {
            btnVerify.text = getString(R.string.verify_button)
        }
    }

    private fun showSuccess() {
        tilVerificationCode.error = null
        tvErrorHint.visibility = View.GONE
        // 延迟跳转，让用户看到成功状态
        lifecycleScope.launch {
            kotlinx.coroutines.delay(500)
            navigateToMain()
        }
    }

    private fun showError(message: String) {
        tilVerificationCode.error = " "
        tvErrorHint.visibility = View.VISIBLE
        (tvErrorHint as? android.widget.TextView)?.text = message
        // 清空输入框
        etVerificationCode.text?.clear()
        etVerificationCode.requestFocus()
    }

    private fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    /**
     * 禁用返回键，防止跳过验证
     */
    override fun onBackPressed() {
        // 不执行任何操作，禁用返回键
    }

    /**
     * 禁用 Home 键后的重新检查
     */
    override fun onRestart() {
        super.onRestart()
        // 从后台返回时重新检查验证状态
        if (verificationManager.isVerified().not()) {
            // 确保仍在验证页面
        }
    }
}