package com.autoaccessibility.assistant.example

import com.autoaccessibility.assistant.model.ActionType
import com.autoaccessibility.assistant.model.TaskScript
import com.autoaccessibility.assistant.model.TaskStep

/**
 * 智能购物比价任务示例
 * 
 * 功能说明：
 * 1. 捕获当前屏幕（商品列表页）
 * 2. OCR 识别屏幕上的所有商品价格
 * 3. AI 分析并选择价格最高的商品
 * 4. 自动点击该商品查看详情
 * 
 * 使用场景：自动找出最贵的商品、自动比价等
 */
object SmartShoppingTask {

    /**
     * 创建智能比价任务脚本
     */
    fun createSmartShoppingScript(): TaskScript {
        return TaskScript(
            name = "智能比价 - 选择最贵商品",
            description = "自动识别屏幕上的商品价格，并点击价格最高的商品",
            steps = listOf(
                // 步骤 1: 等待页面加载完成
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "等待页面加载",
                    duration = 2000,
                    delay = 500
                ),
                
                // 步骤 2: 捕获屏幕
                TaskStep(
                    actionType = ActionType.SCREEN_CAPTURE,
                    description = "捕获当前商品列表页面",
                    delay = 500
                ),
                
                // 步骤 3: OCR 识别屏幕文字
                TaskStep(
                    actionType = ActionType.OCR_ANALYZE,
                    description = "识别屏幕上的商品价格信息",
                    delay = 1000
                ),
                
                // 步骤 4: AI 智能决策 - 找出价格最高的商品并点击
                TaskStep(
                    actionType = ActionType.AI_DECIDE,
                    description = "分析商品价格，选择并点击最贵的商品",
                    text = "这是一个商品列表页面，请找出价格最高的商品，并返回它的点击坐标。如果有多个商品，选择单价最高的那个。",
                    delay = 2000
                ),
                
                // 步骤 5: 等待商品详情页加载
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "等待商品详情页加载",
                    duration = 3000,
                    delay = 500
                ),
                
                // 步骤 6: 完成任务
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "任务完成",
                    duration = 1000,
                    delay = 0
                )
            )
        )
    }

    /**
     * 创建自定义 AI 决策任务
     * @param instruction AI 决策指令，如"点击登录按钮"、"找出最便宜的商品"
     */
    fun createAiDecisionTask(instruction: String): TaskScript {
        return TaskScript(
            name = "AI 智能决策任务",
            description = "使用 AI 分析屏幕内容并执行智能操作：$instruction",
            steps = listOf(
                // 等待
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "准备执行",
                    duration = 1000,
                    delay = 500
                ),
                
                // 捕获屏幕
                TaskStep(
                    actionType = ActionType.SCREEN_CAPTURE,
                    description = "捕获当前屏幕",
                    delay = 500
                ),
                
                // AI 决策并执行
                TaskStep(
                    actionType = ActionType.AI_DECIDE,
                    description = "AI 分析并执行：$instruction",
                    text = instruction,
                    delay = 2000
                ),
                
                // 完成
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "任务完成",
                    duration = 1000,
                    delay = 0
                )
            )
        )
    }

    /**
     * 创建循环比价任务（多页比较）
     */
    fun createMultiPageComparisonScript(): TaskScript {
        return TaskScript(
            name = "多页比价任务",
            description = "滚动多页商品列表，找出最贵的商品",
            steps = listOf(
                // 初始化
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "准备开始",
                    duration = 1000,
                    delay = 500
                ),
                
                // 循环开始：最多滚动 5 页
                TaskStep(
                    actionType = ActionType.LOOP_START,
                    description = "开始循环比价（最多 5 页）",
                    loopCount = 5,
                    delay = 0
                ),
                
                // 捕获当前页
                TaskStep(
                    actionType = ActionType.SCREEN_CAPTURE,
                    description = "捕获当前页商品",
                    delay = 500
                ),
                
                // OCR 识别
                TaskStep(
                    actionType = ActionType.OCR_ANALYZE,
                    description = "识别商品价格",
                    delay = 1000
                ),
                
                // AI 记录当前页最贵商品（由 TaskEngine 维护上下文）
                TaskStep(
                    actionType = ActionType.AI_DECIDE,
                    description = "记录当前页最贵商品信息",
                    text = "记录这一页所有商品的价格信息，用于后续比较",
                    delay = 1000
                ),
                
                // 向下滑动到下一页
                TaskStep(
                    actionType = ActionType.SWIPE,
                    description = "滑动到下一页",
                    startY = null, // 由 GestureController 计算
                    endY = null,
                    duration = 500,
                    delay = 1500
                ),
                
                // 循环结束
                TaskStep(
                    actionType = ActionType.LOOP_END,
                    description = "检查是否继续循环",
                    delay = 500
                ),
                
                // 最终决策：点击最贵的商品
                TaskStep(
                    actionType = ActionType.AI_DECIDE,
                    description = "在所有记录中选择最贵的商品并点击",
                    text = "根据之前记录的所有商品信息，找出价格最高的商品并返回它的坐标位置，然后点击它",
                    delay = 2000
                ),
                
                // 完成
                TaskStep(
                    actionType = ActionType.WAIT,
                    description = "任务完成",
                    duration = 1000,
                    delay = 0
                )
            )
        )
    }
}