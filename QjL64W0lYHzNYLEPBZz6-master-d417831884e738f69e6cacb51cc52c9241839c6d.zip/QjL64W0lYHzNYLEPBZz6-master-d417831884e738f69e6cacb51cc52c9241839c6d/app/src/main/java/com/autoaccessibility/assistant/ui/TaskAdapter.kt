package com.autoaccessibility.assistant.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.model.TaskScript
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 任务列表适配器
 */
class TaskAdapter(
    private val tasks: MutableList<TaskScript>,
    private val listener: TaskClickListener
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    interface TaskClickListener {
        fun onTaskClick(task: TaskScript)
        fun onTaskToggle(task: TaskScript, isEnabled: Boolean)
        fun onTaskDelete(task: TaskScript)
    }

    inner class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val iconView: ImageView = itemView.findViewById(R.id.taskIcon)
        val titleView: TextView = itemView.findViewById(R.id.taskTitle)
        val descView: TextView = itemView.findViewById(R.id.taskDesc)
        val timeView: TextView = itemView.findViewById(R.id.taskTime)
        val switchView: Switch = itemView.findViewById(R.id.taskSwitch)
        val deleteBtn: ImageButton = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        
        // 设置图标（根据任务类型）
        holder.iconView.setImageResource(getTaskIcon(task))
        
        // 设置标题和描述
        holder.titleView.text = task.name
        holder.descView.text = task.description
        
        // 设置最后运行时间（使用 updatedAt 代替）
        holder.timeView.text = formatLastRunTime(task.updatedAt)
        
        // 设置开关状态
        holder.switchView.isChecked = task.isEnabled
        holder.switchView.setOnCheckedChangeListener { _, isChecked ->
            listener.onTaskToggle(task, isChecked)
        }
        
        // 点击事件
        holder.itemView.setOnClickListener {
            listener.onTaskClick(task)
        }
        
        // 删除按钮
        holder.deleteBtn.setOnClickListener {
            listener.onTaskDelete(task)
        }
    }

    override fun getItemCount(): Int = tasks.size

    /**
     * 获取任务图标
     */
    private fun getTaskIcon(task: TaskScript): Int {
        return when {
            task.name.contains("微信") -> R.drawable.ic_task
            task.name.contains("抖音") -> R.drawable.ic_task
            task.name.contains("签到") -> R.drawable.ic_task
            else -> R.drawable.ic_task
        }
    }

    /**
     * 格式化最后运行时间
     */
    private fun formatLastRunTime(timestamp: Long): String {
        if (timestamp <= 0) {
            return "从未运行"
        }
        
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        
        return when {
            diff < 60_000 -> "刚刚"
            diff < 3600_000 -> "${diff / 60_000}分钟前"
            diff < 86400_000 -> "${diff / 3600_000}小时前"
            else -> SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(timestamp))
        }
    }
}