package com.autoaccessibility.assistant.api

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * 验证服务
 * 负责从网络获取验证码并进行校验
 */
class VerificationService {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    // 验证码获取 URL
    private val verificationUrl = "https://sharechain.qq.com/46628e1139e9f2e1b221982c3bd3c484"

    // 本地缓存的验证码
    private var cachedCode: String? = null
    private var cacheTimestamp: Long = 0
    private val cacheDuration = 5 * 60 * 1000L // 5 分钟缓存

    /**
     * 从网络获取验证码
     * @return 验证码字符串
     * @throws Exception 网络请求失败时抛出异常
     */
    @Throws(Exception::class)
    suspend fun getVerificationCode(): String {
        // 检查缓存是否有效
        val currentTime = System.currentTimeMillis()
        if (cachedCode != null && (currentTime - cacheTimestamp) < cacheDuration) {
            return cachedCode!!
        }

        // 发起网络请求
        val request = Request.Builder()
            .url(verificationUrl)
            .get()
            .build()

        val response = client.newCall(request).execute()
        
        if (!response.isSuccessful) {
            throw Exception("Failed to fetch verification code: ${response.code}")
        }

        val body = response.body?.string()?.trim()
        if (body.isNullOrEmpty()) {
            throw Exception("Verification code is empty")
        }

        // 更新缓存
        cachedCode = body
        cacheTimestamp = currentTime

        return body
    }

    /**
     * 清除缓存
     */
    fun clearCache() {
        cachedCode = null
        cacheTimestamp = 0
    }

    /**
     * 验证输入的验证码是否正确
     * @param inputCode 用户输入的验证码
     * @return 是否匹配
     */
    suspend fun verifyCode(inputCode: String): Boolean {
        return try {
            val correctCode = getVerificationCode()
            correctCode.equals(inputCode, ignoreCase = true)
        } catch (e: Exception) {
            false
        }
    }
}