package com.autoaccessibility.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.autoaccessibility.assistant.model.TaskScript
import com.autoaccessibility.assistant.model.UserSettings

/**
 * Room 数据库
 * 存储自动化任务脚本、执行日志和用户设置
 */
@Database(
    entities = [TaskScript::class, UserSettings::class],
    version = 3,
    exportSchema = false
)
@androidx.room.TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Migration 2 -> 3: 添加点击延迟配置字段
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // 添加固定延迟字段（默认 500ms）
                database.execSQL("ALTER TABLE user_settings ADD COLUMN clickDelayFixed INTEGER NOT NULL DEFAULT 500")
                // 添加随机延迟开关字段（默认 false）
                database.execSQL("ALTER TABLE user_settings ADD COLUMN clickDelayRandom INTEGER NOT NULL DEFAULT 0")
                // 注：clickDelayRandomMin 和 clickDelayRandomMax 使用固定值 200 和 2000，不存入数据库
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "auto_assistant_database"
                )
                    .addMigrations(MIGRATION_2_3)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}