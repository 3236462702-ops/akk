package com.autoaccessibility.assistant.config

import android.content.Context
import android.util.Log
import com.autoaccessibility.assistant.data.SettingsRepository
import com.autoaccessibility.assistant.model.UserSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import org.json.JSONObject

/**
 * 设置管理器
 * 统一管理和分发用户配置变更
 */
class SettingsManager private constructor() {

    companion object {
        private const val TAG = "SettingsManager"
        private const val BACKUP_FILE_NAME = "user_settings_backup.json"
        
        @Volatile
        private var instance: SettingsManager? = null
        
        fun getInstance(): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager().also { instance = it }
            }
        }
    }

    private var repository: SettingsRepository? = null
    
    // 配置的 StateFlow，支持响应式更新
    private val _settingsFlow = MutableStateFlow(UserSettings.getDefault())
    val settingsFlow: StateFlow<UserSettings> = _settingsFlow.asStateFlow()
    
    // 当前配置缓存
    private var currentSettings: UserSettings = UserSettings.getDefault()
    
    // 配置变更监听器
    private val listeners = mutableListOf<(UserSettings) -> Unit>()
    
    /**
     * 初始化设置管理器
     */
    fun initialize(context: Context) {
        if (repository == null) {
            repository = SettingsRepository.getInstance(context)
            // 使用默认值初始化，实际配置异步加载
            updateSettings(UserSettings.getDefault(), notify = false)
            // 在后台线程中加载配置
            Thread {
                try {
                    val settings = repository?.getSettingsBlocking() ?: UserSettings.getDefault()
                    updateSettings(settings, notify = false)
                    Log.d(TAG, "配置已加载：刷新间隔=${settings.refreshIntervalSeconds}s")
                } catch (e: Exception) {
                    Log.e(TAG, "加载配置失败", e)
                    updateSettings(UserSettings.getDefault(), notify = false)
                }
            }.start()
        }
    }
    
    /**
     * 加载用户配置（协程版本）
     */
    suspend fun loadSettings() {
        try {
            val settings = repository?.getSettings() ?: UserSettings.getDefault()
            updateSettings(settings, notify = false)
            Log.d(TAG, "配置已加载：刷新间隔=${settings.refreshIntervalSeconds}s")
        } catch (e: Exception) {
            Log.e(TAG, "加载配置失败", e)
            updateSettings(UserSettings.getDefault(), notify = false)
        }
    }
    
    /**
     * 加载用户配置（阻塞版本，用于非协程环境）
     */
    fun loadSettingsBlocking(): UserSettings {
        return try {
            val settings = repository?.getSettingsBlocking() ?: UserSettings.getDefault()
            updateSettings(settings, notify = false)
            Log.d(TAG, "配置已加载：刷新间隔=${settings.refreshIntervalSeconds}s")
            settings
        } catch (e: Exception) {
            Log.e(TAG, "加载配置失败", e)
            UserSettings.getDefault()
        }
    }
    
    /**
     * 保存用户配置
     */
    suspend fun saveSettings(settings: UserSettings): Boolean {
        return try {
            val updated = settings.copy(updatedAt = System.currentTimeMillis())
            repository?.saveSettings(updated)
            updateSettings(updated)
            backupSettings(settings)
            Log.d(TAG, "配置已保存")
            true
        } catch (e: Exception) {
            Log.e(TAG, "保存配置失败", e)
            false
        }
    }
    
    /**
     * 更新刷新间隔
     */
    suspend fun updateRefreshInterval(seconds: Int): Boolean {
        if (!UserSettings.isValidRefreshInterval(seconds)) {
            Log.w(TAG, "无效的刷新间隔：$seconds")
            return false
        }
        
        val updated = currentSettings.copy(refreshIntervalSeconds = seconds)
        return saveSettings(updated)
    }
    
    /**
     * 更新价格过滤设置
     */
    suspend fun updatePriceFilter(
        enabled: Boolean,
        minPrice: Double,
        maxPrice: Double
    ): Boolean {
        if (!UserSettings.isValidPriceRange(minPrice, maxPrice)) {
            Log.w(TAG, "无效的价格区间：$minPrice-$maxPrice")
            return false
        }
        
        val updated = currentSettings.copy(
            enablePriceFilter = enabled,
            minPrice = minPrice,
            maxPrice = maxPrice
        )
        return saveSettings(updated)
    }
    
    /**
     * 更新距离过滤设置
     */
    suspend fun updateDistanceFilter(
        enabled: Boolean,
        maxPickupDistance: Double
    ): Boolean {
        if (!UserSettings.isValidDistance(maxPickupDistance)) {
            Log.w(TAG, "无效的距离：$maxPickupDistance")
            return false
        }
        
        val updated = currentSettings.copy(
            enableDistanceFilter = enabled,
            maxPickupDistance = maxPickupDistance
        )
        return saveSettings(updated)
    }
    
    /**
     * 更新行程距离过滤设置
     */
    suspend fun updateTripDistanceFilter(
        enabled: Boolean,
        minDistance: Double,
        maxDistance: Double
    ): Boolean {
        if (!UserSettings.isValidDistance(minDistance) || 
            !UserSettings.isValidDistance(maxDistance) ||
            minDistance > maxDistance) {
            Log.w(TAG, "无效的行程距离：$minDistance-$maxDistance")
            return false
        }
        
        val updated = currentSettings.copy(
            enableTripDistanceFilter = enabled,
            minTripDistance = minDistance,
            maxTripDistance = maxDistance
        )
        return saveSettings(updated)
    }
    
    /**
     * 更新自动抢单总开关
     */
    suspend fun setAutoGrabEnabled(enabled: Boolean): Boolean {
        val updated = currentSettings.copy(autoGrabEnabled = enabled)
        return saveSettings(updated)
    }
    
    /**
     * 获取实际点击延迟（根据是否随机返回计算值）
     */
    fun getClickDelay(): Int {
        return if (currentSettings.clickDelayRandom) {
            // 随机延迟：200-2000ms
            (200..2000).random()
        } else {
            // 固定延迟
            currentSettings.clickDelayFixed
        }
    }
    
    /**
     * 获取实际刷新延迟（根据是否随机返回计算值）
     * 未设置时默认按 2 秒（2000ms）执行
     */
    fun getRefreshDelay(): Int {
        return if (currentSettings.refreshDelayRandom) {
            // 随机延迟：2000-5000ms（2-5 秒）
            (UserSettings.REFRESH_RANDOM_DELAY_MIN_MS..UserSettings.REFRESH_RANDOM_DELAY_MAX_MS).random()
        } else {
            // 固定延迟：1000-10000ms（1-10 秒），默认 2000ms
            currentSettings.refreshDelayFixed.coerceIn(
                UserSettings.REFRESH_DELAY_MIN_MS,
                UserSettings.REFRESH_DELAY_MAX_MS
            )
        }
    }
    
    /**
     * 设置固定延迟
     */
    suspend fun setFixedDelay(delayMs: Int): Boolean {
        if (!UserSettings.isValidClickDelay(delayMs)) {
            Log.w(TAG, "无效的固定延迟：$delayMs")
            return false
        }
        
        val updated = currentSettings.copy(
            clickDelayFixed = delayMs,
            clickDelayRandom = false  // 设置固定延迟时自动关闭随机模式
        )
        return saveSettings(updated)
    }
    
    /**
     * 设置是否启用随机延迟
     */
    suspend fun setRandomDelay(enabled: Boolean): Boolean {
        val updated = currentSettings.copy(clickDelayRandom = enabled)
        return saveSettings(updated)
    }
    
    /**
     * 检查是否启用随机延迟
     */
    fun isRandomDelay(): Boolean {
        return currentSettings.clickDelayRandom
    }
    
    /**
     * 获取固定延迟值
     */
    fun getFixedDelay(): Int {
        return currentSettings.clickDelayFixed
    }
    
    /**
     * 设置刷新固定延迟
     */
    suspend fun setRefreshFixedDelay(delayMs: Int): Boolean {
        if (!UserSettings.isValidRefreshDelay(delayMs)) {
            Log.w(TAG, "无效的刷新固定延迟：$delayMs")
            return false
        }
        
        val updated = currentSettings.copy(
            refreshDelayFixed = delayMs,
            refreshDelayRandom = false  // 设置固定延迟时自动关闭随机模式
        )
        return saveSettings(updated)
    }
    
    /**
     * 设置是否启用随机刷新延迟
     */
    suspend fun setRefreshRandomDelay(enabled: Boolean): Boolean {
        val updated = currentSettings.copy(refreshDelayRandom = enabled)
        return saveSettings(updated)
    }
    
    /**
     * 更新区域过滤设置（新接口：两个互斥的勾选框）
     */
    suspend fun updateRegionFilter(
        excludeEnabled: Boolean,
        includeEnabled: Boolean,
        excludedDistricts: List<String> = emptyList(),
        includedDistricts: List<String> = emptyList()
    ): Boolean {
        // 确保互斥：不能同时启用
        val actualExclude = if (includeEnabled) false else excludeEnabled
        val actualInclude = if (excludeEnabled) false else includeEnabled
        
        val updated = currentSettings.copy(
            excludeRegionEnabled = actualExclude,
            includeRegionEnabled = actualInclude,
            excludedDistricts = excludedDistricts.joinToString(","),
            includedDistricts = includedDistricts.joinToString(",")
        )
        return saveSettings(updated)
    }
    
    /**
     * 更新区域过滤设置（旧接口兼容）
     */
    suspend fun updateRegionFilterLegacy(
        mode: com.autoaccessibility.assistant.model.RegionFilterMode,
        excludedDistricts: List<String> = emptyList(),
        includedDistricts: List<String> = emptyList()
    ): Boolean {
        val (excludeEnabled, includeEnabled) = com.autoaccessibility.assistant.model.convertLegacyRegionFilterMode(
            mode,
            excludedDistricts.joinToString(","),
            includedDistricts.joinToString(",")
        )
        return updateRegionFilter(excludeEnabled, includeEnabled, excludedDistricts, includedDistricts)
    }
    
    /**
     * 检查是否启用随机刷新延迟
     */
    fun isRefreshRandomDelay(): Boolean {
        return currentSettings.refreshDelayRandom
    }
    
    /**
     * 获取刷新固定延迟值
     */
    fun getRefreshFixedDelay(): Int {
        return currentSettings.refreshDelayFixed
    }
    
    /**
     * 重置为默认配置
     */
    suspend fun resetToDefaults(): Boolean {
        return saveSettings(UserSettings.getDefault())
    }
    
    /**
     * 获取当前配置
     */
    fun getCurrentSettings(): UserSettings {
        return currentSettings
    }
    
    /**
     * 添加配置变更监听器
     */
    fun addListener(listener: (UserSettings) -> Unit) {
        listeners.add(listener)
        // 立即通知当前配置
        listener(currentSettings)
    }
    
    /**
     * 移除配置变更监听器
     */
    fun removeListener(listener: (UserSettings) -> Unit) {
        listeners.remove(listener)
    }
    
    /**
     * 更新内部配置并通知监听器
     */
    private fun updateSettings(settings: UserSettings, notify: Boolean = true) {
        currentSettings = settings
        _settingsFlow.value = settings
        
        if (notify) {
            listeners.forEach { listener ->
                try {
                    listener(settings)
                } catch (e: Exception) {
                    Log.e(TAG, "通知监听器失败", e)
                }
            }
        }
    }
    
    /**
     * 备份配置到本地文件
     */
    private fun backupSettings(settings: UserSettings, context: Context? = null) {
        try {
            // 简化实现，实际使用时需要传入 context
            val json = JSONObject().apply {
                put("refreshIntervalSeconds", settings.refreshIntervalSeconds)
                put("enablePriceFilter", settings.enablePriceFilter)
                put("minPrice", settings.minPrice)
                put("maxPrice", settings.maxPrice)
                put("enableDistanceFilter", settings.enableDistanceFilter)
                put("maxPickupDistance", settings.maxPickupDistance)
                put("enableTripDistanceFilter", settings.enableTripDistanceFilter)
                put("minTripDistance", settings.minTripDistance)
                put("maxTripDistance", settings.maxTripDistance)
                put("autoGrabEnabled", settings.autoGrabEnabled)
                put("clickDelayFixed", settings.clickDelayFixed)
                put("clickDelayRandom", settings.clickDelayRandom)
                put("refreshDelayFixed", settings.refreshDelayFixed)
                put("refreshDelayRandom", settings.refreshDelayRandom)
                put("updatedAt", settings.updatedAt)
            }
            
            Log.d(TAG, "配置备份：$json")
            // 实际使用时写入文件：context.filesDir.resolve(BACKUP_FILE_NAME).writeText(json.toString())
        } catch (e: Exception) {
            Log.e(TAG, "备份配置失败", e)
        }
    }
    
    /**
     * 从备份文件恢复配置
     */
    fun restoreFromBackup(context: Context): Boolean {
        return try {
            val backupFile = File(context.filesDir, BACKUP_FILE_NAME)
            if (!backupFile.exists()) {
                Log.w(TAG, "备份文件不存在")
                return false
            }
            
            val json = JSONObject(backupFile.readText())
            val settings = UserSettings(
                refreshIntervalSeconds = json.getInt("refreshIntervalSeconds"),
                enablePriceFilter = json.getBoolean("enablePriceFilter"),
                minPrice = json.getDouble("minPrice"),
                maxPrice = json.getDouble("maxPrice"),
                enableDistanceFilter = json.getBoolean("enableDistanceFilter"),
                maxPickupDistance = json.getDouble("maxPickupDistance"),
                enableTripDistanceFilter = json.getBoolean("enableTripDistanceFilter"),
                minTripDistance = json.getDouble("minTripDistance"),
                maxTripDistance = json.getDouble("maxTripDistance"),
                autoGrabEnabled = json.getBoolean("autoGrabEnabled"),
                clickDelayFixed = json.optInt("clickDelayFixed", UserSettings.DELAY_DEFAULT_MS),
                clickDelayRandom = json.optBoolean("clickDelayRandom", false),
                refreshDelayFixed = json.optInt("refreshDelayFixed", UserSettings.REFRESH_DELAY_DEFAULT_MS),
                refreshDelayRandom = json.optBoolean("refreshDelayRandom", false)
            )
            
            updateSettings(settings)
            Log.d(TAG, "已从备份恢复配置")
            true
        } catch (e: Exception) {
            Log.e(TAG, "恢复备份失败", e)
            false
        }
    }
    
    /**
     * 导出配置为 JSON 字符串
     */
    fun exportToJson(): String {
        return JSONObject().apply {
            put("version", 1)
            put("exportedAt", System.currentTimeMillis())
            put("settings", JSONObject().apply {
                put("refreshIntervalSeconds", currentSettings.refreshIntervalSeconds)
                put("enablePriceFilter", currentSettings.enablePriceFilter)
                put("minPrice", currentSettings.minPrice)
                put("maxPrice", currentSettings.maxPrice)
                put("enableDistanceFilter", currentSettings.enableDistanceFilter)
                put("maxPickupDistance", currentSettings.maxPickupDistance)
                put("enableTripDistanceFilter", currentSettings.enableTripDistanceFilter)
                put("minTripDistance", currentSettings.minTripDistance)
                put("maxTripDistance", currentSettings.maxTripDistance)
                put("autoGrabEnabled", currentSettings.autoGrabEnabled)
                put("clickDelayFixed", currentSettings.clickDelayFixed)
                put("clickDelayRandom", currentSettings.clickDelayRandom)
                put("refreshDelayFixed", currentSettings.refreshDelayFixed)
                put("refreshDelayRandom", currentSettings.refreshDelayRandom)
                put("excludeRegionEnabled", currentSettings.excludeRegionEnabled)
                put("includeRegionEnabled", currentSettings.includeRegionEnabled)
                put("excludedDistricts", currentSettings.excludedDistricts)
                put("includedDistricts", currentSettings.includedDistricts)
                put("totalRefreshCount", currentSettings.totalRefreshCount)
                put("totalFilteredOrders", currentSettings.totalFilteredOrders)
                put("totalGrabbedOrders", currentSettings.totalGrabbedOrders)
            })
        }.toString(2)
    }
    
    /**
     * 从 JSON 字符串导入配置
     */
    fun importFromJson(jsonString: String): Boolean {
        return try {
            val json = JSONObject(jsonString)
            val settingsJson = json.getJSONObject("settings")
            
            // 优先使用新的布尔值字段，如果不存在则从旧模式转换
            val excludeRegionEnabled = settingsJson.optBoolean("excludeRegionEnabled", false)
            val includeRegionEnabled = settingsJson.optBoolean("includeRegionEnabled", false)
            
            val imported = UserSettings(
                refreshIntervalSeconds = settingsJson.getInt("refreshIntervalSeconds"),
                enablePriceFilter = settingsJson.getBoolean("enablePriceFilter"),
                minPrice = settingsJson.getDouble("minPrice"),
                maxPrice = settingsJson.getDouble("maxPrice"),
                enableDistanceFilter = settingsJson.getBoolean("enableDistanceFilter"),
                maxPickupDistance = settingsJson.getDouble("maxPickupDistance"),
                enableTripDistanceFilter = settingsJson.getBoolean("enableTripDistanceFilter"),
                minTripDistance = settingsJson.getDouble("minTripDistance"),
                maxTripDistance = settingsJson.getDouble("maxTripDistance"),
                autoGrabEnabled = settingsJson.getBoolean("autoGrabEnabled"),
                clickDelayFixed = settingsJson.optInt("clickDelayFixed", UserSettings.DELAY_DEFAULT_MS),
                clickDelayRandom = settingsJson.optBoolean("clickDelayRandom", false),
                refreshDelayFixed = settingsJson.optInt("refreshDelayFixed", UserSettings.REFRESH_DELAY_DEFAULT_MS),
                refreshDelayRandom = settingsJson.optBoolean("refreshDelayRandom", false),
                excludeRegionEnabled = excludeRegionEnabled,
                includeRegionEnabled = includeRegionEnabled,
                excludedDistricts = settingsJson.optString("excludedDistricts", ""),
                includedDistricts = settingsJson.optString("includedDistricts", ""),
                totalRefreshCount = settingsJson.optLong("totalRefreshCount", 0),
                totalFilteredOrders = settingsJson.optLong("totalFilteredOrders", 0),
                totalGrabbedOrders = settingsJson.optLong("totalGrabbedOrders", 0)
            )
            
            updateSettings(imported)
            Log.d(TAG, "已导入配置")
            true
        } catch (e: Exception) {
            Log.e(TAG, "导入配置失败", e)
            false
        }
    }
    
    /**
     * 清理资源
     */
    fun destroy() {
        listeners.clear()
        instance = null
    }
}