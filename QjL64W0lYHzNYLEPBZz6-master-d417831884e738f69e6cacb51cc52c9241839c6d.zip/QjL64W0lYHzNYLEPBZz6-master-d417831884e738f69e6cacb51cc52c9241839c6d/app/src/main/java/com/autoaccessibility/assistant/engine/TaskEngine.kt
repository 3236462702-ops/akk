package com.autoaccessibility.assistant.engine

import android.content.Context
import android.util.Log
import com.autoaccessibility.assistant.config.SettingsManager
import com.autoaccessibility.assistant.controller.GestureController
import com.autoaccessibility.assistant.data.SettingsRepository
import com.autoaccessibility.assistant.filter.OrderFilterEngine
import com.autoaccessibility.assistant.log.OrderLogManager
import com.autoaccessibility.assistant.log.GrabResult
import com.autoaccessibility.assistant.service.FloatingWindowService.GrabState
import com.autoaccessibility.assistant.model.ActionType
import com.autoaccessibility.assistant.model.OrderInfo
import com.autoaccessibility.assistant.model.OrderType
import com.autoaccessibility.assistant.model.TaskScript
import com.autoaccessibility.assistant.model.TaskStep
import com.autoaccessibility.assistant.recognition.ButtonRecognizer
import com.autoaccessibility.assistant.recognition.ResultRecognizer
import com.autoaccessibility.assistant.recognition.GrabResultType
import com.autoaccessibility.assistant.recognition.ResultCallback
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * 自动化任务执行引擎
 * 负责解析、调度和执行自动化脚本
 * 
 * 支持智能延迟点击和抢单结果自动识别
 */
class TaskEngine {

    companion object {
        private const val TAG = "TaskEngine"
        
        @Volatile
        private var instance: TaskEngine? = null
        
        /**
         * 获取单例实例
         */
        fun getInstance(): TaskEngine {
            return instance ?: synchronized(this) {
                instance ?: TaskEngine().also { instance = it }
            }
        }
    }

    private val gestureController = GestureController()
    private var coroutineScope: CoroutineScope? = null
    private val isRunning = AtomicBoolean(false)
    private var currentJob: Job? = null
    
    // 执行上下文（用于步骤间数据传递）
    private val executionContext = mutableMapOf<String, Any>()
    
    // 订单过滤引擎和设置仓库（延迟初始化）
    private var settingsRepository: SettingsRepository? = null
    private var filterEngine: OrderFilterEngine? = null
    private var settingsManager: SettingsManager? = null
    
    // 按钮识别器
    private var buttonRecognizer: ButtonRecognizer? = null
    
    // 结果识别器
    private var resultRecognizer: ResultRecognizer? = null
    
    // 日志管理器
    private val logManager = OrderLogManager.getInstance()
    
    // 上下文引用（用于 SoundManager 等需要 Context 的组件）
    private var appContext: Context? = null
    
    // 抢单状态机
    private var grabState: GrabState = GrabState.IDLE
    
    // 执行状态监听
    var onTaskStarted: ((TaskScript) -> Unit)? = null
    var onTaskProgress: ((TaskScript, Int, Int) -> Unit)? = null  // 当前步骤，总步骤
    var onTaskCompleted: ((TaskScript, Boolean, String?) -> Unit)? = null  // 任务，成功与否，错误信息
    var onStepExecuted: ((TaskScript, TaskStep, Boolean) -> Unit)? = null
    var onContextUpdated: ((Map<String, Any>) -> Unit)? = null  // 上下文更新通知
    var onGrabStateChanged: ((GrabState) -> Unit)? = null  // 抢单状态变化通知

    /**
     * 检查服务是否可用
     */
    fun isServiceAvailable(): Boolean {
        return gestureController.isServiceAvailable()
    }

    /**
     * 初始化手势控制器的服务依赖
     */
    fun initializeServices(
        captureManager: com.autoaccessibility.assistant.capture.ScreenCaptureManager,
        ocrService: com.autoaccessibility.assistant.ocr.OcrService,
        aiService: com.autoaccessibility.assistant.ai.AiDecisionService,
        context: Context? = null
    ) {
        gestureController.screenCaptureManager = captureManager
        gestureController.ocrService = ocrService
        gestureController.aiDecisionService = aiService
        
        // 初始化设置仓库、过滤引擎和按钮识别器
        if (context != null) {
            appContext = context.applicationContext
            settingsRepository = SettingsRepository.getInstance(context)
            settingsManager = SettingsManager.getInstance()
            settingsManager?.initialize(context)
            filterEngine = OrderFilterEngine.getInstance()
            filterEngine?.initialize(context)
            buttonRecognizer = ButtonRecognizer.getInstance()
            
            // 初始化结果识别器
            resultRecognizer = ResultRecognizer.getInstance()
            resultRecognizer?.initialize(captureManager)
            resultRecognizer?.registerCallback(object : ResultCallback {
                override fun onResult(result: GrabResultType, reason: String) {
                    handleGrabResult(result, reason)
                }
            })
        }
        
        updateGrabState(GrabState.IDLE)
        Log.d(TAG, "任务引擎服务已初始化（含延迟控制和结果识别）")
    }
    
    /**
     * 获取实际延迟时间（根据固定/随机设置）
     */
    private fun getActualDelayMs(): Int {
        val settings = settingsManager?.getCurrentSettings() ?: return 500
        
        return if (settings.clickDelayRandom) {
            // 随机延迟：200ms - 2000ms
            Random.nextInt(200, 2001)
        } else {
            // 固定延迟：默认 500ms，范围 200-10000ms
            settings.clickDelayFixed.coerceIn(200, 10000)
        }
    }
    
    /**
     * 执行带延迟的点击操作
     */
    private suspend fun clickWithDelay(x: Int, y: Int): Boolean {
        val delayMs = getActualDelayMs()
        Log.d(TAG, "延迟 ${delayMs}ms 后点击坐标 ($x, $y)")
        
        delay(delayMs.toLong())
        
        return gestureController.click(x, y)
    }
    
    /**
     * 处理抢单结果
     */
    private fun handleGrabResult(result: GrabResultType, reason: String) {
        when (result) {
            GrabResultType.SUCCESS -> {
                Log.d(TAG, "抢单成功：$reason")
                updateGrabState(GrabState.SUCCESS)
                
                // 记录成功日志
                logManager.addSystemLog("抢单成功！$reason", OrderLogManager.LogType.SUCCESS)
                
                // 播放成功提示音
                try {
                    appContext?.let { ctx ->
                        com.autoaccessibility.assistant.audio.SoundManager.getInstance(ctx)
                            .playSuccessSound()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "播放成功音效失败", e)
                }
                
                // 停止自动刷新，进入等待模式
                stopAutoRefresh()
                
            }
            GrabResultType.FAILED -> {
                Log.d(TAG, "抢单失败：$reason")
                updateGrabState(GrabState.SCANNING)
                
                // 记录失败日志
                logManager.addSystemLog("抢单失败：$reason", OrderLogManager.LogType.WARNING)
                
                // 继续自动刷新
                resumeAutoRefresh()
                
            }
            GrabResultType.TIMEOUT, GrabResultType.UNKNOWN -> {
                Log.w(TAG, "抢单结果未知：$reason")
                updateGrabState(GrabState.SCANNING)
                
                // 超时或未知时，继续刷新
                resumeAutoRefresh()
            }
        }
    }
    
    /**
     * 更新抢单状态
     */
    private fun updateGrabState(state: GrabState) {
        grabState = state
        onGrabStateChanged?.invoke(state)
        Log.d(TAG, "抢单状态变更：$state")
    }
    
    /**
     * 停止自动刷新（抢单成功后调用）
     */
    private fun stopAutoRefresh() {
        Log.d(TAG, "停止自动刷新（功能已简化）")
    }
    
    /**
     * 恢复自动刷新（抢单失败后调用）
     */
    private fun resumeAutoRefresh() {
        Log.d(TAG, "恢复自动刷新（功能已简化）")
    }
    
    /**
     * 手动重置状态（供悬浮窗"重新开始"按钮调用）
     */
    fun resetToIdle() {
        updateGrabState(GrabState.IDLE)
        resultRecognizer?.reset()
        Log.d(TAG, "状态已重置为 IDLE")
    }

    /**
     * 执行任务脚本（支持高级逻辑）
     */
    fun executeTask(script: TaskScript) {
        if (!isServiceAvailable()) {
            Log.e(TAG, "无障碍服务不可用，无法执行任务")
            onTaskCompleted?.invoke(script, false, "无障碍服务未启用")
            return
        }

        if (isRunning.get()) {
            Log.w(TAG, "已有任务正在执行，请等待完成")
            onTaskCompleted?.invoke(script, false, "已有任务正在执行")
            return
        }

        if (!script.isEnabled) {
            Log.w(TAG, "任务已禁用：${script.name}")
            return
        }

        Log.d(TAG, "开始执行任务：${script.name}")
        isRunning.set(true)
        executionContext.clear()  // 清空上下文
        coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        
        currentJob = coroutineScope?.launch {
            try {
                onTaskStarted?.invoke(script)
                
                var successCount = 0
                var failCount = 0
                var errorMessage: String? = null
                
                // 使用索引遍历以支持循环跳转
                var index = 0
                val steps = script.steps
                val loopStack = mutableListOf<LoopContext>()  // 循环栈
                
                while (index < steps.size) {
                    if (!isRunning.get()) {
                        Log.i(TAG, "任务被用户中断")
                        errorMessage = "用户中断"
                        break
                    }
                    
                    val step = steps[index]
                    
                    // 处理循环结束标记
                    if (step.actionType == ActionType.LOOP_END && loopStack.isNotEmpty()) {
                        val loopContext = loopStack.last()
                        loopContext.iteration++
                        
                        if (loopContext.iteration <= loopContext.maxIterations) {
                            // 继续循环，跳回到 LOOP_START
                            index = loopContext.startIndex
                            continue
                        } else {
                            // 循环结束，弹出栈
                            loopStack.removeAt(loopStack.size - 1)
                            index++
                            continue
                        }
                    }
                    
                    // 处理循环开始标记
                    if (step.actionType == ActionType.LOOP_START) {
                        val maxIterations = step.loopCount ?: 1
                        loopStack.add(LoopContext(index, maxIterations, 0))
                        index++
                        continue
                    }
                    
                    // 处理条件判断
                    if (step.actionType == ActionType.CONDITION) {
                        val conditionMet = evaluateCondition(step)
                        Log.d(TAG, "条件判断：${step.description}, 结果：$conditionMet")
                        
                        if (!conditionMet) {
                            // 条件不满足，跳过此步骤
                            index++
                            continue
                        }
                        // 条件满足，继续执行后续步骤
                    }
                    
                    Log.d(TAG, "执行步骤 ${index + 1}/${steps.size}: ${step.description}")
                    onTaskProgress?.invoke(script, index + 1, steps.size)
                    
                    val success = gestureController.executeStep(step)
                    
                    if (success) {
                        successCount++
                        
                        // 保存 OCR 或 AI 决策结果到上下文
                        if (step.actionType == ActionType.OCR_ANALYZE) {
                            // OCR 分析后，执行完整的智能抢单流程
                            handleOrderAnalysis()
                        }
                        if (step.actionType == ActionType.AI_DECIDE) {
                            // 可以从 AI 服务获取最新决策
                        }
                    } else {
                        failCount++
                        Log.w(TAG, "步骤执行失败：${step.description}")
                        
                        // 关键步骤失败处理已简化
                    }
                    
                    onStepExecuted?.invoke(script, step, success)
                    onContextUpdated?.invoke(executionContext.toMap())
                    
                    index++
                }
                
                val allSuccess = failCount == 0
                val resultMessage = if (allSuccess) {
                    "任务完成，共 ${steps.size} 步，全部成功"
                } else {
                    "任务完成，成功 $successCount/${steps.size} 步，失败 $failCount 步"
                }
                
                Log.d(TAG, resultMessage)
                onTaskCompleted?.invoke(script, allSuccess, if (allSuccess) null else errorMessage)
                
            } catch (e: Exception) {
                Log.e(TAG, "任务执行异常", e)
                onTaskCompleted?.invoke(script, false, e.message ?: "未知错误")
            } finally {
                isRunning.set(false)
                currentJob = null
                executionContext.clear()
            }
        }
    }
    
    /**
     * 评估条件表达式
     */
    private fun evaluateCondition(step: TaskStep): Boolean {
        // 简化实现：条件判断恒为真
        return true
    }

    /**
     * 停止当前任务
     */
    fun stopTask() {
        Log.d(TAG, "请求停止任务")
        isRunning.set(false)
        currentJob?.cancel()
        gestureController.stop()
    }

    /**
     * 是否正在执行任务
     */
    fun isExecuting(): Boolean {
        return isRunning.get() && currentJob?.isActive == true
    }

    /**
     * 立即执行单个操作
     */
    fun executeImmediateAction(step: TaskStep, callback: (Boolean) -> Unit) {
        if (!isServiceAvailable()) {
            callback(false)
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = gestureController.executeStep(step)
                withContext(Dispatchers.Main) {
                    callback(result)
                }
            } catch (e: Exception) {
                Log.e(TAG, "执行操作异常", e)
                withContext(Dispatchers.Main) {
                    callback(false)
                }
            }
        }
    }

    /**
     * 测试连接
     */
    fun testConnection(): Boolean {
        return isServiceAvailable()
    }

    /**
     * 获取当前屏幕元素列表（用于调试）
     */
    fun getCurrentElements(): List<String> {
        val service = com.autoaccessibility.assistant.service.AutoAccessibilityService.getInstance()
            ?: return emptyList()
        
        service.refreshScreenElements()
        // currentElements 是私有的，需要通过公开方法获取
        return service.getClickableElements().map { "${it.text} (${it.className})" }
    }

    /**
     * 处理订单分析（智能抢单核心流程）
     */
    private suspend fun handleOrderAnalysis() {
        try {
            val orderInfo = parseOrderFromContext()
            if (orderInfo == null) {
                logManager.addSystemLog("未识别到订单信息", OrderLogManager.LogType.WARNING)
                return
            }
            
            Log.d(TAG, "开始处理订单：${orderInfo.toDescription()}")
            
            // 1. 识别订单类型
            val detectedOrderType = filterEngine?.detectOrderType(orderInfo.rawText) ?: ""
            orderInfo.copy(orderType = detectedOrderType)
            Log.d(TAG, "识别订单类型：$detectedOrderType")
            
            // 2. 检查订单类型是否在选中列表中
            val settings = settingsManager?.getCurrentSettings()
            if (settings != null && settings.selectedOrderTypes.isNotEmpty()) {
                if (detectedOrderType.isNotEmpty() && !settings.selectedOrderTypes.contains(detectedOrderType)) {
                    Log.d(TAG, "订单类型不符合：$detectedOrderType 不在选中列表中")
                    logManager.addLog(
                        orderType = detectedOrderType,
                        price = orderInfo.price,
                        pickupDistance = orderInfo.pickupDistance,
                        tripDistance = orderInfo.tripDistance,
                        filterPassed = false,
                        filterReason = "类型不匹配：$detectedOrderType",
                        grabResult = GrabResult.SKIPPED,
                        grabReason = "订单类型未勾选"
                    )
                    return
                }
            }
            
            // 3. 执行过滤引擎检查
            if (filterEngine != null) {
                val filterResult = filterEngine!!.checkOrder(orderInfo)
                
                if (!filterResult) {
                    val reason = filterEngine?.getLastFilterReason() ?: "过滤未通过"
                    Log.d(TAG, "订单过滤未通过：$reason")
                    logManager.addLog(
                        orderType = detectedOrderType,
                        price = orderInfo.price,
                        pickupDistance = orderInfo.pickupDistance,
                        tripDistance = orderInfo.tripDistance,
                        filterPassed = false,
                        filterReason = reason,
                        grabResult = GrabResult.SKIPPED,
                        grabReason = reason
                    )
                    return
                }
            }
            
            // 4. 过滤通过，识别抢单按钮位置
            if (buttonRecognizer != null) {
                val buttonInfo = buttonRecognizer!!.recognizeGrabButton()
                
                if (buttonInfo == null) {
                    Log.w(TAG, "未识别到抢单按钮")
                    logManager.addLog(
                        orderType = detectedOrderType,
                        price = orderInfo.price,
                        pickupDistance = orderInfo.pickupDistance,
                        tripDistance = orderInfo.tripDistance,
                        filterPassed = true,
                        filterReason = null,
                        grabResult = GrabResult.FAILED,
                        grabReason = "未识别到抢单按钮"
                    )
                    return
                }
                
                Log.d(TAG, "识别到抢单按钮：${buttonInfo.type}")
                
                // 5. 更新状态为点击中
                updateGrabState(GrabState.CLICKING)
                
                // 5. 执行带延迟的点击操作
                val clickSuccess = clickWithDelay(
                    buttonInfo.centerX.toInt(),
                    buttonInfo.centerY.toInt()
                )
                
                if (clickSuccess) {
                    Log.d(TAG, "抢单点击成功，开始识别结果...")
                    
                    // 6. 触发结果识别（延迟由 ResultRecognizer 内部处理）
                    updateGrabState(GrabState.VERIFYING)
                    resultRecognizer?.startRecognition(delayMs = 500L)
                    
                    // 先记录点击成功，最终结果由识别回调更新
                    logManager.addLog(
                        orderType = detectedOrderType,
                        price = orderInfo.price,
                        pickupDistance = orderInfo.pickupDistance,
                        tripDistance = orderInfo.tripDistance,
                        filterPassed = true,
                        filterReason = null,
                        grabResult = GrabResult.SUCCESS,
                        grabReason = "点击坐标：(${buttonInfo.centerX.toInt()}, ${buttonInfo.centerY.toInt()}), 等待结果识别"
                    )
                } else {
                    Log.w(TAG, "抢单失败：点击操作未成功")
                    updateGrabState(GrabState.SCANNING)
                    logManager.addLog(
                        orderType = detectedOrderType,
                        price = orderInfo.price,
                        pickupDistance = orderInfo.pickupDistance,
                        tripDistance = orderInfo.tripDistance,
                        filterPassed = true,
                        filterReason = null,
                        grabResult = GrabResult.FAILED,
                        grabReason = "点击操作失败"
                    )
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "处理订单异常", e)
            logManager.addSystemLog("订单处理异常：${e.message}", OrderLogManager.LogType.ERROR)
        }
    }

    /**
     * 从上下文解析订单信息
     */
    private fun parseOrderFromContext(): OrderInfo? {
        return try {
            val ocrResult = executionContext["ocr_result"] as? String ?: return null
            
            // 简单解析 OCR 结果中的价格、距离等信息
            val price = extractNumber(ocrResult, "￥|元|价格") ?: 0.0
            val pickupDistance = extractNumber(ocrResult, "接驾 | 距离乘客 | 公里") ?: 0.0
            val tripDistance = extractNumber(ocrResult, "行程 | 公里数 | 路程") ?: 0.0
            
            // 解析订单类型
            val orderType = extractOrderType(ocrResult)
            
            OrderInfo(
                price = price,
                pickupDistance = pickupDistance,
                tripDistance = tripDistance,
                orderType = orderType,
                rawText = ocrResult
            )
        } catch (e: Exception) {
            Log.e(TAG, "解析订单信息失败", e)
            null
        }
    }

    /**
     * 从文本中提取订单类型
     */
    private fun extractOrderType(text: String): String {
        return OrderType.entries.firstOrNull { type ->
            text.contains(type.displayName, ignoreCase = true) ||
            type.keywords.any { keyword -> text.contains(keyword, ignoreCase = true) }
        }?.displayName ?: ""
    }
    
    /**
     * 从文本中提取数字（简化实现）
     */
    private fun extractNumber(text: String, keywordPattern: String): Double? {
        val regex = Regex("($keywordPattern)[^0-9]*([0-9]+\\.?[0-9]*)")
        val match = regex.find(text)
        return match?.groupValues?.getOrNull(2)?.toDoubleOrNull()
    }

    /**
     * 清理资源
     */
    fun destroy() {
        stopTask()
        coroutineScope?.cancel()
        coroutineScope = null
        instance = null
        settingsRepository = null
        filterEngine = null
    }
}

/**
 * 循环上下文
 */
private data class LoopContext(
    val startIndex: Int,         // LOOP_START 的索引
    val maxIterations: Int,      // 最大循环次数
    var iteration: Int           // 当前迭代次数
)

/**
 * 任务执行历史记录
 */
data class ExecutionRecord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val taskId: String,
    val taskName: String,
    val executedAt: Long = System.currentTimeMillis(),
    val duration: Long,              // 执行耗时（毫秒）
    val totalSteps: Int,
    val successSteps: Int,
    val isSuccess: Boolean,
    val errorMessage: String? = null
) {
    fun getSuccessRate(): Float {
        return if (totalSteps > 0) successSteps.toFloat() / totalSteps else 0f
    }
    
    fun getFormattedDuration(): String {
        val seconds = duration / 1000
        val minutes = seconds / 60
        return if (minutes > 0) {
            "${minutes}分${seconds % 60}秒"
        } else {
            "${seconds}秒"
        }
    }
}