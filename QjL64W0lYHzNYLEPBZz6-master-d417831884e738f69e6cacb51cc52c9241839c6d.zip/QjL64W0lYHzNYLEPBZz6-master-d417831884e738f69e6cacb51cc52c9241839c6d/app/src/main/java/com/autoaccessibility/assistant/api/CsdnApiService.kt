package com.autoaccessibility.assistant.api

import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

/**
 * CSDN AI API 服务接口
 * 提供 OCR 文字识别和 AI 智能对话能力
 */
interface CsdnApiService {

    /**
     * OCR 文字识别
     * POST https://models.csdn.net/v1/images/ocr
     */
    @Multipart
    @POST("v1/images/ocr")
    suspend fun recognizeText(
        @Header("Authorization") authorization: String,
        @Part image: MultipartBody.Part? = null,
        @Part("url") url: RequestBody? = null,
        @Part("model") model: RequestBody
    ): Response<OcrResponse>

    /**
     * AI 智能对话（图文混合输入）
     * POST https://models.csdn.net/v1/chat/completions
     */
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") authorization: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>
}

/**
 * OCR 响应数据
 */
data class OcrResponse(
    val request_id: String,
    val created: Long,
    val data: String,
    val usage: OcrUsage
)

data class OcrUsage(
    val ocr_count: Int
)

/**
 * AI 对话请求数据
 */
data class ChatCompletionRequest(
    val model: String,
    val messages: List<Message>,
    val stream: Boolean = false,
    val max_tokens: Int? = null,
    val temperature: Float? = null,
    val top_p: Float? = null,
    val top_k: Int? = null
)

/**
 * 对话消息
 */
data class Message(
    val role: String,
    val content: Any // 可以是 String 或 List<ContentPart>
)

/**
 * 消息内容部分（支持图文混合）
 */
data class ContentPart(
    val type: String,
    val text: String? = null,
    val image_url: ImageUrl? = null
)

data class ImageUrl(
    val url: String // Base64 或 HTTP URL
)

/**
 * AI 对话响应数据
 */
data class ChatCompletionResponse(
    val id: String,
    val object_type: String,
    val created: Long,
    val model: String,
    val choices: List<Choice>,
    val usage: Usage
)

data class Choice(
    val index: Int,
    val message: ResponseMessage,
    val finish_reason: String
)

data class ResponseMessage(
    val role: String,
    val content: String,
    val reasoning_content: String? = null
)

data class Usage(
    val prompt_tokens: Int,
    val completion_tokens: Int,
    val total_tokens: Int
)