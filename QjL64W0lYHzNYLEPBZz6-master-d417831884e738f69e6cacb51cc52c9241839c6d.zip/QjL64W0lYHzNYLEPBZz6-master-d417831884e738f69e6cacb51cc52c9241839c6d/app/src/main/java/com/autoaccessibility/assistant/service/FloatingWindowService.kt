package com.autoaccessibility.assistant.service

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.ui.MainActivity
import java.text.SimpleDateFormat
import java.util.*

/**
 * 悬浮窗服务
 * 提供系统级悬浮窗显示，实时监控软件状态和订单处理日志
 */
class FloatingWindowService : Service() {

    companion object {
        private const val TAG = "FloatingWindowService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "floating_window_channel"
        
        // 单例引用
        @Volatile
        private var instance: FloatingWindowService? = null
        
        fun getInstance(): FloatingWindowService? {
            return instance
        }
        
        // 操作类型常量
        const val ACTION_TOGGLE_PAUSE = "com.autoaccessibility.assistant.TOGGLE_PAUSE"
        const val ACTION_OPEN_SETTINGS = "com.autoaccessibility.assistant.OPEN_SETTINGS"
        const val ACTION_MINIMIZE = "com.autoaccessibility.assistant.MINIMIZE"
    }

    private lateinit var windowManager: WindowManager
    private lateinit var layoutParams: WindowManager.LayoutParams
    private var floatingView: View? = null
    
    // 状态标识
    private var isMinimized = false
    private var isPaused = false
    private var isRunning = false
    private var currentGrabState: GrabState = GrabState.IDLE
    
    // UI 组件引用
    private var tvSoftwareStatus: TextView? = null
    private var statusIndicator: View? = null
    private var tvBattery: TextView? = null
    private var tvNetwork: TextView? = null
    private var tvTime: TextView? = null
    private var tvStats: TextView? = null
    private var tvGrabResult: TextView? = null  // 抢单结果显示
    private var btnRestart: Button? = null      // 重新开始按钮
    private var logContainer: LinearLayout? = null
    private var logScrollView: ScrollView? = null
    private var btnPause: Button? = null
    private var btnSettings: Button? = null
    private var btnExpand: Button? = null
    private var btnMinimize: ImageButton? = null
    private var btnClearLog: TextView? = null
    
    // 抢单状态枚举
    enum class GrabState {
        IDLE,           // 空闲/等待手动启动
        SCANNING,       // 扫描订单中
        CLICKING,       // 点击抢单中
        VERIFYING,      // 识别结果中
        SUCCESS,        // 抢单成功
        FAILED          // 抢单失败
    }
    
    // 日志管理
    private val logEntries = mutableListOf<String>()
    private val maxLogEntries = 100
    
    // 时间格式化
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val logTimeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    
    // 电池状态接收器
    private var batteryReceiver: BroadcastReceiver? = null
    
    // 网络状态接收器
    private var networkReceiver: BroadcastReceiver? = null
    
    // 时间更新定时器
    private var timeUpdateRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "悬浮窗服务创建")
        instance = this
        
        initWindowManager()
        createNotificationChannel()
        startForegroundService()
        registerReceivers()
        startTimeUpdate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "悬浮窗服务启动")
        showFloatingWindow()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        Log.d(TAG, "悬浮窗服务销毁")
        stopTimeUpdate()
        unregisterReceivers()
        removeFloatingWindow()
        instance = null
        super.onDestroy()
    }

    /**
     * 初始化 WindowManager
     */
    private fun initWindowManager() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        
        // 设置初始位置（右上角）
        layoutParams.gravity = Gravity.TOP or Gravity.END
        layoutParams.x = 50
        layoutParams.y = 200
    }

    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "悬浮窗服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "显示抢单助手悬浮窗控制"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * 启动前台服务
     */
    private fun startForegroundService() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("抢单助手")
            .setContentText("悬浮窗监控服务运行中")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
        
        startForeground(NOTIFICATION_ID, notification)
    }

    /**
     * 显示悬浮窗
     */
    private fun showFloatingWindow() {
        if (floatingView != null) return
        
        try {
            val inflater = LayoutInflater.from(this)
            floatingView = inflater.inflate(R.layout.floating_window_layout, null)
            
            // 绑定 UI 组件
            bindViews(floatingView!!)
            
            // 设置事件监听
            setupListeners()
            
            // 更新初始状态
            updateSoftwareStatus(isRunning = true, isPaused = false)
            updatePhoneStatus()
            
            // 添加到窗口
            windowManager.addView(floatingView, layoutParams)
            
            addLogEntry("悬浮窗已启动", LogType.INFO)
            
            Log.d(TAG, "悬浮窗已显示")
            
        } catch (e: Exception) {
            Log.e(TAG, "显示悬浮窗失败", e)
        }
    }

    /**
     * 移除悬浮窗
     */
    private fun removeFloatingWindow() {
        try {
            if (floatingView != null) {
                windowManager.removeView(floatingView)
                floatingView = null
                Log.d(TAG, "悬浮窗已移除")
            }
        } catch (e: Exception) {
            Log.e(TAG, "移除悬浮窗失败", e)
        }
    }

    /**
     * 绑定视图组件
     */
    private fun bindViews(view: View) {
        tvSoftwareStatus = view.findViewById(R.id.tvSoftwareStatus)
        statusIndicator = view.findViewById(R.id.statusIndicator)
        tvBattery = view.findViewById(R.id.tvBattery)
        tvNetwork = view.findViewById(R.id.tvNetwork)
        tvTime = view.findViewById(R.id.tvTime)
        tvStats = view.findViewById(R.id.tvStats)
        tvGrabResult = view.findViewById(R.id.tvGrabResult)
        btnRestart = view.findViewById(R.id.btnRestart)
        logContainer = view.findViewById(R.id.logContainer)
        logScrollView = view.findViewById(R.id.logScrollView)
        btnPause = view.findViewById(R.id.btnPause)
        btnSettings = view.findViewById(R.id.btnSettings)
        btnExpand = view.findViewById(R.id.btnExpand)
        btnMinimize = view.findViewById(R.id.btnMinimize)
        btnClearLog = view.findViewById(R.id.btnClearLog)
        
        // 初始化抢单结果显示
        tvGrabResult?.visibility = View.GONE
        btnRestart?.visibility = View.GONE
    }

    /**
     * 设置事件监听
     */
    private fun setupListeners() {
        // 暂停/继续按钮
        btnPause?.setOnClickListener {
            togglePause()
        }
        
        // 设置按钮
        btnSettings?.setOnClickListener {
            openSettings()
        }
        
        // 展开/收起按钮
        btnExpand?.setOnClickListener {
            toggleExpand()
        }
        
        // 最小化按钮
        btnMinimize?.setOnClickListener {
            minimize()
        }
        
        // 清空日志
        btnClearLog?.setOnClickListener {
            clearLogs()
        }
        
        // 重新开始按钮（抢单成功后显示）
        btnRestart?.setOnClickListener {
            restartGrabbing()
        }
        
        // 拖动功能
        setupDragListener()
    }

    /**
     * 设置拖动监听
     */
    private fun setupDragListener() {
        val statusBarLayout = floatingView?.findViewById<View>(R.id.statusBarLayout)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        
        statusBarLayout?.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, layoutParams)
                    true
                }
                else -> false
            }
        }
    }

    /**
     * 切换暂停状态
     */
    private fun togglePause() {
        isPaused = !isPaused
        updatePauseButton()
        
        // 广播暂停状态变化
        val intent = Intent(ACTION_TOGGLE_PAUSE).apply {
            setPackage(packageName)
            putExtra("isPaused", isPaused)
        }
        sendBroadcast(intent)
        
        val status = if (isPaused) "已暂停" else "运行中"
        addLogEntry("用户$status", LogType.INFO)
    }

    /**
     * 打开设置页面
     */
    private fun openSettings() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_settings", true)
        }
        startActivity(intent)
        
        addLogEntry("打开设置页面", LogType.INFO)
    }

    /**
     * 切换展开/收起状态
     */
    private fun toggleExpand() {
        val logSection = floatingView?.findViewById<ScrollView>(R.id.logScrollView)
        val bottomBar = floatingView?.findViewById<View>(R.id.bottomBar)
        
        if (logSection?.visibility == View.VISIBLE) {
            // 收起
            logSection.visibility = View.GONE
            bottomBar?.visibility = View.GONE
            btnExpand?.text = "展开"
            isMinimized = true
        } else {
            // 展开
            logSection?.visibility = View.VISIBLE
            bottomBar?.visibility = View.VISIBLE
            btnExpand?.text = "收起"
            isMinimized = false
        }
    }

    /**
     * 最小化悬浮窗
     */
    private fun minimize() {
        // 简化实现：暂时隐藏悬浮窗
        floatingView?.visibility = View.GONE
        
        val intent = Intent(ACTION_MINIMIZE).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
        
        addLogEntry("悬浮窗已最小化", LogType.INFO)
    }

    /**
     * 更新暂停按钮状态
     */
    private fun updatePauseButton() {
        btnPause?.text = if (isPaused) "继续" else "暂停"
        btnPause?.setBackgroundResource(
            if (isPaused) R.drawable.bg_continue_button else R.drawable.bg_pause_button
        )
    }

    /**
     * 更新软件状态显示
     */
    fun updateSoftwareStatus(isRunning: Boolean, isPaused: Boolean = false) {
        this.isRunning = isRunning
        this.isPaused = isPaused
        
        tvSoftwareStatus?.post {
            when {
                !isRunning -> {
                    tvSoftwareStatus?.text = "已停止"
                    tvSoftwareStatus?.setTextColor(android.graphics.Color.GRAY)
                    statusIndicator?.setBackgroundColor(android.graphics.Color.GRAY)
                }
                isPaused -> {
                    tvSoftwareStatus?.text = "已暂停"
                    tvSoftwareStatus?.setTextColor(android.graphics.Color.parseColor("#FFA726"))
                    statusIndicator?.setBackgroundColor(android.graphics.Color.parseColor("#FFA726"))
                }
                else -> {
                    tvSoftwareStatus?.text = "运行中"
                    tvSoftwareStatus?.setTextColor(android.graphics.Color.parseColor("#4CAF50"))
                    statusIndicator?.setBackgroundColor(android.graphics.Color.parseColor("#4CAF50"))
                }
            }
            updatePauseButton()
        }
    }
    
    /**
     * 更新抢单状态
     */
    fun updateGrabState(state: GrabState, resultText: String = "") {
        currentGrabState = state
        
        tvGrabResult?.post {
            when (state) {
                GrabState.IDLE -> {
                    tvGrabResult?.visibility = View.GONE
                    btnRestart?.visibility = View.GONE
                    tvSoftwareStatus?.text = "等待启动"
                    tvSoftwareStatus?.setTextColor(android.graphics.Color.GRAY)
                    statusIndicator?.setBackgroundColor(android.graphics.Color.GRAY)
                }
                GrabState.SCANNING -> {
                    tvGrabResult?.visibility = View.VISIBLE
                    tvGrabResult?.text = "🔍 扫描订单中..."
                    tvGrabResult?.setTextColor(android.graphics.Color.parseColor("#2196F3"))
                    btnRestart?.visibility = View.GONE
                }
                GrabState.CLICKING -> {
                    tvGrabResult?.visibility = View.VISIBLE
                    tvGrabResult?.text = "⚡ 抢单中..."
                    tvGrabResult?.setTextColor(android.graphics.Color.parseColor("#FF9800"))
                    btnRestart?.visibility = View.GONE
                }
                GrabState.VERIFYING -> {
                    tvGrabResult?.visibility = View.VISIBLE
                    tvGrabResult?.text = "👀 识别结果中..."
                    tvGrabResult?.setTextColor(android.graphics.Color.parseColor("#9C27B0"))
                    btnRestart?.visibility = View.GONE
                }
                GrabState.SUCCESS -> {
                    tvGrabResult?.visibility = View.VISIBLE
                    tvGrabResult?.text = "✅ $resultText"
                    tvGrabResult?.setTextColor(android.graphics.Color.parseColor("#4CAF50"))
                    btnRestart?.visibility = View.VISIBLE
                    tvSoftwareStatus?.text = "抢单成功"
                    tvSoftwareStatus?.setTextColor(android.graphics.Color.parseColor("#4CAF50"))
                    statusIndicator?.setBackgroundColor(android.graphics.Color.parseColor("#4CAF50"))
                    
                    // 播放成功提示音
                    try {
                        val soundManager = com.autoaccessibility.assistant.audio.SoundManager.getInstance(applicationContext)
                        soundManager.playSuccessSound()
                    } catch (e: Exception) {
                        Log.w(TAG, "播放成功音效失败", e)
                    }
                    
                    addLogEntry("🎉 抢单成功！等待下次手动启动", LogType.SUCCESS)
                }
                GrabState.FAILED -> {
                    tvGrabResult?.visibility = View.VISIBLE
                    tvGrabResult?.text = "❌ $resultText"
                    tvGrabResult?.setTextColor(android.graphics.Color.parseColor("#F44336"))
                    btnRestart?.visibility = View.GONE
                    addLogEntry("抢单失败：$resultText", LogType.ERROR)
                }
            }
        }
    }
    
    /**
     * 重新开始抢单（成功后手动重启）
     */
    private fun restartGrabbing() {
        addLogEntry("用户点击重新开始", LogType.INFO)
        
        // 广播重启请求
        val intent = Intent(ACTION_TOGGLE_PAUSE).apply {
            setPackage(packageName)
            putExtra("restartGrabbing", true)
        }
        sendBroadcast(intent)
        
        // 重置状态
        updateGrabState(GrabState.SCANNING)
    }

    /**
     * 更新手机状态
     */
    private fun updatePhoneStatus() {
        updateBatteryStatus()
        updateNetworkStatus()
        updateTime()
    }

    /**
     * 更新电量状态
     */
    private fun updateBatteryStatus() {
        try {
            val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            batteryIntent?.let {
                val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) {
                    val batteryPercent = (level * 100) / scale
                    tvBattery?.text = "$batteryPercent%"
                    
                    // 低电量预警
                    if (batteryPercent < 20) {
                        tvBattery?.setTextColor(android.graphics.Color.RED)
                    } else {
                        tvBattery?.setTextColor(android.graphics.Color.parseColor("#666666"))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "获取电量失败", e)
        }
    }

    /**
     * 更新网络状态
     */
    private fun updateNetworkStatus() {
        // 简化实现，实际项目中需要检测 WiFi/移动数据状态
        tvNetwork?.text = "WiFi"
        tvNetwork?.setTextColor(android.graphics.Color.parseColor("#666666"))
    }

    /**
     * 更新时间
     */
    private fun updateTime() {
        tvTime?.text = timeFormat.format(Date())
    }

    /**
     * 更新统计信息
     */
    fun updateStats(refreshCount: Int, orderCount: Int, successCount: Int) {
        tvStats?.post {
            tvStats?.text = "刷新：$refreshCount | 订单：$orderCount | 成功：$successCount"
        }
    }

    /**
     * 添加日志条目
     */
    fun addLogEntry(message: String, type: LogType = LogType.INFO) {
        val timestamp = logTimeFormat.format(Date())
        val logText = "[$timestamp] $message"
        
        logEntries.add(logText)
        
        // 限制日志数量
        if (logEntries.size > maxLogEntries) {
            logEntries.removeAt(0)
        }
        
        logContainer?.post {
            // 创建日志条目视图
            val logItemView = createLogItemView(timestamp, message, type)
            logContainer?.addView(logItemView)
            
            // 限制显示的视图数量
            if (logContainer?.childCount ?: 0 > maxLogEntries) {
                logContainer?.removeViewAt(0)
            }
            
            // 滚动到底部
            logScrollView?.fullScroll(View.FOCUS_DOWN)
        }
    }

    /**
     * 创建日志条目视图
     */
    private fun createLogItemView(timestamp: String, message: String, type: LogType): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 6, 8, 6)
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
        }
        
        // 类型标识
        val indicator = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(8, 8).apply {
                marginEnd = 8
            }
            setBackgroundColor(when (type) {
                LogType.SUCCESS -> android.graphics.Color.parseColor("#4CAF50")
                LogType.ERROR -> android.graphics.Color.parseColor("#F44336")
                LogType.WARNING -> android.graphics.Color.parseColor("#FF9800")
                else -> android.graphics.Color.parseColor("#2196F3")
            })
        }
        
        // 消息文本
        val textView = TextView(this).apply {
            text = message
            textSize = 11f
            setTextColor(android.graphics.Color.parseColor("#333333"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        
        layout.addView(indicator)
        layout.addView(textView)
        
        return layout
    }

    /**
     * 清空日志
     */
    private fun clearLogs() {
        logEntries.clear()
        logContainer?.removeAllViews()
        addLogEntry("日志已清空", LogType.INFO)
    }

    /**
     * 注册广播接收器
     */
    private fun registerReceivers() {
        // 电池状态
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                updateBatteryStatus()
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        
        // 网络状态
        networkReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                updateNetworkStatus()
            }
        }
        registerReceiver(networkReceiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
    }

    /**
     * 注销广播接收器
     */
    private fun unregisterReceivers() {
        try {
            batteryReceiver?.let { unregisterReceiver(it) }
            networkReceiver?.let { unregisterReceiver(it) }
        } catch (e: Exception) {
            Log.e(TAG, "注销接收器失败", e)
        }
    }

    /**
     * 启动时间更新
     */
    private fun startTimeUpdate() {
        timeUpdateRunnable = Runnable {
            updateTime()
            tvTime?.postDelayed(timeUpdateRunnable, 1000)
        }
        tvTime?.post(timeUpdateRunnable)
    }

    /**
     * 停止时间更新
     */
    private fun stopTimeUpdate() {
        timeUpdateRunnable?.let {
            tvTime?.removeCallbacks(it)
        }
    }

    /**
     * 日志类型枚举
     */
    enum class LogType {
        INFO,       // 普通信息
        SUCCESS,    // 成功
        WARNING,    // 警告
        ERROR       // 错误
    }
}

/**
 * 抢单状态枚举（与 TaskEngine 共享）
 */
enum class GlobalGrabState {
    IDLE,           // 空闲/等待手动启动
    SCANNING,       // 扫描订单中
    CLICKING,       // 点击抢单中
    VERIFYING,      // 识别结果中
    SUCCESS,        // 抢单成功
    FAILED          // 抢单失败
}