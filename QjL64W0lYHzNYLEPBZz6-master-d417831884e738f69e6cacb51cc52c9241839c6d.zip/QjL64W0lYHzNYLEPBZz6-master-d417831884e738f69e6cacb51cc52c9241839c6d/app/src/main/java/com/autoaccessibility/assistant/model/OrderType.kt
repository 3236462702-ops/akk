package com.autoaccessibility.assistant.model

/**
 * 订单类型枚举
 * 定义所有支持的订单类型及其特征
 */
enum class OrderType(
    val displayName: String,      // 显示名称
    val keywords: List<String>,   // OCR 识别关键词
    val colorCode: Int            // 颜色代码（ARGB）
) {
    // 拼车订单
    CARPOOL(
        displayName = "拼车",
        keywords = listOf("拼车", "合乘", "共享"),
        colorCode = 0xFF4CAF50.toInt()  // 绿色
    ),
    
    // 快车订单
    EXPRESS(
        displayName = "快车",
        keywords = listOf("快车", "经济", "普通"),
        colorCode = 0xFF2196F3.toInt()  // 蓝色
    ),
    
    // 特快订单
    PREMIUM(
        displayName = "特快",
        keywords = listOf("特快", "优先", "急速"),
        colorCode = 0xFFFF9800.toInt()  // 橙色
    ),
    
    // 四轮小件
    SMALL_CARGO(
        displayName = "四轮小件",
        keywords = listOf("四轮小件", "小件", "货物", "物品"),
        colorCode = 0xFF795548.toInt()  // 棕色
    ),
    
    // 网约车（通用）
    RIDE_HAILING(
        displayName = "网约车",
        keywords = listOf("网约车", "专车", "轿车"),
        colorCode = 0xFF607D8B.toInt()  // 蓝灰色
    ),
    
    // 用户出价
    USER_BID(
        displayName = "用户出价",
        keywords = listOf("用户出价", "议价", "报价", "自定义"),
        colorCode = 0xFFE91E63.toInt()  // 粉红色
    ),
    
    // 特惠订单
    DISCOUNT(
        displayName = "特惠",
        keywords = listOf("特惠", "优惠", "折扣", "特价"),
        colorCode = 0xFFFFC107.toInt()  // 黄色
    ),
    
    // 长途特惠
    LONG_DISTANCE(
        displayName = "长途特惠",
        keywords = listOf("长途特惠", "长途", "远途", "跨城"),
        colorCode = 0xFF9C27B0.toInt()  // 紫色
    );
    
    companion object {
        /**
         * 根据 OCR 文本识别订单类型
         * @param ocrText OCR 识别结果
         * @return 识别到的订单类型，未识别返回 null
         */
        fun recognizeFromText(ocrText: String): OrderType? {
            val text = ocrText.lowercase()
            
            // 按优先级排序检查（更具体的类型优先）
            val priorityOrder = listOf(
                LONG_DISTANCE,  // 长途特惠优先
                SMALL_CARGO,    // 四轮小件
                USER_BID,       // 用户出价
                CARPOOL,        // 拼车
                PREMIUM,        // 特快
                DISCOUNT,       // 特惠
                EXPRESS,        // 快车
                RIDE_HAILING    // 网约车（最通用）
            )
            
            for (type in priorityOrder) {
                for (keyword in type.keywords) {
                    if (text.contains(keyword.lowercase())) {
                        return type
                    }
                }
            }
            
            return null
        }
        
        /**
         * 获取所有订单类型的列表
         */
        fun getAllTypes(): List<OrderType> {
            return values().toList()
        }
        
        /**
         * 根据显示名称查找订单类型
         */
        fun fromDisplayName(name: String): OrderType? {
            return values().find { it.displayName == name }
        }
    }
}

/**
 * 按钮信息数据类
 * 用于存储识别到的抢单按钮信息
 */
data class ButtonInfo(
    val type: ButtonType,           // 按钮类型
    val centerX: Float,             // 按钮中心 X 坐标
    val centerY: Float,             // 按钮中心 Y 坐标
    val width: Float,               // 按钮宽度
    val height: Float,              // 按钮高度
    val confidence: Float,          // 置信度 (0-1)
    val recognizedAt: Long          // 识别时间戳
) {
    /**
     * 获取按钮点击坐标
     */
    fun getClickPoint(): Pair<Float, Float> {
        return Pair(centerX, centerY)
    }
    
    /**
     * 获取按钮区域（用于调试显示）
     */
    fun getBounds(): RectF {
        return RectF(
            centerX - width / 2,
            centerY - height / 2,
            centerX + width / 2,
            centerY + height / 2
        )
    }
}

/**
 * 按钮类型枚举
 */
enum class ButtonType(val displayName: String) {
    GRAB_ORDER("抢单"),
    ACCEPT("接受"),
    CONFIRM("确认"),
    UNKNOWN("未知")
}

/**
 * 简易矩形类（避免依赖 Android Graphics）
 */
data class RectF(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    fun contains(x: Float, y: Float): Boolean {
        return x >= left && x <= right && y >= top && y <= bottom
    }
    
    fun width(): Float = right - left
    fun height(): Float = bottom - top
}