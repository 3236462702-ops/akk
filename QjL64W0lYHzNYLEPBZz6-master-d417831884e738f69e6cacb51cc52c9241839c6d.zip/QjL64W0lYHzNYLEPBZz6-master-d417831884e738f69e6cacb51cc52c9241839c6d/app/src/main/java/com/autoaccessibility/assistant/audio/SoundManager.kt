package com.autoaccessibility.assistant.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.util.Log
import com.autoaccessibility.assistant.R
import java.util.concurrent.ConcurrentHashMap

/**
 * 音效管理器 - 统一管理应用内所有音效播放
 * 
 * 功能：
 * - 预加载音效资源，避免播放延迟
 * - 支持音量控制
 * - 支持音效开关
 * - 自动管理音频焦点
 * - 防止内存泄漏
 */
class SoundManager private constructor(private val context: Context) {
    
    companion object {
        private const val TAG = "SoundManager"
        
        @Volatile
        private var instance: SoundManager? = null
        
        /**
         * 获取单例实例
         */
        fun getInstance(context: Context): SoundManager {
            return instance ?: synchronized(this) {
                instance ?: SoundManager(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
    
    private val audioManager: AudioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    
    private val soundPool: SoundPool by lazy {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        
        SoundPool.Builder()
            .setMaxStreams(AudioConfig.MAX_SIMULTANEOUS_SOUNDS)
            .setAudioAttributes(attributes)
            .build()
    }
    
    // 音效 ID 映射表
    private val soundIdMap = ConcurrentHashMap<AudioConfig.SoundType, Int>()
    
    // 音效加载状态
    private val loadedSounds = ConcurrentHashMap<Int, Boolean>()
    
    // 用户设置
    private var soundEnabled = true
    private var clickSoundEnabled = true
    private var successSoundEnabled = true
    private var volume = AudioConfig.DEFAULT_VOLUME
    
    // 防抖时间戳
    private var lastClickTime = 0L
    
    init {
        loadAllSounds()
    }
    
    /**
     * 预加载所有音效
     */
    private fun loadAllSounds() {
        try {
            // 加载短点击音
            val clickId = soundPool.load(context, R.raw.click_sound, 1)
            soundIdMap[AudioConfig.SoundType.CLICK_SHORT] = clickId
            
            // 加载成功 DJ 音效
            val successId = soundPool.load(context, R.raw.success_dj, 1)
            soundIdMap[AudioConfig.SoundType.SUCCESS_DJ] = successId
            
            // 加载错误提示音（可选）- 暂时禁用
            // val errorId = soundPool.load(context, R.raw.error_sound, 1)
            // soundIdMap[AudioConfig.SoundType.ERROR] = errorId
            
            Log.d(TAG, "所有音效加载完成")
        } catch (e: Exception) {
            Log.e(TAG, "音效加载失败", e)
        }
    }
    
    /**
     * 播放短点击音
     */
    fun playClickSound() {
        if (!soundEnabled || !clickSoundEnabled) return
        
        // 防抖处理
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime < AudioConfig.DEBOUNCE_TIME_MS) {
            return
        }
        lastClickTime = currentTime
        
        playSound(AudioConfig.SoundType.CLICK_SHORT)
    }
    
    /**
     * 播放抢单成功音效
     */
    fun playSuccessSound() {
        if (!soundEnabled || !successSoundEnabled) return
        
        playSound(AudioConfig.SoundType.SUCCESS_DJ, priority = 1.0f)
    }
    
    /**
     * 播放错误提示音
     */
    fun playErrorSound() {
        if (!soundEnabled) return
        
        // 暂时禁用错误音效
        // playSound(AudioConfig.SoundType.ERROR)
    }
    
    /**
     * 播放指定类型的音效
     */
    private fun playSound(type: AudioConfig.SoundType, priority: Float = 0.5f) {
        val soundId = soundIdMap[type] ?: return
        
        // 请求音频焦点
        requestAudioFocus()
        
        // 计算实际音量 (0.0 - 1.0)
        val actualVolume = (volume / 100.0f) * priority
        
        try {
            soundPool.play(soundId, actualVolume, actualVolume, 1, 0, 1.0f)
        } catch (e: Exception) {
            Log.e(TAG, "播放音效失败", e)
        }
    }
    
    /**
     * 请求音频焦点
     */
    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .build()
            audioManager.requestAudioFocus(focusRequest)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            )
        }
    }
    
    /**
     * 更新音效设置
     */
    fun updateSettings(
        enabled: Boolean? = null,
        clickEnabled: Boolean? = null,
        successEnabled: Boolean? = null,
        volumeLevel: Int? = null
    ) {
        enabled?.let { soundEnabled = it }
        clickEnabled?.let { clickSoundEnabled = it }
        successEnabled?.let { successSoundEnabled = it }
        volumeLevel?.let { volume = it.coerceIn(0, 100) }
        
        Log.d(TAG, "音效设置更新：enabled=$soundEnabled, click=$clickSoundEnabled, success=$successSoundEnabled, volume=$volume")
    }
    
    /**
     * 释放资源
     */
    fun release() {
        try {
            soundPool.release()
            soundIdMap.clear()
            loadedSounds.clear()
            instance = null
            Log.d(TAG, "音效管理器资源已释放")
        } catch (e: Exception) {
            Log.e(TAG, "释放资源失败", e)
        }
    }
}