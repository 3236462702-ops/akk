package com.autoaccessibility.assistant.config

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/**
 * 应用配置管理
 * 统一管理 API 密钥、权限状态和用户偏好设置
 */
class AppConfig private constructor(context: Context) {

    companion object {
        private const val TAG = "AppConfig"
        private const val PREF_NAME = "auto_assistant_config"
        
        // CSDN API 固定密钥
        const val DEFAULT_API_KEY = "sk-kpoorxpbmlrrkptl"
        
        // OCR API 端点
        const val OCR_API_URL = "https://models.csdn.net/v1/images/ocr"
        
        // AI 对话 API 端点
        const val AI_API_URL = "https://models.csdn.net/v1/chat/completions"
        
        // 默认 OCR 模型
        const val DEFAULT_OCR_MODEL = "default_ocr"
        
        // 默认 AI 模型（支持图文混合）
        const val DEFAULT_AI_MODEL = "qwen-vl-plus"
        
        // 网络超时配置（毫秒）
        const val CONNECT_TIMEOUT = 30_000L
        const val READ_TIMEOUT = 60_000L
        const val WRITE_TIMEOUT = 60_000L
        
        // OCR/AI 重试次数
        const val API_RETRY_COUNT = 2
        
        @Volatile
        private var instance: AppConfig? = null
        
        /**
         * 获取单例实例
         */
        fun getInstance(context: Context): AppConfig {
            return instance ?: synchronized(this) {
                instance ?: AppConfig(context.applicationContext).also { 
                    instance = it 
                }
            }
        }
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    
    // ==================== API 配置 ====================
    
    /**
     * 获取 API Key
     */
    fun getApiKey(): String {
        return prefs.getString("api_key", DEFAULT_API_KEY) ?: DEFAULT_API_KEY
    }
    
    /**
     * 设置 API Key（用户可自定义）
     */
    fun setApiKey(key: String) {
        prefs.edit().putString("api_key", key).apply()
        Log.d(TAG, "API Key 已更新")
    }
    
    /**
     * 获取 OCR 模型名称
     */
    fun getOcrModel(): String {
        return prefs.getString("ocr_model", DEFAULT_OCR_MODEL) ?: DEFAULT_OCR_MODEL
    }
    
    /**
     * 设置 OCR 模型
     */
    fun setOcrModel(model: String) {
        prefs.edit().putString("ocr_model", model).apply()
    }
    
    /**
     * 获取 AI 模型名称
     */
    fun getAiModel(): String {
        return prefs.getString("ai_model", DEFAULT_AI_MODEL) ?: DEFAULT_AI_MODEL
    }
    
    /**
     * 设置 AI 模型
     */
    fun setAiModel(model: String) {
        prefs.edit().putString("ai_model", model).apply()
    }
    
    // ==================== 执行配置 ====================
    
    /**
     * 获取步骤间默认延迟（毫秒）
     */
    fun getStepDelay(): Long {
        return prefs.getLong("step_delay", 1000L)
    }
    
    /**
     * 设置步骤间延迟
     */
    fun setStepDelay(delay: Long) {
        prefs.edit().putLong("step_delay", delay).apply()
    }
    
    /**
     * 获取默认重试次数
     */
    fun getRetryCount(): Int {
        return prefs.getInt("retry_count", 3)
    }
    
    /**
     * 设置重试次数
     */
    fun setRetryCount(count: Int) {
        prefs.edit().putInt("retry_count", count).apply()
    }
    
    /**
     * 是否启用调试日志
     */
    fun isDebugMode(): Boolean {
        return prefs.getBoolean("debug_mode", false)
    }
    
    /**
     * 设置调试模式
     */
    fun setDebugMode(enabled: Boolean) {
        prefs.edit().putBoolean("debug_mode", enabled).apply()
        Log.d(TAG, "调试模式已${if (enabled) "开启" else "关闭"}")
    }
    
    // ==================== 权限状态 ====================
    
    /**
     * 保存无障碍权限已授予状态
     */
    fun setAccessibilityGranted(granted: Boolean) {
        prefs.edit().putBoolean("accessibility_granted", granted).apply()
    }
    
    /**
     * 检查无障碍权限是否已授予
     */
    fun isAccessibilityGranted(): Boolean {
        return prefs.getBoolean("accessibility_granted", false)
    }
    
    /**
     * 保存录屏权限已授予状态
     */
    fun setScreenCaptureGranted(granted: Boolean) {
        prefs.edit().putBoolean("screen_capture_granted", granted).apply()
    }
    
    /**
     * 检查录屏权限是否已授予
     */
    fun isScreenCaptureGranted(): Boolean {
        return prefs.getBoolean("screen_capture_granted", false)
    }
    
    // ==================== 其他配置 ====================
    
    /**
     * 获取上次使用的目标应用包名
     */
    fun getLastPackageName(): String? {
        return prefs.getString("last_package", null)
    }
    
    /**
     * 保存最后使用的包名
     */
    fun setLastPackageName(packageName: String) {
        prefs.edit().putString("last_package", packageName).apply()
    }
    
    /**
     * 清除所有配置（恢复默认）
     */
    fun reset() {
        prefs.edit().clear().apply()
        Log.d(TAG, "配置已重置")
    }
}