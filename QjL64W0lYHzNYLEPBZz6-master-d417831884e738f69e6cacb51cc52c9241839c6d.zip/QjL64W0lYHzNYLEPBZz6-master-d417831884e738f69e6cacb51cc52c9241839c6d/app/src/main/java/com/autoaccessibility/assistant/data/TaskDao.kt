package com.autoaccessibility.assistant.data

import androidx.room.*
import com.autoaccessibility.assistant.model.TaskScript

/**
 * 任务数据访问对象
 */
@Dao
interface TaskDao {

    @Query("SELECT * FROM task_script ORDER BY createdAt DESC")
    suspend fun getAllTasks(): List<TaskScript>

    @Query("SELECT * FROM task_script WHERE id = :taskId")
    suspend fun getTaskById(taskId: String): TaskScript?

    @Query("SELECT * FROM task_script WHERE isEnabled = 1")
    suspend fun getEnabledTasks(): List<TaskScript>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskScript)

    @Update
    suspend fun updateTask(task: TaskScript)

    @Delete
    suspend fun deleteTask(task: TaskScript)

    @Query("DELETE FROM task_script WHERE id = :taskId")
    suspend fun deleteTaskById(taskId: String)

    @Query("SELECT COUNT(*) FROM task_script")
    suspend fun getTaskCount(): Int
}