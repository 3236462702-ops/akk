package com.autoaccessibility.assistant.model

/**
 * 操作类型枚举
 * 定义所有支持的手势和操作类型
 */
enum class ActionType {
    CLICK,          // 点击
    LONG_PRESS,     // 长按
    SWIPE,          // 滑动
    INPUT_TEXT,     // 输入文本
    PRESS_BACK,     // 返回
    PRESS_HOME,     // 主页
    PRESS_RECENTS,  // 最近任务
    WAIT,           // 等待
    CONDITION,      // 条件判断
    LOOP_START,     // 循环开始
    LOOP_END,       // 循环结束
    SCREEN_CAPTURE, // 屏幕捕获
    OCR_ANALYZE,    // OCR 识别
    AI_DECIDE       // AI 决策
}