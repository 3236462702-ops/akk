package com.autoaccessibility.assistant.compat

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * 澎湃系统（HyperOS）和 MIUI 适配层
 * 处理小米系统的特殊权限、后台限制和行为差异
 * 
 * 适配版本：
 * - HyperOS 1.x / 2.x
 * - MIUI 12 / 13 / 14
 */
class HyperOSCompat {

    companion object {
        private const val TAG = "HyperOSCompat"
        
        @Volatile
        private var instance: HyperOSCompat? = null
        
        fun getInstance(): HyperOSCompat {
            return instance ?: synchronized(this) {
                instance ?: HyperOSCompat().also { instance = it }
            }
        }
        
        // 系统标识
        private const val MANUFACTURER_XIAOMI = "Xiaomi"
        
        // MIUI/HyperOS 版本号获取属性
        private const val PROPERTY_MIUI_VERSION = "ro.miui.ui.version.name"
        private const val PROPERTY_OS_VERSION = "ro.build.version.incremental"
    }

    /**
     * 检查是否为小米设备（MIUI 或 HyperOS）
     */
    fun isXiaomiDevice(): Boolean {
        return Build.MANUFACTURER.equals(MANUFACTURER_XIAOMI, ignoreCase = true)
    }

    /**
     * 检查是否为澎湃系统（HyperOS）
     * HyperOS 版本号通常以 "OS" 开头，如 "OS1.0"、"OS2.0"
     */
    fun isHyperOS(): Boolean {
        if (!isXiaomiDevice()) return false
        
        try {
            val miuiVersion = getSystemProperty(PROPERTY_MIUI_VERSION) ?: ""
            // HyperOS 的版本号格式与 MIUI 不同
            return miuiVersion.contains("OS", ignoreCase = true) || 
                   miuiVersion.startsWith("1.") ||  // HyperOS 1.x
                   miuiVersion.startsWith("2.")     // HyperOS 2.x
        } catch (e: Exception) {
            Log.e(TAG, "检测 HyperOS 失败", e)
            return false
        }
    }

    /**
     * 获取 MIUI/HyperOS 版本号
     */
    fun getMiuiVersion(): String {
        return getSystemProperty(PROPERTY_MIUI_VERSION) ?: "Unknown"
    }

    /**
     * 获取系统完整版本号
     */
    fun getOsVersion(): String {
        return getSystemProperty(PROPERTY_OS_VERSION) ?: Build.VERSION.RELEASE
    }

    /**
     * 检查是否运行在 Android 15 及以上
     * Android 15 API 级别为 35
     */
    fun isAndroid15OrAbove(): Boolean {
        return Build.VERSION.SDK_INT >= 35
    }

    /**
     * 检查是否运行在 Android 16 及以上
     * Android 16 API 级别为 36（预留）
     */
    fun isAndroid16OrAbove(): Boolean {
        return Build.VERSION.SDK_INT >= 36
    }

    /**
     * 检查是否运行在 Android 14 及以上
     * Android 14 API 级别为 34
     */
    fun isAndroid14OrAbove(): Boolean {
        return Build.VERSION.SDK_INT >= 34
    }
    
    /**
     * 获取澎湃系统主版本号（用于区分 HyperOS 2.0/3.0）
     * HyperOS 2.0 对应 Android 15，HyperOS 3.0 对应 Android 16
     */
    fun getHyperOSMajorVersion(): Int {
        if (!isHyperOS()) return 0
        
        try {
            val miuiVersion = getMiuiVersion()
            return when {
                miuiVersion.startsWith("OS3.") || miuiVersion.contains("3.0") -> 3
                miuiVersion.startsWith("OS2.") || miuiVersion.contains("2.0") -> 2
                miuiVersion.startsWith("OS1.") || miuiVersion.contains("1.0") -> 1
                else -> 1
            }
        } catch (e: Exception) {
            Log.e(TAG, "获取澎湃版本号失败", e)
            return 1
        }
    }

    // ==================== 权限适配 ====================

    /**
     * 检查悬浮窗权限（SYSTEM_ALERT_WINDOW）
     * 澎湃系统需要特殊处理
     */
    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    /**
     * 引导用户开启悬浮窗权限
     * 澎湃系统的设置路径与原生 Android 不同
     */
    fun requestOverlayPermission(context: Context) {
        try {
            val intent = when {
                // HyperOS 2.x 特殊路径
                isHyperOS() && getMiuiVersion().startsWith("2.") -> {
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                        setClassName(
                            "com.miui.securitycenter",
                            "com.miui.permissionEditor.SoftPermissionDetailActivity"
                        )
                    }
                }
                // MIUI / HyperOS 1.x 路径
                isXiaomiDevice() -> {
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                        // 尝试 MIUI 专用设置页面
                        setClassName(
                            "com.miui.securitycenter",
                            "com.miui.permcenter.permissions.PermissionsEditorActivity"
                        )
                    }
                }
                // 原生 Android 路径
                else -> {
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                }
            }
            
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            Log.d(TAG, "已启动悬浮窗权限设置页面")
            
        } catch (e: Exception) {
            Log.e(TAG, "启动悬浮窗设置失败", e)
            // 降级方案：使用通用设置页面
            try {
                val fallbackIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
            } catch (e2: Exception) {
                Log.e(TAG, "降级方案也失败", e2)
            }
        }
    }

    /**
     * 检查无障碍服务权限
     * MIUI/HyperOS 可能需要额外确认
     */
    fun hasAccessibilityPermission(context: Context): Boolean {
        val serviceName = "${context.packageName}/com.autoaccessibility.assistant.service.AutoAccessibilityService"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        
        return enabledServices.contains(serviceName) || 
               enabledServices.contains(context.packageName)
    }

    /**
     * 引导用户开启无障碍服务
     */
    fun requestAccessibilityPermission(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            Log.d(TAG, "已启动无障碍设置页面")
        } catch (e: Exception) {
            Log.e(TAG, "启动无障碍设置失败", e)
        }
    }

    /**
     * 检查录屏权限（MediaProjection）
     * Android 15 有更严格的限制
     */
    fun hasScreenCapturePermission(context: Context): Boolean {
        // MediaProjection 权限是运行时动态申请的，无法预先检查
        // 这里只检查是否有相关的基础权限
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.FOREGROUND_SERVICE
        ) == PackageManager.PERMISSION_GRANTED
    }

    // ==================== 后台限制适配 ====================

    /**
     * 检查电池优化是否已禁用
     * 澎湃系统对后台应用限制较严，需要引导用户关闭省电策略
     */
    fun isBatteryOptimizationDisabled(context: Context): Boolean {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.isIgnoringBatteryOptimizations(context.packageName)
    }

    /**
     * 引导用户关闭电池优化
     * 保持录屏服务和抢单功能在后台持续运行
     */
    fun requestDisableBatteryOptimization(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Log.d(TAG, "已启动电池优化设置页面")
        } catch (e: Exception) {
            Log.e(TAG, "启动电池优化设置失败", e)
            // 降级方案
            fallbackBatterySettings(context)
        }
    }

    /**
     * 降级方案：引导到应用详情页面
     */
    private fun fallbackBatterySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "降级方案失败", e)
        }
    }

    /**
     * 检查自启动权限
     * MIUI/HyperOS 需要手动开启自启动才能后台运行
     */
    fun hasAutoStartPermission(context: Context): Boolean {
        // 自启动权限没有公开 API 检查，只能通过反射或系统属性
        // 这里简化处理，始终返回 false 以引导用户检查
        return if (isXiaomiDevice()) {
            false  // 小米设备需要手动检查
        } else {
            true   // 其他设备假设已开启
        }
    }

    /**
     * 引导用户开启自启动权限
     */
    fun requestAutoStartPermission(context: Context) {
        try {
            val intent = Intent().apply {
                component = android.content.ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Log.d(TAG, "已启动自启动管理页面")
        } catch (e: Exception) {
            Log.e(TAG, "启动自启动设置失败", e)
            // 降级方案
            fallbackBatterySettings(context)
        }
    }

    // ==================== 澎湃系统特殊适配 ====================

    /**
     * 检查澎湃系统的截图延迟特性
     * 部分机型截图有 100-300ms 延迟，需要在识别时考虑
     */
    fun getScreenshotDelayMs(): Long {
        return when {
            isAndroid16OrAbove() && isHyperOS() -> 250  // HyperOS 3.0 (Android 16) 延迟最大
            isAndroid15OrAbove() && isHyperOS() -> 200  // HyperOS 2.0 (Android 15) 延迟较大
            isHyperOS() -> 150                          // HyperOS 1.x
            isXiaomiDevice() -> 100                     // MIUI
            else -> 50                                  // 其他设备
        }
    }
    
    /**
     * Android 15/16 澎湃系统后台服务保活策略
     * 新版本系统对后台限制更严格，需要使用前台服务 + 通知保活
     */
    fun shouldUseForegroundService(): Boolean {
        return isAndroid15OrAbove() || isHyperOS()
    }
    
    /**
     * 检查是否需要处理隐私沙盒限制
     * Android 15+ 对屏幕捕获有更严格的隐私限制
     */
    fun hasPrivacySandboxRestrictions(): Boolean {
        return isAndroid15OrAbove()
    }
    
    /**
     * 获取推荐的手势注入延迟
     * Android 15/16 澎湃系统需要更长的延迟以确保系统正确处理
     */
    fun getRecommendedGestureDelayMs(): Int {
        return when {
            isAndroid16OrAbove() -> 300  // Android 16 需要更长延迟
            isAndroid15OrAbove() -> 250  // Android 15 需要中等延迟
            isHyperOS() -> 200           // HyperOS 1.x
            else -> 150                  // 其他设备
        }
    }
    
    /**
     * 检查是否需要特殊处理悬浮窗权限
     * Android 15+ 的 SYSTEM_ALERT_WINDOW 权限有更严格的限制
     */
    fun needsSpecialOverlayHandling(): Boolean {
        return isAndroid15OrAbove()
    }
    
    /**
     * 获取应用保活建议
     * 针对不同系统版本提供不同的保活策略
     */
    fun getBackgroundKeepAliveAdvice(context: Context): String {
        return when {
            isAndroid16OrAbove() && isHyperOS() -> 
                "Android 16 + 澎湃 3.0：需开启自启动 + 关闭电池优化 + 锁定后台"
            isAndroid15OrAbove() && isHyperOS() -> 
                "Android 15 + 澎湃 2.0：需开启自启动 + 关闭电池优化"
            isHyperOS() -> 
                "澎湃系统：建议开启自启动权限"
            isXiaomiDevice() -> 
                "MIUI 系统：建议开启自启动权限"
            else -> 
                "标准 Android：保持前台服务运行即可"
        }
    }

    /**
     * 获取系统适配状态描述
     * 用于在设置页面显示当前系统信息
     */
    fun getCompatibilityStatus(context: Context): String {
        val sb = StringBuilder()
        
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        
        if (isXiaomiDevice()) {
            if (isHyperOS()) {
                sb.append("澎湃系统 ${getMiuiVersion()}")
            } else {
                sb.append("MIUI 系统 ${getMiuiVersion()}")
            }
        } else {
            sb.append("标准 Android 系统")
        }
        return sb.toString()
    }

    /**
     * 获取系统属性（通过反射）
     */
    private fun getSystemProperty(key: String): String? {
        try {
            val clazz = Class.forName("android.os.SystemProperties")
            val method = clazz.getMethod("get", String::class.java)
            return method.invoke(null, key) as? String
        } catch (e: Exception) {
            Log.e(TAG, "获取系统属性失败：$key", e)
            return null
        }
    }
}