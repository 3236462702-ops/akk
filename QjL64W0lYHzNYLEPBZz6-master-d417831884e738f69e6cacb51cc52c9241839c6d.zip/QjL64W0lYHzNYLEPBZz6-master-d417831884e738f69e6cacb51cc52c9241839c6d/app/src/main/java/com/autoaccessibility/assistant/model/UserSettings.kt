package com.autoaccessibility.assistant.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters

/**
 * 用户自定义设置数据类
 * 用于配置自动抢单助手的各项参数
 */
@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey(autoGenerate = false)
    val id: Int = 0,  // 固定为 0，单例配置
    
    // === 刷新设置 ===
    /**
     * 下拉刷新速度（秒）
     * 范围：3-10 秒，默认 5 秒
     * 独立运行，不影响其他判断逻辑
     */
    val refreshIntervalSeconds: Int = 5,
    
    // === 刷新延迟设置 ===
    /**
     * 固定刷新延迟（毫秒）
     * 范围：1000-10000ms（1-10 秒），默认 2000ms
     * 当 refreshDelayRandom 为 false 时使用
     */
    val refreshDelayFixed: Int = 2000,
    
    /**
     * 是否启用随机刷新延迟
     * 启用后使用 2000-5000ms（2-5 秒）随机延迟，与固定延迟互斥
     * 默认关闭
     */
    val refreshDelayRandom: Boolean = false,
    
    // === 价格过滤设置 ===
    /**
     * 是否启用价格过滤
     */
    val enablePriceFilter: Boolean = false,
    
    /**
     * 最小价格（元）
     * 默认 0，表示不限制
     */
    val minPrice: Double = 0.0,
    
    /**
     * 最大价格（元）
     * 默认 9999，表示不限制
     */
    val maxPrice: Double = 9999.0,
    
    // === 距离过滤设置 ===
    /**
     * 是否启用距离过滤
     */
    val enableDistanceFilter: Boolean = false,
    
    /**
     * 最大接驾距离（公里）
     * 乘客距离司机的最大距离，默认 10 公里
     */
    val maxPickupDistance: Double = 10.0,
    
    // === 行程距离过滤设置 ===
    /**
     * 是否启用行程距离过滤
     */
    val enableTripDistanceFilter: Boolean = false,
    
    /**
     * 最小行程距离（公里）
     * 订单行程的最小距离，默认 0
     */
    val minTripDistance: Double = 0.0,
    
    /**
     * 最大行程距离（公里）
     * 订单行程的最大距离，默认 999 公里
     */
    val maxTripDistance: Double = 999.0,
    
    // === 订单类型过滤 ===
    /**
     * 是否启用订单类型过滤
     */
    val enableOrderTypeFilter: Boolean = false,
    
    /**
     * 选中的订单类型（JSON 字符串存储）
     * 包含：拼车、快车、特快、四轮小件、网约车、用户出价、特惠、长途特惠
     */
    val selectedOrderTypes: String = "",
    
    // === 区域过滤设置 ===
    /**
     * 是否启用不接区域（黑名单模式）
     * 勾选后生效，与 includeRegionEnabled 互斥
     */
    val excludeRegionEnabled: Boolean = false,
    
    /**
     * 是否启用只接区域（白名单模式）
     * 勾选后生效，与 excludeRegionEnabled 互斥
     */
    val includeRegionEnabled: Boolean = false,
    
    /**
     * 不接的区域列表（黑名单，逗号分隔存储）
     * 当 excludeRegionEnabled 为 true 时生效
     */
    val excludedDistricts: String = "",
    
    /**
     * 只接的区域列表（白名单，逗号分隔存储）
     * 当 includeRegionEnabled 为 true 时生效
     */
    val includedDistricts: String = "",
    
    // === 总开关 ===
    /**
     * 自动抢单总开关
     */
    val autoGrabEnabled: Boolean = false,
    
    // === 点击延迟设置 ===
    /**
     * 固定点击延迟（毫秒）
     * 范围：200-10000ms，默认 500ms
     * 当 clickDelayRandom 为 false 时使用
     */
    val clickDelayFixed: Int = 500,
    
    /**
     * 是否启用随机延迟
     * 启用后使用 200-2000ms 随机延迟，与固定延迟互斥
     * 默认关闭
     */
    val clickDelayRandom: Boolean = false,
    
    /**
     * 随机延迟最小值（毫秒）
     * 固定为 200ms，不可更改
     */
    val clickDelayRandomMin: Int = 200,
    
    /**
     * 随机延迟最大值（毫秒）
     * 固定为 2000ms，不可更改
     */
    val clickDelayRandomMax: Int = 2000,
    
    // === 统计信息 ===
    /**
     * 累计刷新次数
     */
    val totalRefreshCount: Long = 0L,
    
    /**
     * 累计过滤订单数
     */
    val totalFilteredOrders: Long = 0L,
    
    /**
     * 累计成功抢单数
     */
    val totalGrabbedOrders: Long = 0L,
    
    // === 时间戳 ===
    /**
     * 最后更新时间
     */
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        /**
         * 点击延迟配置常量
         */
        const val DELAY_MIN_MS = 200
        const val DELAY_MAX_MS = 10000
        const val DELAY_DEFAULT_MS = 500
        const val RANDOM_DELAY_MIN_MS = 200
        const val RANDOM_DELAY_MAX_MS = 2000
        
        /**
         * 刷新延迟配置常量
         */
        const val REFRESH_DELAY_MIN_MS = 1000
        const val REFRESH_DELAY_MAX_MS = 10000
        const val REFRESH_DELAY_DEFAULT_MS = 2000
        const val REFRESH_RANDOM_DELAY_MIN_MS = 2000
        const val REFRESH_RANDOM_DELAY_MAX_MS = 5000
        
        /**
         * 重庆各区县列表
         */
        val CHONGQING_DISTRICTS = listOf(
            "渝中区", "江北区", "南岸区", "九龙坡区", "沙坪坝区", "大渡口区",
            "北碚区", "渝北区", "巴南区", "万州区", "涪陵区", "永川区",
            "合川区", "江津区", "长寿区", "南川区", "綦江区", "大足区",
            "璧山区", "铜梁区", "潼南区", "荣昌区", "开州区", "梁平区",
            "武隆区", "城口县", "丰都县", "垫江县", "忠县", "云阳县",
            "奉节县", "巫山县", "巫溪县", "石柱县", "秀山县", "酉阳县", "彭水县",
            "两江新区"
        )
        
        /**
         * 获取默认配置
         */
        fun getDefault(): UserSettings {
            return UserSettings()
        }
        
        /**
         * 验证刷新间隔是否合法
         */
        fun isValidRefreshInterval(seconds: Int): Boolean {
            return seconds in 3..10
        }
        
        /**
         * 验证固定延迟是否合法
         */
        fun isValidClickDelay(delayMs: Int): Boolean {
            return delayMs in DELAY_MIN_MS..DELAY_MAX_MS
        }
        
        /**
         * 验证刷新延迟是否合法
         */
        fun isValidRefreshDelay(delayMs: Int): Boolean {
            return delayMs in REFRESH_DELAY_MIN_MS..REFRESH_DELAY_MAX_MS
        }
        
        /**
         * 验证价格区间是否合法
         */
        fun isValidPriceRange(min: Double, max: Double): Boolean {
            return min >= 0 && max >= min && max <= 9999
        }
        
        /**
         * 验证距离是否合法
         */
        fun isValidDistance(distance: Double): Boolean {
            return distance >= 0 && distance <= 999
        }
    }
    
    /**
     * 检查价格是否符合设置
     */
    fun isPriceValid(price: Double): Boolean {
        if (!enablePriceFilter) return true
        return price in minPrice..maxPrice
    }
    
    /**
     * 检查接驾距离是否符合设置
     */
    fun isPickupDistanceValid(distance: Double): Boolean {
        if (!enableDistanceFilter) return true
        return distance <= maxPickupDistance
    }
    
    /**
     * 检查行程距离是否符合设置
     */
    fun isTripDistanceValid(distance: Double): Boolean {
        if (!enableTripDistanceFilter) return true
        return distance in minTripDistance..maxTripDistance
    }
    
    /**
     * 检查订单是否符合所有条件
     */
    fun isOrderValid(
        price: Double,
        pickupDistance: Double,
        tripDistance: Double,
        orderType: String? = null,
        district: String? = null
    ): Boolean {
        // 1. 订单类型过滤
        if (enableOrderTypeFilter && !isOrderTypeValid(orderType)) {
            return false
        }
        
        // 2. 价格过滤
        if (!isPriceValid(price)) return false
        
        // 3. 接驾距离过滤
        if (!isPickupDistanceValid(pickupDistance)) return false
        
        // 4. 行程距离过滤
        if (!isTripDistanceValid(tripDistance)) return false
        
        // 5. 区域过滤（新增）
        if (!isRegionValid(district)) return false
        
        return true
    }
    
    /**
     * 检查订单类型是否符合设置
     */
    fun isOrderTypeValid(orderType: String?): Boolean {
        if (!enableOrderTypeFilter) return true
        if (orderType.isNullOrBlank()) return true
        
        // 解析选中的类型列表
        val selectedTypes = parseSelectedOrderTypes()
        
        // 如果未选择任何类型，默认全部接受
        if (selectedTypes.isEmpty()) return true
        
        // 检查订单类型是否在选中列表中
        return selectedTypes.any { type ->
            orderType.contains(type, ignoreCase = true) ||
            type.contains(orderType, ignoreCase = true)
        }
    }
    
    /**
     * 检查区域是否符合设置
     */
    fun isRegionValid(district: String?): Boolean {
        // 如果区域为空，直接通过
        if (district.isNullOrBlank()) {
            return true
        }
        
        return when {
            // 黑名单模式：不在排除列表中则通过
            excludeRegionEnabled -> {
                val excluded = parseExcludedDistricts()
                // 如果黑名单为空，默认通过
                if (excluded.isEmpty()) return true
                return excluded.none { ex -> district.contains(ex, ignoreCase = true) }
            }
            // 白名单模式：在包含列表中则通过
            includeRegionEnabled -> {
                val included = parseIncludedDistricts()
                // 如果白名单为空，默认不限制
                if (included.isEmpty()) return true
                return included.any { inc -> district.contains(inc, ignoreCase = true) }
            }
            // 都不启用，默认通过
            else -> true
        }
    }
    
    /**
     * 解析选中的订单类型列表
     */
    fun parseSelectedOrderTypes(): List<String> {
        if (selectedOrderTypes.isBlank()) return emptyList()
        return selectedOrderTypes.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }
    
    /**
     * 保存选中的订单类型
     */
    fun saveSelectedOrderTypes(types: List<String>): UserSettings {
        return copy(selectedOrderTypes = types.joinToString(","))
    }
    
    /**
     * 解析排除的区域列表
     */
    fun parseExcludedDistricts(): List<String> {
        if (excludedDistricts.isBlank()) return emptyList()
        return excludedDistricts.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }
    
    /**
     * 保存排除的区域列表
     */
    fun saveExcludedDistricts(districts: List<String>): UserSettings {
        return copy(excludedDistricts = districts.joinToString(","))
    }
    
    /**
     * 解析包含的区域列表
     */
    fun parseIncludedDistricts(): List<String> {
        if (includedDistricts.isBlank()) return emptyList()
        return includedDistricts.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }
    
    /**
     * 保存包含的区域列表
     */
    fun saveIncludedDistricts(districts: List<String>): UserSettings {
        return copy(includedDistricts = districts.joinToString(","))
    }
    
    /**
     * 更新统计信息
     */
    fun incrementRefreshCount(): UserSettings {
        return copy(totalRefreshCount = totalRefreshCount + 1)
    }
    
    fun incrementFilteredCount(): UserSettings {
        return copy(totalFilteredOrders = totalFilteredOrders + 1)
    }
    
    fun incrementGrabbedCount(): UserSettings {
        return copy(totalGrabbedOrders = totalGrabbedOrders + 1)
    }
}

/**
 * 区域过滤模式枚举（保留用于向后兼容）
 */
enum class RegionFilterMode {
    NONE,      // 不限制区域
    EXCLUDE,   // 不接指定区域（黑名单）
    INCLUDE    // 只接指定区域（白名单）
}

/**
 * 从旧的 regionFilterMode 转换为新的布尔值
 */
fun convertLegacyRegionFilterMode(
    legacyMode: RegionFilterMode,
    excludedDistricts: String,
    includedDistricts: String
): Pair<Boolean, Boolean> {
    return when (legacyMode) {
        RegionFilterMode.EXCLUDE -> {
            // 旧模式下有排除列表才启用
            val enabled = excludedDistricts.isNotBlank()
            Pair(enabled, false)
        }
        RegionFilterMode.INCLUDE -> {
            // 旧模式下有包含列表才启用
            val enabled = includedDistricts.isNotBlank()
            Pair(false, enabled)
        }
        RegionFilterMode.NONE -> Pair(false, false)
    }
}

/**
 * 订单信息数据类
 * 用于存储从 OCR 解析出的订单结构化信息
 */
data class OrderInfo(
    val price: Double = 0.0,              // 订单价格
    val pickupDistance: Double = 0.0,     // 接驾距离（公里）
    val tripDistance: Double = 0.0,       // 行程距离（公里）
    val passengerLocation: String = "",   // 乘客上车点
    val destination: String = "",         // 目的地
    val orderType: String = "",           // 订单类型（快车、专车等）
    val district: String = "",            // 所属区域（新增）
    val rawText: String = ""              // 原始 OCR 文本
) {
    /**
     * 转换为可读描述
     */
    fun toDescription(): String {
        val typeDesc = if (orderType.isNotBlank()) "[$orderType] " else ""
        val districtDesc = if (district.isNotBlank()) "($district) " else ""
        return "${typeDesc}${districtDesc}订单：¥$price, 接驾${pickupDistance}km, 行程${tripDistance}km"
    }
    
    /**
     * 获取详细的日志描述
     */
    fun toLogDescription(): String {
        val typeDesc = if (orderType.isNotBlank()) "类型:$orderType | " else ""
        val districtDesc = if (district.isNotBlank()) "区域:$district | " else ""
        return "${typeDesc}${districtDesc}价格:¥$price | 接驾:${pickupDistance}km | 行程:${tripDistance}km"
    }
}

/**
 * 订单类型转换器（Room 数据库使用）
 */
class OrderTypeConverters {
    @TypeConverter
    fun fromOrderTypeList(types: List<String>): String {
        return types.joinToString(",")
    }
    
    @TypeConverter
    fun toOrderTypeList(data: String): List<String> {
        return if (data.isBlank()) emptyList() else data.split(",").map { it.trim() }
    }
}