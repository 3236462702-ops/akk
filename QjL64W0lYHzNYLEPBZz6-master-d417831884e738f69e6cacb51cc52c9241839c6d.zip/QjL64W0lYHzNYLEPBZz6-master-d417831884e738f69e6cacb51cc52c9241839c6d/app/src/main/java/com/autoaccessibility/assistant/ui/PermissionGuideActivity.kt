package com.autoaccessibility.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.autoaccessibility.assistant.R

/**
 * 权限引导界面
 * 引导用户授予悬浮窗权限
 */
class PermissionGuideActivity : AppCompatActivity() {

    companion object {
        /**
         * 检查是否有悬浮窗权限
         */
        fun hasOverlayPermission(context: android.content.Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true // 低版本默认允许
            }
        }

        /**
         * 跳转到系统设置页面授权
         */
        fun requestOverlayPermission(context: android.content.Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                )
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
            }
        }
    }

    private lateinit var btnGrantPermission: Button
    private lateinit var btnSkip: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission_guide)

        bindViews()
        setupListeners()
    }

    private fun bindViews() {
        btnGrantPermission = findViewById(R.id.btnGrantPermission)
        btnSkip = findViewById(R.id.btnSkip)
    }

    private fun setupListeners() {
        btnGrantPermission.setOnClickListener {
            requestOverlayPermission(this)
            // 等待用户授权后返回
        }

        btnSkip.setOnClickListener {
            // 跳过权限，仅使用通知栏显示状态
            navigateToMain()
        }
    }

    override fun onResume() {
        super.onResume()
        // 检查用户是否已授权
        if (hasOverlayPermission(this)) {
            navigateToMain()
        }
    }

    private fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}