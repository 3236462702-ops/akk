package com.autoaccessibility.assistant.recognition

import android.graphics.Bitmap
import android.util.Log
import com.autoaccessibility.assistant.model.ButtonInfo
import com.autoaccessibility.assistant.model.ButtonType
import com.autoaccessibility.assistant.model.RectF
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 智能按钮识别器
 * 使用 OCR 和图像特征识别抢单按钮位置
 */
class ButtonRecognizer {

    companion object {
        private const val TAG = "ButtonRecognizer"
        
        @Volatile
        private var instance: ButtonRecognizer? = null
        
        /**
         * 获取单例实例
         */
        fun getInstance(): ButtonRecognizer {
            return instance ?: synchronized(this) {
                instance ?: ButtonRecognizer().also { instance = it }
            }
        }
    }

    // 按钮位置缓存（应用包名 -> 按钮信息）
    private val buttonCache = mutableMapOf<String, ButtonInfo>()
    
    // 连续失败计数
    private var consecutiveFailures = 0
    
    // 最大失败次数
    private val maxFailures = 3

    /**
     * 识别抢单按钮位置（简化调用版本）
     * @return 识别到的按钮信息，未识别返回 null
     */
    suspend fun recognizeGrabButton(): ButtonInfo? {
        // 简化实现：使用默认参数调用 recognizeButton
        // 实际项目中应该传入屏幕截图和 OCR 结果
        return recognizeButton(null, emptyList(), "")
    }

    /**
     * 识别抢单按钮位置
     * @param bitmap 屏幕截图
     * @param ocrResult OCR 识别结果（包含文字和位置）
     * @param packageName 当前应用包名
     * @return 识别到的按钮信息，未识别返回 null
     */
    suspend fun recognizeButton(
        bitmap: Bitmap?,
        ocrResult: List<OcrWord>,
        packageName: String
    ): ButtonInfo? {
        return withContext(Dispatchers.Default) {
            try {
                // 1. 优先从缓存获取
                val cached = buttonCache[packageName]
                if (cached != null && isCacheValid(cached)) {
                    Log.d(TAG, "使用缓存的按钮位置：${cached.type}")
                    return@withContext cached
                }
                
                // 2. OCR 关键词匹配
                val grabButton = findButtonByKeywords(ocrResult)
                if (grabButton != null) {
                    Log.d(TAG, "通过关键词识别到按钮：${grabButton.type}, 置信度：${grabButton.confidence}")
                    buttonCache[packageName] = grabButton
                    consecutiveFailures = 0
                    return@withContext grabButton
                }
                
                // 3. 图像特征匹配（颜色、形状等）
                if (bitmap != null) {
                    val featureButton = findButtonByFeatures(bitmap, ocrResult)
                    if (featureButton != null) {
                        Log.d(TAG, "通过图像特征识别到按钮：${featureButton.type}")
                        buttonCache[packageName] = featureButton
                        consecutiveFailures = 0
                        return@withContext featureButton
                    }
                }
                
                // 4. 识别失败
                consecutiveFailures++
                Log.w(TAG, "按钮识别失败，连续失败次数：$consecutiveFailures/$maxFailures")
                
                if (consecutiveFailures >= maxFailures) {
                    Log.e(TAG, "连续识别失败 $maxFailures 次，建议用户手动标记")
                }
                
                null
                
            } catch (e: Exception) {
                Log.e(TAG, "按钮识别异常", e)
                consecutiveFailures++
                null
            }
        }
    }

    /**
     * 通过 OCR 关键词查找按钮
     */
    private fun findButtonByKeywords(ocrResult: List<OcrWord>): ButtonInfo? {
        // 抢单按钮关键词（按优先级排序）
        val priorityKeywords = listOf(
            Pair("抢单", ButtonType.GRAB_ORDER),
            Pair("立即抢", ButtonType.GRAB_ORDER),
            Pair("接受订单", ButtonType.ACCEPT),
            Pair("接受", ButtonType.ACCEPT),
            Pair("确认接单", ButtonType.CONFIRM),
            Pair("确认", ButtonType.CONFIRM),
            Pair("接单", ButtonType.GRAB_ORDER)
        )
        
        for ((keyword, type) in priorityKeywords) {
            for (word in ocrResult) {
                if (word.text.contains(keyword, ignoreCase = true)) {
                    // 计算按钮中心坐标
                    val centerX = word.bounds.left + word.bounds.width() / 2
                    val centerY = word.bounds.top + word.bounds.height() / 2
                    
                    // 估算按钮大小（文字区域的 1.5 倍）
                    val estimatedWidth = word.bounds.width() * 1.5f
                    val estimatedHeight = word.bounds.height() * 2.5f
                    
                    // 根据关键词匹配度计算置信度
                    val confidence = calculateConfidence(word.text, keyword)
                    
                    return ButtonInfo(
                        type = type,
                        centerX = centerX,
                        centerY = centerY,
                        width = estimatedWidth,
                        height = estimatedHeight,
                        confidence = confidence,
                        recognizedAt = System.currentTimeMillis()
                    )
                }
            }
        }
        
        return null
    }

    /**
     * 通过图像特征查找按钮
     * （简化实现，实际项目中可使用模板匹配或深度学习）
     */
    private fun findButtonByFeatures(bitmap: Bitmap, ocrResult: List<OcrWord>): ButtonInfo? {
        // 这里可以实现更复杂的图像识别逻辑
        // 例如：检测红色/橙色区域、圆角矩形等按钮常见特征
        
        // 简化实现：在屏幕下半部分寻找面积较大的文字区域
        val screenHeight = bitmap.height
        val lowerHalfWords = ocrResult.filter { word ->
            word.bounds.top > screenHeight * 0.5 && 
            word.bounds.width() > 100 && 
            word.bounds.height() > 80
        }
        
        if (lowerHalfWords.isNotEmpty()) {
            val candidate = lowerHalfWords.maxByOrNull { it.bounds.width() * it.bounds.height() }
            candidate?.let { word ->
                return ButtonInfo(
                    type = ButtonType.GRAB_ORDER,
                    centerX = word.bounds.left + word.bounds.width() / 2,
                    centerY = word.bounds.top + word.bounds.height() / 2,
                    width = word.bounds.width() * 1.5f,
                    height = word.bounds.height() * 2.5f,
                    confidence = 0.6f,  // 特征匹配置信度较低
                    recognizedAt = System.currentTimeMillis()
                )
            }
        }
        
        return null
    }

    /**
     * 计算置信度
     */
    private fun calculateConfidence(text: String, keyword: String): Float {
        return when {
            text == keyword -> 1.0f
            text.contains(keyword) -> 0.9f
            text.lowercase().contains(keyword.lowercase()) -> 0.8f
            else -> 0.7f
        }
    }

    /**
     * 检查缓存是否有效（5 分钟内有效）
     */
    private fun isCacheValid(cached: ButtonInfo): Boolean {
        val age = System.currentTimeMillis() - cached.recognizedAt
        return age < 5 * 60 * 1000  // 5 分钟
    }

    /**
     * 清除缓存
     */
    fun clearCache() {
        buttonCache.clear()
        consecutiveFailures = 0
        Log.d(TAG, "按钮缓存已清除")
    }

    /**
     * 清除特定应用的缓存
     */
    fun clearCache(packageName: String) {
        buttonCache.remove(packageName)
        Log.d(TAG, "已清除 $packageName 的按钮缓存")
    }

    /**
     * 是否应该暂停识别（连续失败过多）
     */
    fun shouldPauseRecognition(): Boolean {
        return consecutiveFailures >= maxFailures
    }

    /**
     * 重置失败计数
     */
    fun resetFailures() {
        consecutiveFailures = 0
    }
}

/**
 * OCR 识别结果中的单词
 */
data class OcrWord(
    val text: String,
    val bounds: RectF,
    val confidence: Float = 1.0f
)