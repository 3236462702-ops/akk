package com.autoaccessibility.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.autoaccessibility.assistant.R
import com.autoaccessibility.assistant.config.SettingsManager
import com.autoaccessibility.assistant.controller.GestureController
import com.autoaccessibility.assistant.data.SettingsRepository
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 自动刷新服务
 * 独立运行的后台服务，按用户设置的间隔（3-5 秒）自动执行下拉刷新操作
 * 不影响其他判断逻辑，纯 UI 交互
 */
class AutoRefreshService : Service() {

    companion object {
        private const val TAG = "AutoRefreshService"
        private const val NOTIFICATION_CHANNEL_ID = "auto_refresh_channel"
        private const val NOTIFICATION_ID = 1001
        
        @Volatile
        private var instance: AutoRefreshService? = null
        
        /**
         * 获取服务实例
         */
        fun getInstance(): AutoRefreshService? {
            return instance
        }
        
        /**
         * 启动服务
         */
        fun start(context: Context) {
            val intent = Intent(context, AutoRefreshService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        
        /**
         * 停止服务
         */
        fun stop(context: Context) {
            val intent = Intent(context, AutoRefreshService::class.java)
            context.stopService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob())
    private val isRunning = AtomicBoolean(false)
    private var refreshJob: Job? = null
    
    private val gestureController = GestureController()
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var settingsManager: SettingsManager
    
    // 监听设置变化
    private var settingsUpdateJob: Job? = null
    
    // 当前刷新间隔（秒）
    private var currentRefreshInterval = 5
    
    // 当前刷新延迟（毫秒）
    private var currentRefreshDelay = 2000
    
    // 统计信息
    private var refreshCount = 0L

    override fun onCreate() {
        super.onCreate()
        instance = this
        settingsRepository = SettingsRepository.getInstance(applicationContext)
        settingsManager = SettingsManager.getInstance()
        settingsManager.initialize(applicationContext)
        
        createNotificationChannel()
        loadCurrentSettings()
        
        Log.d(TAG, "自动刷新服务已创建")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "自动刷新服务启动")
        
        // 启动前台服务
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)
        
        // 开始自动刷新
        startAutoRefresh()
        
        // 监听设置变化
        observeSettingsChanges()
        
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        Log.d(TAG, "自动刷新服务销毁")
        stopAutoRefresh()
        settingsUpdateJob?.cancel()
        serviceScope.cancel()
        instance = null
        super.onDestroy()
    }

    /**
     * 创建通知渠道
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "自动刷新服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "用于保持自动刷新服务运行"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * 创建前台通知
     */
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("自动刷新中")
            .setContentText("正在自动刷新订单列表...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    /**
     * 更新通知显示
     */
    private fun updateNotification() {
        val delayDesc = if (currentRefreshDelay >= 1000) "${currentRefreshDelay / 1000}s" else "${currentRefreshDelay}ms"
        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("自动刷新中")
            .setContentText("已刷新 $refreshCount 次 | 间隔 ${currentRefreshInterval}秒 | 延迟 $delayDesc")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
        
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    /**
     * 加载当前设置
     */
    private fun loadCurrentSettings() {
        serviceScope.launch {
            try {
                val settings = settingsRepository.getSettings()
                currentRefreshInterval = settings.refreshIntervalSeconds
                currentRefreshDelay = settingsManager.getRefreshDelay()
                Log.d(TAG, "加载刷新设置：间隔=${currentRefreshInterval}秒，延迟=${currentRefreshDelay}ms")
                
                // 如果服务正在运行，重启刷新任务以应用新设置
                if (isRunning.get()) {
                    restartAutoRefresh()
                }
            } catch (e: Exception) {
                Log.e(TAG, "加载设置失败", e)
            }
        }
    }

    /**
     * 监听设置变化
     */
    private fun observeSettingsChanges() {
        settingsUpdateJob = serviceScope.launch {
            var lastInterval = currentRefreshInterval
            var lastDelay = currentRefreshDelay
            while (isActive) {
                delay(1000)
                try {
                    val settings = settingsRepository.getSettings()
                    var settingsChanged = false
                    
                    // 检查刷新间隔变化
                    if (settings.refreshIntervalSeconds != lastInterval) {
                        lastInterval = settings.refreshIntervalSeconds
                        currentRefreshInterval = lastInterval
                        Log.d(TAG, "检测到设置变化，刷新间隔更新为：${currentRefreshInterval}秒")
                        settingsChanged = true
                    }
                    
                    // 检查刷新延迟变化
                    val newDelay = settingsManager.getRefreshDelay()
                    if (newDelay != lastDelay) {
                        lastDelay = newDelay
                        currentRefreshDelay = newDelay
                        Log.d(TAG, "检测到设置变化，刷新延迟更新为：${currentRefreshDelay}ms")
                        settingsChanged = true
                    }
                    
                    if (settingsChanged) {
                        restartAutoRefresh()
                        updateNotification()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "检查设置变化失败", e)
                }
            }
        }
    }

    /**
     * 启动自动刷新
     */
    private fun startAutoRefresh() {
        if (isRunning.get()) {
            Log.w(TAG, "自动刷新已在运行")
            return
        }

        Log.d(TAG, "启动自动刷新，间隔：${currentRefreshInterval}秒，延迟：${currentRefreshDelay}ms")
        isRunning.set(true)
        
        refreshJob = serviceScope.launch {
            while (isRunning.get()) {
                try {
                    // 应用刷新延迟
                    val delayMs = currentRefreshDelay
                    Log.d(TAG, "等待刷新延迟：${delayMs}ms")
                    delay(delayMs.toLong())
                    
                    // 执行下拉刷新
                    performSwipeRefresh()
                    refreshCount++
                    
                    // 更新通知
                    updateNotification()
                    
                    Log.d(TAG, "第 $refreshCount 次刷新完成")
                    
                    // 等待设定的间隔（减去已消耗的延迟时间）
                    val waitTime = (currentRefreshInterval * 1000L - delayMs).coerceAtLeast(0)
                    if (waitTime > 0) {
                        delay(waitTime)
                    }
                    
                } catch (e: Exception) {
                    Log.e(TAG, "刷新执行异常", e)
                    delay(1000) // 异常后等待 1 秒再试
                }
            }
        }
    }

    /**
     * 重启自动刷新（用于设置变化时）
     */
    private fun restartAutoRefresh() {
        stopAutoRefresh()
        // 短暂延迟后重新启动
        serviceScope.launch {
            delay(500)
            startAutoRefresh()
        }
    }

    /**
     * 停止自动刷新
     */
    private fun stopAutoRefresh() {
        Log.d(TAG, "停止自动刷新")
        isRunning.set(false)
        refreshJob?.cancel()
        refreshJob = null
    }

    /**
     * 执行下拉刷新手势
     */
    private suspend fun performSwipeRefresh() {
        withContext(Dispatchers.Main) {
            try {
                // 获取屏幕尺寸
                val displayMetrics = resources.displayMetrics
                val screenWidth = displayMetrics.widthPixels
                val screenHeight = displayMetrics.heightPixels
                
                // 计算滑动路径：从屏幕下方 1/3 处滑到上方 1/3 处
                val startX = screenWidth / 2
                val startY = (screenHeight * 0.7).toInt()
                val endX = screenWidth / 2
                val endY = (screenHeight * 0.3).toInt()
                
                // 执行滑动手势
                gestureController.swipe(startX, startY, endX, endY, 300)
                
                Log.d(TAG, "执行下滑刷新：($startX, $startY) -> ($endX, $endY)")
                
            } catch (e: Exception) {
                Log.e(TAG, "执行滑动手势失败", e)
            }
        }
    }

    /**
     * 获取当前刷新次数
     */
    fun getRefreshCount(): Long {
        return refreshCount
    }

    /**
     * 重置刷新计数
     */
    fun resetRefreshCount() {
        refreshCount = 0
        updateNotification()
    }

    /**
     * 是否正在运行
     */
    fun isServiceRunning(): Boolean {
        return isRunning.get()
    }
}