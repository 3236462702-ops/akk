package com.autoaccessibility.assistant.log

import android.util.Log
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentLinkedDeque

/**
 * 订单处理日志管理器
 * 使用环形缓冲区存储最近的日志记录，支持实时推送给悬浮窗显示
 */
class OrderLogManager private constructor() {

    companion object {
        private const val TAG = "OrderLogManager"
        private const val MAX_LOG_SIZE = 100
        
        @Volatile
        private var instance: OrderLogManager? = null
        
        fun getInstance(): OrderLogManager {
            return instance ?: synchronized(this) {
                instance ?: OrderLogManager().also { instance = it }
            }
        }
    }

    // 环形缓冲区：使用双端队列实现
    private val logBuffer = ConcurrentLinkedDeque<OrderLogEntry>()
    
    // 日志监听器列表
    private val listeners = mutableListOf<OnLogUpdateListener>()
    
    // 日期格式化
    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    
    // 是否暂停自动滚动
    var isAutoScrollPaused = false

    /**
     * 添加日志条目
     */
    fun addLog(
        orderType: String,
        price: Double,
        pickupDistance: Double,
        tripDistance: Double,
        filterPassed: Boolean,
        filterReason: String?,
        grabResult: GrabResult,
        grabReason: String? = null
    ) {
        val entry = OrderLogEntry(
            timestamp = System.currentTimeMillis(),
            timeDisplay = dateFormat.format(Date()),
            orderType = orderType.ifEmpty { "未知" },
            price = price,
            pickupDistance = pickupDistance,
            tripDistance = tripDistance,
            filterPassed = filterPassed,
            filterReason = filterReason,
            grabResult = grabResult,
            grabReason = grabReason
        )
        
        // 添加到缓冲区
        logBuffer.addFirst(entry)
        
        // 保持缓冲区大小不超过限制
        while (logBuffer.size > MAX_LOG_SIZE) {
            logBuffer.removeLast()
        }
        
        Log.d(TAG, "添加日志：${entry.toShortString()}")
        
        // 通知监听器
        notifyListeners(entry)
    }

    /**
     * 添加简单日志（系统消息）
     */
    fun addSystemLog(message: String, type: LogType = LogType.INFO) {
        val entry = OrderLogEntry(
            timestamp = System.currentTimeMillis(),
            timeDisplay = dateFormat.format(Date()),
            orderType = "系统",
            price = 0.0,
            pickupDistance = 0.0,
            tripDistance = 0.0,
            filterPassed = true,
            filterReason = null,
            grabResult = when (type) {
                LogType.SUCCESS -> GrabResult.SUCCESS
                LogType.ERROR -> GrabResult.FAILED
                else -> GrabResult.NONE
            },
            grabReason = message
        )
        
        logBuffer.addFirst(entry)
        
        while (logBuffer.size > MAX_LOG_SIZE) {
            logBuffer.removeLast()
        }
        
        notifyListeners(entry)
    }

    /**
     * 获取所有日志（按时间倒序）
     */
    fun getAllLogs(): List<OrderLogEntry> {
        return logBuffer.toList()
    }

    /**
     * 获取最近 N 条日志
     */
    fun getRecentLogs(count: Int): List<OrderLogEntry> {
        return logBuffer.take(count)
    }

    /**
     * 清空所有日志
     */
    fun clearLogs() {
        logBuffer.clear()
        notifyCleared()
        Log.d(TAG, "日志已清空")
    }

    /**
     * 导出日志到文本
     */
    fun exportToText(): String {
        val sb = StringBuilder()
        sb.appendLine("=== 抢单助手 - 订单处理日志 ===")
        sb.appendLine("导出时间：${dateFormat.format(Date())}")
        sb.appendLine()
        
        logBuffer.reversed().forEach { entry ->
            sb.appendLine(entry.toFullString())
            sb.appendLine("---")
        }
        
        return sb.toString()
    }

    /**
     * 添加日志监听器
     */
    fun addLogListener(listener: OnLogUpdateListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    /**
     * 移除日志监听器
     */
    fun removeLogListener(listener: OnLogUpdateListener) {
        listeners.remove(listener)
    }

    /**
     * 通知监听器新日志
     */
    private fun notifyListeners(entry: OrderLogEntry) {
        listeners.forEach { listener ->
            try {
                listener.onNewLog(entry)
            } catch (e: Exception) {
                Log.e(TAG, "通知监听器异常", e)
            }
        }
    }

    /**
     * 通知监听器日志已清空
     */
    private fun notifyCleared() {
        listeners.forEach { listener ->
            try {
                listener.onLogsCleared()
            } catch (e: Exception) {
                Log.e(TAG, "通知监听器异常", e)
            }
        }
    }

    /**
     * 日志监听器接口
     */
    interface OnLogUpdateListener {
        fun onNewLog(entry: OrderLogEntry)
        fun onLogsCleared()
    }

    /**
     * 日志类型枚举
     */
    enum class LogType {
        INFO,       // 普通信息
        SUCCESS,    // 成功
        WARNING,    // 警告
        ERROR       // 错误
    }
}

/**
 * 抢单结果枚举
 */
enum class GrabResult {
    SUCCESS,        // 抢单成功
    FAILED,         // 抢单失败
    SKIPPED,        // 跳过（未抢）
    NONE            // 无操作（系统日志）
}

/**
 * 订单日志条目
 */
data class OrderLogEntry(
    val timestamp: Long,                  // 时间戳
    val timeDisplay: String,              // 格式化时间显示
    val orderType: String,                // 订单类型
    val price: Double,                    // 价格
    val pickupDistance: Double,           // 接驾距离
    val tripDistance: Double,             // 行程距离
    val filterPassed: Boolean,            // 过滤是否通过
    val filterReason: String?,            // 过滤原因
    val grabResult: GrabResult,           // 抢单结果
    val grabReason: String?               // 抢单原因/失败原因
) {
    /**
     * 获取过滤状态显示文本
     */
    fun getFilterStatusText(): String {
        return if (filterPassed) {
            "✓ 符合"
        } else {
            "✗ 不符合"
        }
    }

    /**
     * 获取抢单结果显式文本
     */
    fun getGrabResultText(): String {
        return when (grabResult) {
            GrabResult.SUCCESS -> "✓ 抢单成功"
            GrabResult.FAILED -> "✗ 抢单失败"
            GrabResult.SKIPPED -> "✗ 未抢"
            GrabResult.NONE -> ""
        }
    }

    /**
     * 获取简短描述（用于列表显示）
     */
    fun toShortString(): String {
        return "$timeDisplay [$orderType] ¥$price ${getFilterStatusText()} ${getGrabResultText()}"
    }

    /**
     * 获取完整描述（用于详情显示）
     */
    fun toFullString(): String {
        return buildString {
            appendLine("时间：$timeDisplay")
            appendLine("类型：$orderType")
            appendLine("价格：¥$price")
            appendLine("接驾：${pickupDistance}km")
            appendLine("行程：${tripDistance}km")
            appendLine("过滤：${getFilterStatusText()}${if (filterReason != null) " ($filterReason)" else ""}")
            appendLine("抢单：${getGrabResultText()}${if (grabReason != null) " ($grabReason)" else ""}")
        }
    }
}