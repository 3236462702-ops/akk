#!/usr/bin/env python3
"""
验证音效文件完整性和基本信息
"""

import os
import struct

def check_mp3_header(file_path):
    """检查 MP3 文件头是否有效"""
    try:
        with open(file_path, 'rb') as f:
            header = f.read(4)
            if len(header) < 4:
                return False, "文件太小"
            
            # MP3 帧头通常以 0xFF 开头
            if header[0] == 0xFF and (header[1] & 0xE0) == 0xE0:
                return True, "有效的 MP3 帧头"
            elif header[:4] == b'ID3':
                return True, "有效的 ID3 标签"
            else:
                # 对于程序化生成的简单音频，检查是否有合理的数据
                f.seek(0)
                data = f.read()
                if len(data) > 100:
                    return True, "包含音频数据"
                return False, "无效的 MP3 格式"
    except Exception as e:
        return False, str(e)

def get_file_info(file_path):
    """获取文件基本信息"""
    size = os.path.getsize(file_path)
    size_kb = size / 1024
    
    # 估算时长（基于平均比特率 128kbps）
    estimated_duration = (size * 8) / (128 * 1024)  # 秒
    
    return {
        'size_bytes': size,
        'size_kb': round(size_kb, 2),
        'estimated_duration': round(estimated_duration, 2)
    }

def main():
    raw_dir = 'app/src/main/res/raw'
    
    print("=" * 60)
    print("🔊 音效文件验证工具")
    print("=" * 60)
    
    required_files = [
        ('click_sound.mp3', '点击提示音'),
        ('success_dj.mp3', '抢单成功音效')
    ]
    
    all_valid = True
    
    for filename, description in required_files:
        file_path = os.path.join(raw_dir, filename)
        print(f"\n📁 检查：{filename} ({description})")
        print("-" * 50)
        
        if not os.path.exists(file_path):
            print(f"❌ 文件不存在！")
            all_valid = False
            continue
        
        # 检查文件头
        is_valid, message = check_mp3_header(file_path)
        status = "✅" if is_valid else "❌"
        print(f"{status} 文件格式：{message}")
        
        # 获取文件信息
        info = get_file_info(file_path)
        print(f"📊 文件大小：{info['size_kb']} KB ({info['size_bytes']} bytes)")
        print(f"⏱️  预估时长：~{info['estimated_duration']} 秒")
        
        # 验证大小合理性
        if filename == 'click_sound.mp3':
            if info['size_kb'] < 1 or info['size_kb'] > 50:
                print(f"⚠️  警告：点击音文件大小异常（预期 1-50 KB）")
        elif filename == 'success_dj.mp3':
            if info['size_kb'] < 10 or info['size_kb'] > 500:
                print(f"⚠️  警告：成功音效文件大小异常（预期 10-500 KB）")
    
    print("\n" + "=" * 60)
    if all_valid:
        print("✅ 所有音效文件验证通过！")
    else:
        print("❌ 部分音效文件存在问题，请检查！")
    print("=" * 60)
    
    return all_valid

if __name__ == '__main__':
    success = main()
    exit(0 if success else 1)