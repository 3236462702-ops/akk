#!/usr/bin/env python3
"""
生成 Android 应用图标的不同分辨率版本
"""
from PIL import Image, ImageDraw
import os

# 定义各分辨率尺寸 (Android 标准)
RESOLUTIONS = {
    'mdpi': 48,
    'hdpi': 72,
    'xhdpi': 96,
    'xxhdpi': 144,
    'xxxhdpi': 192
}

# 源文件路径
SOURCE_ICON = 'app/src/main/res/mipmap-xxxhdpi/ic_launcher.png'

def create_rounded_icon(icon_path, output_path):
    """创建圆形图标版本"""
    img = Image.open(icon_path)
    img = img.convert("RGBA")
    
    # 创建圆形蒙版
    mask = Image.new('L', img.size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse([0, 0, img.size[0], img.size[1]], fill=255)
    
    # 应用蒙版
    rounded = img.copy()
    rounded.putalpha(mask)
    rounded.save(output_path, 'PNG')
    print(f"✓ 已生成圆形图标：{output_path}")

def resize_icon(source_path, size, output_path):
    """缩放图标到指定尺寸"""
    img = Image.open(source_path)
    img = img.resize((size, size), Image.Resampling.LANCZOS)
    img.save(output_path, 'PNG')
    print(f"✓ 已生成 {size}x{size} 图标：{output_path}")

def main():
    if not os.path.exists(SOURCE_ICON):
        print(f"错误：源图标文件不存在：{SOURCE_ICON}")
        return
    
    print("开始生成 Android 应用图标...")
    print(f"源文件：{SOURCE_ICON}")
    print()
    
    # 为每个分辨率生成图标
    for density, size in RESOLUTIONS.items():
        dir_path = f'app/src/main/res/mipmap-{density}'
        os.makedirs(dir_path, exist_ok=True)
        
        # 生成普通图标
        output_path = f'{dir_path}/ic_launcher.png'
        resize_icon(SOURCE_ICON, size, output_path)
        
        # 生成圆形图标
        round_path = f'{dir_path}/ic_launcher_round.png'
        create_rounded_icon(output_path, round_path)
    
    print()
    print("✅ 所有图标生成完成！")

if __name__ == '__main__':
    main()