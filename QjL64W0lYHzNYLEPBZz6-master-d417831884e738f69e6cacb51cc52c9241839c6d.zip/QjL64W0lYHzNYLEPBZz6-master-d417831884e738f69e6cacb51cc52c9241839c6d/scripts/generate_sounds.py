#!/usr/bin/env python3
"""
生成 Android 抢单助手音效文件
使用程序化方式生成电子提示音
"""

import wave
import struct
import math
import os

def generate_tone(frequency, duration, sample_rate=44100, amplitude=32767):
    """生成指定频率和时长的正弦波"""
    num_samples = int(sample_rate * duration)
    samples = []
    
    for i in range(num_samples):
        value = amplitude * math.sin(2.0 * math.pi * frequency * (i / sample_rate))
        samples.append(int(value))
    
    return samples

def generate_beep_sequence(frequencies, durations, gaps, sample_rate=44100):
    """生成蜂鸣序列"""
    all_samples = []
    
    for i, (freq, dur) in enumerate(zip(frequencies, durations)):
        # 添加音调
        samples = generate_tone(freq, dur, sample_rate)
        all_samples.extend(samples)
        
        # 添加间隔（静音）
        if i < len(gaps):
            gap_samples = [0] * int(sample_rate * gaps[i])
            all_samples.extend(gap_samples)
    
    return all_samples

def save_wav(filename, samples, sample_rate=44100):
    """保存为 WAV 文件"""
    with wave.open(filename, 'w') as wav_file:
        wav_file.setnchannels(1)  # 单声道
        wav_file.setsampwidth(2)  # 16 位
        wav_file.setframerate(sample_rate)
        
        for sample in samples:
            # 限制在 16 位范围内
            sample = max(-32768, min(32767, sample))
            wav_file.writeframes(struct.pack('<h', sample))

def wav_to_mp3(wav_path, mp3_path):
    """简单的 WAV 到 MP3 转换（实际上只是重命名，Android 也支持 WAV）"""
    # Android 原生支持 WAV，所以我们可以直接使用 WAV 文件
    # 这里我们创建 MP3 路径的符号链接或复制文件
    try:
        import shutil
        shutil.copy(wav_path, mp3_path)
        return True
    except Exception as e:
        print(f"复制失败：{e}")
        return False

def main():
    # 确保目录存在
    raw_dir = 'app/src/main/res/raw'
    os.makedirs(raw_dir, exist_ok=True)
    
    print("正在生成音效文件...")
    
    # 1. 生成点击音效（短促的高频音）
    print("生成 click_sound.mp3...")
    click_samples = generate_beep_sequence(
        frequencies=[800],
        durations=[0.05],
        gaps=[],
        sample_rate=44100
    )
    save_wav(f'{raw_dir}/click_sound.wav', click_samples)
    wav_to_mp3(f'{raw_dir}/click_sound.wav', f'{raw_dir}/click_sound.mp3')
    
    # 2. 生成抢单成功音效（欢快的上升音调序列）
    print("生成 success_dj.mp3...")
    success_samples = generate_beep_sequence(
        frequencies=[523, 659, 784, 1047],  # C5, E5, G5, C6 (C 大调和弦)
        durations=[0.1, 0.1, 0.15, 0.3],
        gaps=[0.02, 0.02, 0.05],
        sample_rate=44100
    )
    save_wav(f'{raw_dir}/success_dj.wav', success_samples)
    wav_to_mp3(f'{raw_dir}/success_dj.wav', f'{raw_dir}/success_dj.mp3')
    
    # 清理临时 WAV 文件
    try:
        os.remove(f'{raw_dir}/click_sound.wav')
        os.remove(f'{raw_dir}/success_dj.wav')
    except:
        pass
    
    print("✓ 音效文件生成完成！")
    print(f"  - {raw_dir}/click_sound.mp3 (点击音效)")
    print(f"  - {raw_dir}/success_dj.mp3 (抢单成功音效)")

if __name__ == '__main__':
    main()