#!/usr/bin/env python3
"""生成缺失的 drawable 资源文件"""

import os

# Drawable 目录
drawable_dir = "app/src/main/res/drawable"

# 确保目录存在
os.makedirs(drawable_dir, exist_ok=True)

# 定义需要生成的 drawable 资源
drawables = {
    "ic_empty_task.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#9E9E9E"
        android:pathData="M19,5v14H5V5H19 M19,3H5C3.9,3,3,3.9,3,5v14c0,1.1,0.9,2,2,2h14c1.1,0,2-0.9,2-2V5C21,3.9,20.1,3,19,3L19,3z"/>
</vector>
""",
    "ic_add.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,13h-6v6h-2v-6H5v-2h6V5h2v6h6V13z"/>
</vector>
""",
    "ic_back.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M20,11H7.83l5.59,-5.59L12,4l-8,8l8,8l1.41,-1.41L7.83,13H20V11z"/>
</vector>
""",
    "bg_spinner.xml": """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF"/>
    <stroke android:width="1dp" android:color="#DDDDDD"/>
    <corners android:radius="8dp"/>
</shape>
""",
    "bg_status_indicator.xml": """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#4CAF50"/>
    <size android:width="12dp" android:height="12dp"/>
</shape>
""",
    "bg_control_button.xml": """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#2196F3"/>
    <corners android:radius="8dp"/>
</shape>
""",
    "ic_ride_type.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#666666"
        android:pathData="M18.92,6.01C18.72,5.42,18.16,5,17.5,5h-11C5.84,5,5.28,5.42,5.08,6.01L3,12l2.08,6L5.08,18l11,0l-0.08,-0.01c0.66,0,1.22,-0.42,1.42,-1.01L21,12L18.92,6.01zM6.5,16c-0.83,0,-1.5,-0.67,-1.5,-1.5S5.67,13,6.5,13s1.5,0.67,1.5,1.5S7.33,16,6.5,16zM17.5,16c-0.83,0,-1.5,-0.67,-1.5,-1.5s0.67,-1.5,1.5,-1.5s1.5,0.67,1.5,1.5S18.33,16,17.5,16z"/>
</vector>
""",
    "bg_step_number.xml": """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#2196F3"/>
    <size android:width="32dp" android:height="32dp"/>
</shape>
""",
    "ic_drag_handle.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#9E9E9E"
        android:pathData="M3,15h2v-2H3V15zM3,19h2v-2H3V19zM3,11h2V9H3V11zM3,7h2V5H3V7zM3,23h2v-2H3V23zM7,15h14v-2H7V15zM7,19h14v-2H7V19zM7,11h14V9H7V11zM7,7h14V5H7V7zM7,23h14v-2H7V23z"/>
</vector>
""",
    "ic_task.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#2196F3"
        android:pathData="M14,2H6C4.9,2,4,2.9,4,4v16c0,1.1,0.9,2,2,2h12c1.1,0,2,-0.9,2,-2V8L14,2zM16,18H8v-2h8V18zM16,14H8v-2h8V14zM13,9V3.5L18.5,9H13z"/>
</vector>
""",
    "bg_icon_circle.xml": """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="oval">
    <solid android:color="#E3F2FD"/>
    <size android:width="48dp" android:height="48dp"/>
</shape>
""",
    "ic_delete.xml": """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#F44336"
        android:pathData="M6,19c0,1.1,0.9,2,2,2h8c1.1,0,2,-0.9,2,-2V7H6V19zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z"/>
</vector>
"""
}

# 写入文件
for filename, content in drawables.items():
    filepath = os.path.join(drawable_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✓ 已生成：{filepath}")

print("\n✅ 所有缺失的 drawable 资源生成完成！")