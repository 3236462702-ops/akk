# APK 打包指南

## 📦 项目信息

- **应用名称**: Auto Accessibility Assistant
- **包名**: com.autoaccessibility.assistant
- **目标 SDK**: Android 14 (API 34)
- **最低 SDK**: Android 8.0 (API 26)
- **构建工具**: Gradle 8.2 / Kotlin 1.9.20

## 🔧 环境要求

### 必需环境
1. **JDK 17** - Java Development Kit 17 或更高版本
2. **Android SDK** - 需要安装以下组件：
   - Android SDK Platform 34
   - Build-Tools 34.0.0
   - Android SDK Command-line Tools
3. **Gradle 8.2** - 或使用项目自带的 Gradle Wrapper

### 环境变量配置
```bash
# 设置 JAVA_HOME
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64

# 设置 ANDROID_HOME
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

## 📝 打包步骤

### 方法一：使用 Gradle Wrapper（推荐）

```bash
# 1. 确保 gradlew 有执行权限
chmod +x gradlew

# 2. 清理之前的构建
./gradlew clean

# 3. 构建 Release APK
./gradlew assembleRelease

# 4. 构建 Debug APK（用于测试）
./gradlew assembleDebug
```

### 方法二：使用系统 Gradle

```bash
# 1. 检查 Gradle 版本
gradle --version

# 2. 清理并构建
gradle clean assembleRelease --no-daemon
```

### 方法三：使用构建脚本

```bash
# 运行提供的构建脚本
./build_apk.sh
```

## 📍 APK 输出位置

构建成功后，APK 文件位于：

```
# Release 版本（推荐发布）
app/build/outputs/apk/release/app-release.apk

# Debug 版本（仅用于测试）
app/build/outputs/apk/debug/app-debug.apk
```

## 🔐 签名配置（可选）

如果需要为 APK 添加正式签名，请在 `app/build.gradle.kts` 中添加：

```kotlin
android {
    ...
    signingConfigs {
        create("release") {
            storeFile = file("your-keystore.jks")
            storePassword = "your-store-password"
            keyAlias = "your-key-alias"
            keyPassword = "your-key-password"
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            ...
        }
    }
}
```

## ⚠️ 常见问题

### 1. Gradle 版本不匹配
**错误**: `This version of Gradle requires...`
**解决**: 使用 Gradle Wrapper 或升级系统 Gradle 到 8.2+

### 2. Android SDK 未找到
**错误**: `SDK location not found`
**解决**: 
- 创建 `local.properties` 文件
- 添加内容：`sdk.dir=/path/to/your/Android/Sdk`

### 3. JDK 版本过低
**错误**: `Unsupported class file major version`
**解决**: 确保使用 JDK 17 或更高版本

### 4. 内存不足
**错误**: `OutOfMemoryError`
**解决**: 在 `gradle.properties` 中增加：
```properties
org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m
```

## 📱 安装测试

```bash
# 连接设备后安装
adb install app/build/outputs/apk/release/app-release.apk

# 如果已有旧版本，先卸载
adb uninstall com.autoaccessibility.assistant
adb install app/build/outputs/apk/release/app-release.apk
```

## 🎯 构建优化建议

### ProGuard 混淆
Release 版本已启用 ProGuard 混淆和代码压缩：
- 配置文件：`app/proguard-rules.pro`
- 如需保留特定类，请在配置文件中添加规则

### 多架构支持
当前配置支持所有主流架构：
- armeabi-v7a
- arm64-v8a
- x86
- x86_64

如需减小 APK 体积，可考虑分架构打包。

## 📊 构建统计

查看构建报告：
```bash
./gradlew assembleRelease --profile
```

报告会生成在：`build/reports/profile/profile-*.html`

---

**最后更新**: 2026-05-30
**项目版本**: 1.0 (versionCode: 1)