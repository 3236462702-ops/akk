# 音效资源使用指南

本文档说明智能抢单助手的音效资源管理、生成方式和使用规范。

---

## 📁 音效文件位置

所有音效文件存放在 `app/src/main/res/raw/` 目录：

```
app/src/main/res/raw/
├── click_sound.mp3      # 全局点击提示音（短促"叮"声）
└── success_dj.mp3       # 抢单成功提示音（DJ 风格）
```

---

## 🔊 音效规格说明

### 1. click_sound.mp3（点击提示音）

- **用途**：应用内任意位置点击时播放的短提示音
- **时长**：< 1 秒
- **风格**：清脆、短促、不干扰操作
- **音量**：中等偏低，避免频繁点击造成噪音
- **生成方式**：程序化生成电子音效（正弦波 + 衰减）
- **文件大小**：约 4-5 KB

### 2. success_dj.mp3（抢单成功提示音）

- **用途**：抢单成功时播放的庆祝音效
- **时长**：2-3 秒
- **风格**：激烈、节奏感强、有冲击力
- **音量**：较高，确保用户能清晰感知
- **生成方式**：程序化生成多音调电子音乐（和弦 + 节奏）
- **文件大小**：约 60-70 KB

---

## 🛠️ 音效生成工具

项目包含音效生成脚本 `scripts/generate_sounds.py`，可重新生成或自定义音效。

### 使用方法

```bash
# 激活虚拟环境
source venv/bin/activate

# 运行生成脚本
python3 scripts/generate_sounds.py
```

### 自定义音效参数

编辑 `scripts/generate_sounds.py` 中的以下参数：

```python
# 点击音效配置
click_config = {
    'frequency': 880,        # 主频率 (Hz)，越高越尖锐
    'duration': 0.15,        # 时长 (秒)
    'decay': 0.05,           # 衰减时间 (秒)
    'sample_rate': 44100     # 采样率
}

# 成功音效配置
success_config = {
    'frequencies': [523, 659, 784, 1047],  # 和弦频率 (C 大调)
    'duration': 2.5,         # 总时长 (秒)
    'tempo': 120,            # 节奏 (BPM)
    'sample_rate': 44100
}
```

---

## 🎵 音效管理器集成

音效通过 `SoundManager.kt` 统一管理，支持以下功能：

### API 调用示例

```kotlin
// 获取单例
val soundManager = SoundManager.getInstance(context)

// 播放点击音
soundManager.playClickSound()

// 播放成功音
soundManager.playSuccessSound()

// 播放错误音
soundManager.playErrorSound()

// 更新设置
soundManager.updateSettings(
    enabled = true,              // 总开关
    clickEnabled = true,         // 点击音开关
    successEnabled = true,       // 成功音开关
    volumeLevel = 80             // 音量 0-100
)
```

### 特性

- ✅ **预加载机制**：应用启动时预加载音效，播放延迟 < 50ms
- ✅ **防抖处理**：300ms 内重复点击只播放一次
- ✅ **音量控制**：支持 0-100% 独立音量调节
- ✅ **开关控制**：用户可单独关闭点击音或成功音
- ✅ **音频焦点**：自动请求音频焦点，避免与其他应用冲突
- ✅ **内存管理**：页面销毁时自动释放资源

---

## ⚙️ 用户设置

在设置界面 (`SettingsActivity`) 中提供音效配置：

| 设置项 | 说明 | 默认值 |
|--------|------|--------|
| 启用音效 | 总开关，关闭后所有音效静音 | 开启 |
| 点击音效 | 控制点击提示音播放 | 开启 |
| 成功提示音 | 控制抢单成功音效播放 | 开启 |
| 音效音量 | 滑块调节 0-100% | 80% |

设置实时保存到数据库，`SoundManager` 自动读取最新配置。

---

## 🔧 故障排查

### 问题：音效不播放

**检查清单：**

1. 确认音效文件存在：`ls app/src/main/res/raw/*.mp3`
2. 检查 `SoundManager` 是否正确初始化
3. 确认设置中音效开关已开启
4. 检查设备媒体音量是否打开
5. 查看 Logcat 日志：`adb logcat | grep SoundManager`

### 问题：音效播放延迟

**解决方案：**

- 确认音效已预加载（检查 `loadAllSounds()` 执行）
- 避免使用 MediaPlayer，改用 SoundPool（延迟更低）
- 检查是否有其他应用占用音频焦点

### 问题：音效文件过大

**优化建议：**

- 降低采样率（44100 → 22050 Hz）
- 缩短时长（特别是成功音效）
- 使用单声道而非立体声
- 调整比特率（128kbps → 64kbps）

---

## 📝 扩展自定义音效

如需添加更多音效类型：

### 1. 生成音频文件

使用 `generate_sounds.py` 脚本或从外部导入 MP3/WAV 文件。

### 2. 放入 raw 目录

```bash
cp custom_sound.mp3 app/src/main/res/raw/
```

### 3. 更新 AudioConfig

```kotlin
enum class SoundType {
    CLICK_SHORT,
    SUCCESS_DJ,
    ERROR,
    CUSTOM_SOUND  // 新增
}
```

### 4. 在 SoundManager 中加载

```kotlin
val customId = soundPool.load(context, R.raw.custom_sound, 1)
soundIdMap[AudioConfig.SoundType.CUSTOM_SOUND] = customId
```

### 5. 添加播放方法

```kotlin
fun playCustomSound() {
    if (!soundEnabled) return
    playSound(AudioConfig.SoundType.CUSTOM_SOUND)
}
```

---

## 📄 许可说明

本项目音效资源采用以下方式生成：

- **程序化生成**：使用 Python 脚本合成电子音效，无版权限制
- **开源音效库**：如使用外部资源，确保符合 CC0 或 MIT 许可

商业使用请自行验证音效版权合规性。

---

## 🔄 版本历史

| 版本 | 日期 | 变更说明 |
|------|------|----------|
| 1.0 | 2026-05-30 | 初始版本，包含点击音和成功音 |

---

**最后更新：** 2026 年 5 月 30 日  
**维护者：** 智能抢单助手开发团队