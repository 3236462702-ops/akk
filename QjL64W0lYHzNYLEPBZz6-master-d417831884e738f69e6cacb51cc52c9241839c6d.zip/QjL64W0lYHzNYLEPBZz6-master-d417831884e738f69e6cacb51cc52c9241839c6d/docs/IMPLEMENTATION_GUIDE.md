# 智能屏幕自动化助手 - 技术实现指南

## 📋 目录

1. [系统架构](#系统架构)
2. [核心模块详解](#核心模块详解)
3. [API 集成](#api 集成)
4. [使用示例](#使用示例)
5. [常见问题](#常见问题)

---

## 系统架构

```
┌─────────────────────────────────────────────────────────┐
│                    应用层 (UI Layer)                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │ MainActivity│  │ScriptEditor │  │ Settings    │      │
│  └─────────────┘  └─────────────┘  └─────────────┘      │
└─────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────┐
│                   引擎层 (Engine Layer)                   │
│  ┌─────────────────────────────────────────────────┐    │
│  │              TaskEngine                          │    │
│  │  • 任务调度  • 步骤执行  • 状态管理  • 循环控制  │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────┐
│                  控制器层 (Controller Layer)              │
│  ┌─────────────────────────────────────────────────┐    │
│  │            GestureController                     │    │
│  │  • 点击  • 滑动  • 长按  • 文本输入  • 全局操作  │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────┐
│                  服务层 (Service Layer)                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │AutoAccessi-  │  │ScreenCapture │  │ OcrService   │  │
│  │bilityService │  │  Manager     │  │              │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│  ┌──────────────┐                                        │
│  │AiDecision    │                                        │
│  │Service       │                                        │
│  └──────────────┘                                        │
└─────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────┐
│                  数据层 (Data Layer)                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │Room Database│  │ AppConfig   │  │ TaskScript  │      │
│  └─────────────┘  └─────────────┘  └─────────────┘      │
└─────────────────────────────────────────────────────────┘
```

---

## 核心模块详解

### 1. 屏幕捕获模块 (ScreenCaptureManager)

**位置**: `app/src/main/java/com/autoaccessibility/assistant/capture/ScreenCaptureManager.kt`

**功能**:
- 使用 MediaProjection API 捕获屏幕截图
- 将 Bitmap 转换为 Base64 编码供 API 使用
- 管理录屏权限请求

**关键代码**:
```kotlin
// 请求录屏权限
val mediaProjectionManager = context.getSystemService(
    Context.MEDIA_PROJECTION_SERVICE
) as MediaProjectionManager

val intent = mediaProjectionManager.createScreenCaptureIntent()
startActivityForResult(intent, REQUEST_CODE_SCREEN_CAPTURE)

// 捕获屏幕
fun captureScreenSync(): Bitmap? {
    val virtualDisplay = mediaProjection?.createVirtualDisplay(
        "ScreenCapture",
        width, height, dpi,
        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
        imageReader.surface, null, null
    )
    
    // 等待帧可用
    Thread.sleep(500)
    return imageReader.acquireLatestImage()?.toBitmap()
}
```

### 2. OCR 识别模块 (OcrService)

**位置**: `app/src/main/java/com/autoaccessibility/assistant/ocr/OcrService.kt`

**功能**:
- 调用 CSDN OCR API 识别屏幕文字
- 解析返回结果，提取结构化信息
- 支持错误重试和超时处理

**API 调用示例**:
```kotlin
suspend fun recognizeFromBitmap(bitmap: Bitmap): OcrResult {
    val base64Image = bitmapToBase64(bitmap)
    
    val requestBody = MultipartBody.Builder()
        .setType(MultipartBody.FORM)
        .addFormDataPart("model", "default_ocr")
        .addFormDataPart("image", "screen.png", 
            base64Image.toRequestBody())
        .build()
    
    val response = apiService.recognizeImage(
        ApiClient.getAuthHeader(),
        requestBody
    )
    
    return OcrResult(
        isSuccess = true,
        text = response.data,
        rawResponse = response
    )
}
```

### 3. AI 决策模块 (AiDecisionService)

**位置**: `app/src/main/java/com/autoaccessibility/assistant/ai/AiDecisionService.kt`

**功能**:
- 调用 qwen-vl-plus 多模态模型
- 发送屏幕截图 + 决策指令
- 解析 AI 返回的操作建议

**Prompt 模板**:
```kotlin
object PromptTemplates {
    const val FIND_HIGHEST_PRICE = """
    分析这张商品列表截图，找出价格最高的商品。
    
    请返回 JSON 格式：
    {
        "action": "CLICK",
        "x": 横坐标,
        "y": 纵坐标,
        "reason": "选择理由"
    }
    """
    
    const val FIND_BUTTON = """
    在截图中找到"[按钮文字]"按钮的位置。
    返回点击坐标和确认信息。
    """
}
```

### 4. 手势控制器 (GestureController)

**位置**: `app/src/main/java/com/autoaccessibility/assistant/controller/GestureController.kt`

**支持的操作类型**:
| 操作类型 | 方法 | 说明 |
|---------|------|------|
| 点击 | `click(x, y)` | 点击指定坐标 |
| 长按 | `longPress(x, y, duration)` | 长按指定时长 |
| 滑动 | `swipe(startX, startY, endX, endY)` | 从一个位置滑到另一个位置 |
| 文本输入 | `inputText(text)` | 向输入框输入文字 |
| 返回 | `goBack()` | 执行返回操作 |
| 主页 | `goToHome()` | 返回桌面 |

### 5. 任务引擎 (TaskEngine)

**位置**: `app/src/main/java/com/autoaccessibility/assistant/engine/TaskEngine.kt`

**支持的步骤类型**:
```kotlin
enum class ActionType {
    CLICK,          // 点击
    LONG_PRESS,     // 长按
    SWIPE,          // 滑动
    INPUT_TEXT,     // 输入文字
    PRESS_BACK,     // 返回
    PRESS_HOME,     // 主页
    WAIT,           // 等待
    CONDITION,      // 条件判断
    SCREEN_CAPTURE, // 屏幕捕获
    OCR_ANALYZE,    // OCR 识别
    AI_DECIDE,      // AI 决策
    LOOP_START,     // 循环开始
    LOOP_END        // 循环结束
}
```

---

## API 集成

### CSDN OCR API

**接口地址**: `POST https://models.csdn.net/v1/images/ocr`

**请求头**:
```
Authorization: Bearer sk-kpoorxpbmlrrkptl
Content-Type: multipart/form-data
```

**请求参数**:
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| image | File | 二选一 | 图片文件 |
| url | String | 二选一 | 图片 URL |
| model | String | 是 | 模型名称 (default_ocr) |

**响应示例**:
```json
{
  "request_id": "37b382ea-4b5c-4877-9549-88df0ed4d71e",
  "created": 1735031779,
  "data": "识别出的文字内容",
  "usage": {
    "ocr_count": 1
  }
}
```

### CSDN AI 对话 API

**接口地址**: `POST https://models.csdn.net/v1/chat/completions`

**请求头**:
```
Authorization: Bearer sk-kpoorxpbmlrrkptl
Content-Type: application/json
```

**请求体示例**:
```json
{
  "model": "qwen-vl-plus",
  "stream": false,
  "messages": [
    {
      "role": "user",
      "content": [
        {
          "type": "text",
          "text": "找出价格最高的商品"
        },
        {
          "type": "image_url",
          "image_url": {
            "url": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ..."
          }
        }
      ]
    }
  ]
}
```

---

## 使用示例

### 示例 1: 智能比价购物

```kotlin
// 创建智能购物任务
val shoppingTask = SmartShoppingTask.createPriceComparisonTask(
    productName = "iPhone 15 Pro",
    targetAction = "选择价格最高的选项"
)

// 执行任务
TaskEngine.getInstance().executeTask(shoppingTask)

// 监听执行进度
TaskEngine.getInstance().onTaskProgress = { script, current, total ->
    Log.d("Task", "进度：$current/$total")
}

// 监听完成
TaskEngine.getInstance().onTaskCompleted = { script, success, error ->
    if (success) {
        Log.d("Task", "任务完成!")
    } else {
        Log.e("Task", "任务失败：$error")
    }
}
```

### 示例 2: 自定义脚本

```kotlin
val taskScript = TaskScript(
    name = "自动抢票",
    steps = listOf(
        TaskStep(
            actionType = ActionType.WAIT,
            description = "等待开售",
            duration = 30000
        ),
        TaskStep(
            actionType = ActionType.SCREEN_CAPTURE,
            description = "捕获屏幕"
        ),
        TaskStep(
            actionType = ActionType.AI_DECIDE,
            description = "选择可购买的座位",
            text = "找出可购买的最便宜座位并点击"
        ),
        TaskStep(
            actionType = ActionType.CLICK,
            description = "确认购买",
            targetText = "立即支付"
        )
    )
)
```

### 示例 3: 循环操作

```kotlin
val scrollTask = TaskScript(
    name = "滚动采集数据",
    steps = listOf(
        TaskStep(
            actionType = ActionType.LOOP_START,
            description = "循环滚动",
            loopCount = 10
        ),
        TaskStep(
            actionType = ActionType.SWIPE,
            description = "向上滑动",
            x = 540, y = 1600,
            endX = 540, endY = 800
        ),
        TaskStep(
            actionType = ActionType.WAIT,
            description = "等待加载",
            duration = 2000
        ),
        TaskStep(
            actionType = ActionType.LOOP_END,
            description = "循环结束"
        )
    )
)
```

---

## 常见问题

### Q1: 录屏权限如何申请？

```kotlin
// 在 Activity 中请求
private val screenCaptureLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
) { result ->
    if (result.resultCode == RESULT_OK) {
        val data = result.data ?: return@registerForActivityResult
        ScreenCaptureManager.getInstance().init(data)
    }
}

// 启动请求
val manager = context.getSystemService(
    Context.MEDIA_PROJECTION_SERVICE
) as MediaProjectionManager
screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
```

### Q2: OCR 识别失败如何处理？

```kotlin
try {
    val result = ocrService.recognizeFromBitmap(bitmap)
    if (!result.isSuccess) {
        // 重试逻辑
        retryCount++
        if (retryCount < MAX_RETRY) {
            Thread.sleep(RETRY_DELAY)
            recognizeFromBitmap(bitmap)
        }
    }
} catch (e: Exception) {
    Log.e(TAG, "OCR 识别异常", e)
}
```

### Q3: AI 决策结果如何解析？

```kotlin
// AI 返回的 Markdown 格式响应
val aiResponse = """
```json
{
    "action": "CLICK",
    "x": 540,
    "y": 820,
    "reason": "iPhone 15 Pro 价格最高"
}
```
""".trimIndent()

// 提取 JSON 部分
val jsonMatch = Regex("```json\\s*(.+?)\\s*```", RegexOption.DOT_MATCHES_ALL)
    .find(aiResponse)
val jsonStr = jsonMatch?.groupValues?.get(1) ?: throw ParseException()

// 解析为对象
val decision = gson.fromJson(jsonStr, DecisionResult::class.java)
```

### Q4: 如何调试任务执行？

```kotlin
// 启用调试模式
AppConfig.getInstance(context).isDebugMode = true

// 查看实时日志
Log.d("TaskEngine", "当前步骤：${step.description}")
Log.d("GestureController", "执行点击：($x, $y)")
Log.d("OcrService", "识别结果：${result.text}")

// 获取当前屏幕元素
val elements = AutoAccessibilityService.getInstance()?.currentElements
elements?.forEach { element ->
    Log.d("Elements", element.toActionDescription())
}
```

---

## 性能优化建议

1. **屏幕捕获优化**
   - 降低截图分辨率（如 720p 而非 1080p）
   - 使用 JPEG 压缩（质量 80%）
   - 避免频繁捕获（间隔至少 500ms）

2. **网络请求优化**
   - 使用连接池（OkHttp 默认已优化）
   - 添加请求超时（10 秒）
   - 实现指数退避重试

3. **内存管理**
   - 及时回收 Bitmap (`recycle()`)
   - 使用 WeakReference 持有 Context
   - 避免在循环中创建大对象

4. **电池优化**
   - 任务完成后释放 MediaProjection
   - 减少不必要的屏幕唤醒
   - 使用 WorkScheduler 安排后台任务

---

**最后更新**: 2026-05-30  
**版本**: 1.0.0